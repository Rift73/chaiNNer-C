from __future__ import annotations

import dataclasses
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import psutil
import pytest
from ncnn import ncnn

# The node's modules load the native backend, which GitHub's checks do not build.
pytest.importorskip("nodes.impl._chainner_graph")

from nodes.impl.image_utils import to_uint8
from nodes.impl.native_framework_images import ncnn_input
from nodes.impl.ncnn import session
from nodes.impl.ncnn.auto_split import ncnn_auto_split
from nodes.impl.ncnn.model import NcnnModel, NcnnModelWrapper
from nodes.impl.ncnn.session import create_ncnn_net
from nodes.impl.upscale.auto_split_tiles import ESTIMATE, NO_TILING, TileSize
from nodes.impl.upscale.tiler import MaxTileSize
from packages.chaiNNer_ncnn.ncnn.processing import upscale_image
from packages.chaiNNer_ncnn.ncnn.utility import interpolate_models
from packages.chaiNNer_ncnn.settings import NcnnSettings

BACKEND = Path(__file__).resolve().parents[1] / "src"
SETTINGS = NcnnSettings(
    gpu_index=0, winograd=False, sgemm=False, threads=1, blocktime=0, budget_limit=0
)
# A 1x1 convolution that copies its 3 channels, from blob "data" to blob "out".
PARAM = "7767517\n2 2\nInput data 0 1 data\nConvolution conv 1 1 data out 0=3 1=1 6=9\n"
BIN = b"\x00\x00\x00\x00" + np.eye(3, dtype=np.float32).tobytes()


def tiny_model(directory: Path) -> NcnnModelWrapper:
    (directory / "tiny.param").write_text(PARAM, encoding="utf-8")
    (directory / "tiny.bin").write_bytes(BIN)
    return NcnnModelWrapper(
        NcnnModel.load_from_file(
            str(directory / "tiny.param"), str(directory / "tiny.bin")
        )
    )


def test_a_model_ncnn_loads_is_accepted(tmp_path: Path):
    net = create_ncnn_net(tiny_model(tmp_path), SETTINGS)
    image = np.random.default_rng(0).random((5, 7, 3), dtype=np.float32)
    result = ncnn_auto_split(image, net, "data", "out", None, None, MaxTileSize())
    np.testing.assert_array_equal(
        result, ncnn_input(to_uint8(image)).transpose(1, 2, 0)
    )


@pytest.mark.parametrize(
    "planes,size", [(2, (6, 8)), (5, (5, 7)), (15, (65, 67))], ids=str
)
def test_a_model_of_other_plane_counts_gets_its_planes(
    tmp_path: Path, planes: int, size: tuple[int, int]
):
    # ncnn's pixel formats stop at 4 channels, so these planes reach the model as they are.
    (tmp_path / "copy.param").write_text(
        PARAM.replace("0=3 1=1 6=9", f"0={planes} 1=1 6={planes**2}"), encoding="utf-8"
    )
    (tmp_path / "copy.bin").write_bytes(
        b"\x00\x00\x00\x00" + np.eye(planes, dtype=np.float32).tobytes()
    )
    model = NcnnModelWrapper(
        NcnnModel.load_from_file(
            str(tmp_path / "copy.param"), str(tmp_path / "copy.bin")
        )
    )
    net = create_ncnn_net(model, SETTINGS)
    image = np.random.default_rng(planes).random((*size, planes), dtype=np.float32)
    result = ncnn_auto_split(image, net, "data", "out", None, None, MaxTileSize())
    np.testing.assert_array_equal(
        result, to_uint8(image).astype(np.float32) * np.float32(1 / 255)
    )


@pytest.mark.parametrize("planes", [1, 2, 3, 4, 5, 15])
def test_an_interpolated_model_is_checked_with_the_planes_it_takes(
    tmp_path: Path, planes: int, monkeypatch: pytest.MonkeyPatch
):
    (tmp_path / "copy.param").write_text(
        PARAM.replace("0=3 1=1 6=9", f"0={planes} 1=1 6={planes**2}"), encoding="utf-8"
    )
    (tmp_path / "copy.bin").write_bytes(
        b"\x00\x00\x00\x00" + np.eye(planes, dtype=np.float32).tobytes()
    )
    model = NcnnModelWrapper(
        NcnnModel.load_from_file(
            str(tmp_path / "copy.param"), str(tmp_path / "copy.bin")
        )
    )
    monkeypatch.setattr(upscale_image, "get_settings", lambda _: SETTINGS)
    context = SimpleNamespace(
        add_cleanup=lambda fn, after: None,
        check_aborted=lambda: None,
        set_progress=lambda *_: None,
    )
    assert interpolate_models.check_will_upscale(cast(Any, context), model)


class VulkanNet:
    """Stands in for ncnn.Net on the Vulkan branch: the tests hide every GPU, so the
    Vulkan settings go nowhere and the loads run on a CPU net."""

    def __init__(self):
        self.net = ncnn.Net()
        self.opt = SimpleNamespace()

    def set_vulkan_device(self, index: int) -> None:
        pass

    def __getattr__(self, name: str) -> Any:
        return getattr(self.net, name)


@pytest.mark.parametrize("gpu", [False, True])
@pytest.mark.parametrize("broken", ["param", "bin"])
def test_a_model_ncnn_cannot_load_is_refused(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, broken: str, gpu: bool
):
    if gpu:
        monkeypatch.setattr(session, "use_gpu", True)
        monkeypatch.setattr(session, "ncnn", SimpleNamespace(Net=VulkanNet))
    model = tiny_model(tmp_path)
    if broken == "param":
        # The header counts a layer the param lacks, as a converted SPAN model's does.
        param = PARAM.replace("2 2", "3 3")
        monkeypatch.setattr(model.model, "write_param", lambda: param)
    else:
        truncated = BIN[:8]
        monkeypatch.setattr(
            model.model, "write_bin", lambda path: Path(path).write_bytes(truncated)
        )
    with pytest.raises(ValueError, match=rf"model's \.{broken} \(error code -1\)"):
        create_ncnn_net(model, SETTINGS)


def test_failures_of_the_real_binding_raise_instead_of_crashing(tmp_path: Path):
    # Run apart: reading the empty output of a failed extract crashes the process.
    (tmp_path / "tiny.bin").write_bytes(BIN)
    code = "\n".join(
        [
            "import sys",
            f"sys.path[:0] = [{str(BACKEND)!r}]",
            "import numpy as np",
            "from ncnn import ncnn",
            "from nodes.impl.ncnn.auto_split import ncnn_auto_split",
            "from nodes.impl.upscale.tiler import MaxTileSize",
            "net = ncnn.Net()",
            "net.opt.use_vulkan_compute = False",
            f"assert net.load_param_mem({PARAM!r}) == 0",
            f"assert net.load_model({str(tmp_path / 'tiny.bin')!r}) == 0",
            "image = np.zeros((8, 8, 3), np.float32)",
            "for blobs in (('data', 'missing'), ('missing', 'out')):",
            "    try:",
            "        ncnn_auto_split(image, net, *blobs, None, None, MaxTileSize())",
            "    except Exception as e:",
            "        print(f'{type(e).__name__}: {e}', flush=True)",
        ]
    )
    result = subprocess.run(
        [sys.executable, "-B", "-c", code],
        capture_output=True,
        text=True,
        timeout=300,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == [
        "RuntimeError: NCNN failed with error code -1. Its reason is in chaiNNer's log.",
        "ValueError: The NCNN model has no blob named missing.",
    ]


class Net:
    """Upscales `scale_x` times across and `scale_y` times down (nearest pixel),
    then drops `crop` pixels from each side, as a waifu2x-ncnn-vulkan model's unpadded
    convolutions do. For an input of more than `limit` pixels it returns the error
    `code` as PyPI ncnn's Extractor does: no exception, and an output that must not
    be read."""

    def __init__(
        self,
        code: int = 0,
        limit: int = 2**62,
        crop: int = 0,
        scale_x: float = 2,
        scale_y: float = 2,
        most: int = 2**62,
    ):
        self.code = code
        self.most = most
        self.limit = limit
        self.crop = crop
        self.scale_x = scale_x
        self.scale_y = scale_y
        self.sizes: list[tuple[int, int]] = []
        self.opt = SimpleNamespace(
            use_winograd_convolution=False, use_sgemm_convolution=False
        )

    def create_extractor(self) -> Extractor:
        return Extractor(self)


class Extractor:
    def __init__(self, net: Net):
        self.net = net
        self.image = np.zeros((3, 0, 0), np.float32)

    def input(self, name: str, mat: ncnn.Mat) -> int:
        self.image = np.array(mat)
        return 0

    def extract(self, name: str) -> tuple[int, np.ndarray | None]:
        _, h, w = self.image.shape
        self.net.sizes.append((w, h))
        assert len(self.net.sizes) <= self.net.most, "more extracts than expected"
        if w * h > self.net.limit:
            return self.net.code, None
        c = self.net.crop
        out_h, out_w = round(h * self.net.scale_y), round(w * self.net.scale_x)
        rows = np.arange(out_h) * h // out_h
        columns = np.arange(out_w) * w // out_w
        # A Mat's rows are contiguous (indexing alone would order them otherwise).
        upscaled = np.ascontiguousarray(self.image[:, rows][:, :, columns])
        return 0, upscaled[:, c : out_h - c, c : out_w - c]


def test_out_of_memory_at_the_smallest_tiles_ends():
    # The split retried 16 px tiles for ever before (the stop keeps a failure here
    # from hanging the tests).
    net = Net(code=-100, limit=0, most=1000)
    image = np.zeros((40, 40, 3), np.float32)
    with pytest.raises(
        ValueError, match="tiles smaller than 16x16 px, which still failed 20 more"
    ):
        ncnn_auto_split(
            image, cast(ncnn.Net, net), "data", "out", None, None, MaxTileSize()
        )
    assert len(net.sizes) < 60


def test_out_of_memory_retries_with_smaller_tiles():
    net = Net(code=-100, limit=64 * 64)
    image = np.random.default_rng(0).random((100, 120, 3), dtype=np.float32)
    result = ncnn_auto_split(
        image, cast(ncnn.Net, net), "data", "out", None, None, MaxTileSize()
    )
    assert net.sizes[0] == (120, 100)
    assert len(net.sizes) > 1
    expected = ncnn_input(to_uint8(image)).transpose(1, 2, 0)
    np.testing.assert_allclose(
        result, expected.repeat(2, axis=0).repeat(2, axis=1), rtol=0, atol=1e-6
    )


def test_other_failures_raise_their_code_without_retrying():
    net = Net(code=-1, limit=0)
    image = np.zeros((10, 12, 3), np.float32)
    with pytest.raises(RuntimeError, match=r"NCNN failed with error code -1\."):
        ncnn_auto_split(
            image, cast(ncnn.Net, net), "data", "out", None, None, MaxTileSize()
        )
    assert net.sizes == [(12, 10)]


def upscale_with(
    monkeypatch: pytest.MonkeyPatch,
    net: Net,
    scale: int,
    image: np.ndarray,
    tile_size: TileSize = NO_TILING,
    settings: NcnnSettings = SETTINGS,
    bin_length: int = 0,
) -> np.ndarray:
    """NCNN Upscale Image's upscale with the fake `net`, for a model of `scale` whose
    weights take `bin_length` bytes."""
    monkeypatch.setattr(upscale_image, "get_ncnn_net", lambda model, settings: net)
    model = cast(
        NcnnModelWrapper,
        SimpleNamespace(
            scale=scale, size_multiple=1, model=SimpleNamespace(bin_length=bin_length)
        ),
    )
    return upscale_image.upscale_impl(settings, image, model, "data", "out", tile_size)


@pytest.mark.parametrize(
    ("tile_size", "message"),
    [
        (NO_TILING, "a 1564x1164 image for a 800x600 image, 36 pixels short of its 2x"),
        (TileSize(256), r"a \d+x\d+ image for a \d+x\d+ tile.*whole multiple"),
    ],
)
def test_a_model_that_crops_its_output_is_refused(
    monkeypatch: pytest.MonkeyPatch, tile_size: TileSize, message: str
):
    # 2x less 36 pixels: whole, 800x600 gives 1564x1164; every tile is cropped too.
    image = np.zeros((600, 800, 3), np.float32)
    with pytest.raises(ValueError, match=message):
        upscale_with(monkeypatch, Net(crop=18), 2, image, tile_size)


@pytest.mark.parametrize(
    ("scale_x", "scale_y", "scale", "height", "width"),
    [
        pytest.param(0.5, 0.5, 1, 60, 80, id="downscale"),
        pytest.param(0.5, 0.5, 1, 64, 64, id="downscale-square"),
        pytest.param(2, 1, 2, 60, 80, id="uneven"),
        pytest.param(1.5, 1.5, 1, 64, 64, id="non-integer"),
        pytest.param(2, 2, 4, 60, 80, id="less-than-its-scale"),
    ],
)
def test_other_sizes_are_returned_as_the_model_made_them_without_tiling(
    monkeypatch: pytest.MonkeyPatch,
    scale_x: float,
    scale_y: float,
    scale: int,
    height: int,
    width: int,
):
    image = np.random.default_rng(0).random((height, width, 3), dtype=np.float32)
    net = Net(scale_x=scale_x, scale_y=scale_y)
    result = upscale_with(monkeypatch, net, scale, image)

    pixels = ncnn_input(to_uint8(image))
    extractor = Extractor(net)
    extractor.image = pixels
    _, expected = extractor.extract("out")
    assert expected is not None
    assert result.shape[:2] == (round(height * scale_y), round(width * scale_x))
    np.testing.assert_array_equal(result, expected.transpose(1, 2, 0))


# On the CPU this model's estimate is 60 bytes per pixel of an RGB image
# (159744 * 5/3 / (1024 * 52) * 3 * 4), and 80% of 900000 bytes of available RAM
# holds 12000 pixels: 100x120 fits, 101x120 does not and gets 64-pixel tiles.
BIN_LENGTH = 159744
THRESHOLD_RAM = 900000


def upscale_on_cpu(
    monkeypatch: pytest.MonkeyPatch,
    image: np.ndarray,
    available: int,
    budget_limit: int = 0,
    bin_length: int = BIN_LENGTH,
) -> tuple[np.ndarray, list[tuple[int, int]]]:
    """Automatic tiling with `available` bytes of RAM: the result and the sizes the
    network was given. With 2**60 bytes no image is too big, which is the budget the
    CPU branch had before it counted the RAM."""
    monkeypatch.setattr(
        psutil, "virtual_memory", lambda: SimpleNamespace(available=available)
    )
    net = Net()
    settings = dataclasses.replace(SETTINGS, budget_limit=budget_limit)
    result = upscale_with(
        monkeypatch, net, 2, image, ESTIMATE, settings, bin_length=bin_length
    )
    return result, net.sizes


@pytest.mark.parametrize(
    ("height", "width"),
    [(1, 1), (64, 64), (100, 120), (120, 100), (60, 200), (200, 60), (12000, 1)],
)
def test_cpu_images_that_fit_in_ram_stay_whole(
    monkeypatch: pytest.MonkeyPatch, height: int, width: int
):
    # Each holds at most 12000 pixels; 60x200 is wider than the 64-pixel tiles the
    # RAM would give, and stays whole all the same.
    image = np.random.default_rng(0).random((height, width, 3), dtype=np.float32)
    result, sizes = upscale_on_cpu(monkeypatch, image, THRESHOLD_RAM)
    before, sizes_before = upscale_on_cpu(monkeypatch, image, 2**60)
    assert sizes == sizes_before == [(width, height)]
    np.testing.assert_array_equal(result, before)


@pytest.mark.parametrize(("height", "width"), [(101, 120), (120, 101), (300, 400)])
def test_cpu_images_too_big_for_ram_are_tiled(
    monkeypatch: pytest.MonkeyPatch, height: int, width: int
):
    image = np.random.default_rng(0).random((height, width, 3), dtype=np.float32)
    result, sizes = upscale_on_cpu(monkeypatch, image, THRESHOLD_RAM)
    whole, sizes_before = upscale_on_cpu(monkeypatch, image, 2**60)
    assert sizes_before == [(width, height)]
    assert len(sizes) > 1
    assert max(max(size) for size in sizes) < 100
    np.testing.assert_allclose(result, whole, rtol=0, atol=1e-6)


def test_cpu_budget_limit_splits_an_image_that_fits_in_ram_as_before(
    monkeypatch: pytest.MonkeyPatch,
):
    # A Memory Budget Limit of 1 GiB gives this model 64-pixel tiles, as it did
    # before, while 2 GiB of RAM would hold the whole image.
    image = np.random.default_rng(0).random((100, 120, 3), dtype=np.float32)
    bin_length = BIN_LENGTH * 2**30 // 720000
    result, sizes = upscale_on_cpu(monkeypatch, image, 2 * 2**30, 1, bin_length)
    net = Net()
    expected = upscale_with(monkeypatch, net, 2, image, TileSize(64))
    assert len(sizes) > 1
    assert sizes == net.sizes
    np.testing.assert_array_equal(result, expected)


def test_an_unexpected_error_is_logged_and_kept_as_the_cause(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
):
    # A bare assert of the tiler used to reach the log as an empty "ERROR ''".
    def fail(*args: object, **kwargs: object) -> np.ndarray:
        raise AssertionError

    monkeypatch.setattr(upscale_image, "ncnn_auto_split", fail)
    image = np.zeros((8, 8, 3), np.float32)
    with pytest.raises(RuntimeError, match="unexpected error") as raised:
        upscale_image.upscale_impl(
            SETTINGS, image, tiny_model(tmp_path), "data", "out", NO_TILING
        )
    assert isinstance(raised.value.__cause__, AssertionError)
    errors = [r for r in caplog.records if r.levelname == "ERROR"]
    assert [r.exc_info[0] for r in errors if r.exc_info] == [AssertionError]


# Sorted apart, "m.fp16.param" comes before "m.param" but "m.fp16.bin" after "m.bin":
# each .param goes with the .bin of its own name.
def test_load_models_pairs_each_param_with_its_own_bin(tmp_path: Path):
    from packages.chaiNNer_ncnn.ncnn.batch_processing.load_models import (
        load_models_node,
    )

    for name in ("m", "m.fp16"):
        (tmp_path / f"{name}.param").write_text(PARAM, encoding="utf-8")
        (tmp_path / f"{name}.bin").write_bytes(BIN)
    generator, _ = load_models_node(tmp_path, False)
    items = list(generator.supplier())
    assert all(isinstance(item, tuple) for item in items), items
    assert sorted(item[2] for item in items if isinstance(item, tuple)) == [
        "m",
        "m.fp16",
    ]


def saved_pair(directory: Path) -> tuple[bytes, bytes]:
    return (directory / "m.param").read_bytes(), (directory / "m.bin").read_bytes()


def old_pair(directory: Path) -> tuple[bytes, bytes]:
    (directory / "m.param").write_bytes(b"OLD GRAPH")
    (directory / "m.bin").write_bytes(b"OLD WEIGHTS")
    return saved_pair(directory)


@pytest.mark.skipif(sys.platform != "win32", reason="an open file blocks its rename")
def test_save_model_leaves_the_old_pair_when_the_param_cannot_be_replaced(
    tmp_path: Path,
):
    # Save Model wrote the .bin, then failed on the .param: a new .bin beside the old .param.
    from packages.chaiNNer_ncnn.ncnn.io.save_model import save_model_node

    (tmp_path / "source").mkdir()
    model = tiny_model(tmp_path / "source")
    old = old_pair(tmp_path)
    with open(tmp_path / "m.param", "rb"), pytest.raises(OSError):
        save_model_node(model, tmp_path, "m")
    assert saved_pair(tmp_path) == old
    assert sorted(p.name for p in tmp_path.iterdir()) == ["m.bin", "m.param", "source"]


def test_save_model_puts_the_param_back_when_the_bin_cannot_be_replaced(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    from nodes.impl.native_graph import graph
    from packages.chaiNNer_ncnn.ncnn.io import save_model

    (tmp_path / "source").mkdir()
    model = tiny_model(tmp_path / "source")
    old = old_pair(tmp_path)
    native = graph()

    class Target:
        """The real target, whose rename onto the .bin fails as a held file's does."""

        def __init__(self, path: Path) -> None:
            self.target = native.AtomicTarget(path)
            self.fails = Path(path).suffix == ".bin"

        def __getattr__(self, name: str) -> Any:
            return getattr(self.target, name)

        def __enter__(self) -> Target:
            return self

        def __exit__(self, *error: object) -> None:
            self.target.__exit__(*error)

        def commit(self) -> bool:
            if self.fails:
                raise PermissionError("the .bin is held open")
            return self.target.commit()

    fake = SimpleNamespace(AtomicTarget=Target, atomic_write=native.atomic_write)
    monkeypatch.setattr(save_model, "graph", lambda: fake)
    with pytest.raises(PermissionError):
        save_model.save_model_node(model, tmp_path, "m")
    assert saved_pair(tmp_path) == old
    assert sorted(p.name for p in tmp_path.iterdir()) == ["m.bin", "m.param", "source"]


def test_save_model_writes_the_pair_open_would_write(tmp_path: Path):
    from packages.chaiNNer_ncnn.ncnn.io.save_model import save_model_node

    (tmp_path / "source").mkdir()
    model = tiny_model(tmp_path / "source")
    old_pair(tmp_path)
    save_model_node(model, tmp_path, "m")
    model.model.write_param(tmp_path / "source" / "m.param")
    model.model.write_bin(tmp_path / "source" / "m.bin")
    assert saved_pair(tmp_path) == saved_pair(tmp_path / "source")
    assert sorted(p.name for p in tmp_path.iterdir()) == ["m.bin", "m.param", "source"]
