"""Upscale Image's Use TensorRT Engine for TFDATv2 on an NVIDIA GPU
(nodes/impl/pytorch/rdual_engine.py, which serves every temporal model): a small model
with every parameter random, its set really built in the Engine Cache, its frames
against the TensorRT node's route on the same set, and a second run that reads the set
from the cache without building."""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast
from weakref import WeakKeyDictionary

import numpy as np
import pytest
import torch

pytest.importorskip("spandrel.architectures.TFDAT")
pytest.importorskip("tensorrt")

from spandrel import ModelLoader
from spandrel.architectures.TFDAT import TFDATv2
from test_rdual_engine_route import Context
from test_tensorrt_tfdat import HEIGHT, WIDTH, View, clip, tiny

from api import NodeContext
from nodes.impl.pytorch import rdual_engine
from nodes.impl.pytorch.rdual_window import release_memory
from nodes.impl.pytorch.tfdat_window import TFDATWindows
from nodes.impl.pytorch.utils import is_out_of_memory
from nodes.impl.tensorrt import tfdat, tfdat_session
from nodes.impl.upscale.basic_upscale import PaddingType
from nodes.impl.upscale.temporal_window import Fit
from nodes.impl.upscale.tile_report import TileReport
from nodes.impl.upscale.tiler import NoTiling

pytestmark = pytest.mark.skipif(
    not torch.cuda.is_available(), reason="needs a CUDA GPU"
)
FRAMES = 12
GPU = torch.device("cuda", 0)


@pytest.fixture(scope="module", params=[5, 9], ids=["clip 5", "clip 9"])
def descriptor(request: pytest.FixtureRequest) -> Any:
    return ModelLoader().load_from_state_dict(tiny(TFDATv2, request.param).state_dict())


@pytest.fixture(scope="module")
def frames() -> list[np.ndarray]:
    video = clip(FRAMES)[0].view(FRAMES, 3, HEIGHT, WIDTH)
    return [np.ascontiguousarray(f.permute(1, 2, 0).flip(-1).numpy()) for f in video]


class BuildContext(Context):
    """Context, with the Stop check the set's export and build poll."""

    def check_aborted(self) -> None:
        pass


# The route's sets of each model in memory, as rdual_engine keeps them (builds installs it)
SETS: WeakKeyDictionary[Any, dict[Any, Any]] = WeakKeyDictionary()


@pytest.fixture
def builds(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> list[Any]:
    """The route on this GPU with its Engine Cache in tmp_path and its sets in SETS;
    each set build recorded."""
    calls: list[Any] = []
    SETS.clear()
    monkeypatch.setattr(rdual_engine, "hold_engine", lambda _node: None)
    monkeypatch.setattr(rdual_engine, "release_engine", lambda _node: None)
    monkeypatch.setattr(rdual_engine, "_failed", WeakKeyDictionary())
    monkeypatch.setattr(rdual_engine, "_sets", SETS)
    monkeypatch.setattr(rdual_engine, "cache_folder", lambda *_: tmp_path)
    build_set = tfdat.build_set

    def recorded(*arguments: Any) -> Any:
        calls.append(arguments[1:3])
        return build_set(*arguments)

    monkeypatch.setattr(tfdat, "build_set", recorded)
    return calls


def checkbox(
    descriptor: Any, frames: list[np.ndarray]
) -> tuple[list[np.ndarray], BuildContext]:
    """Every frame through PyTorch's Upscale Image with Use TensorRT Engine on."""
    context = BuildContext()
    view = View(frames, 3)
    cast(Any, context).iteration = view
    fit = Fit(
        NoTiling(), shorten=True, out_of_memory=is_out_of_memory, release=release_memory
    )
    outputs = []
    for index, frame in enumerate(frames):
        view.index = index
        outputs.append(
            rdual_engine.temporal_upscale_through_engine(
                cast(NodeContext, context),
                frame,
                descriptor,
                GPU,
                lambda: TFDATWindows(descriptor, GPU, True),
                0,
                TileReport(),
                PaddingType.NONE,
                fit,
            )
        )
    return outputs, context


def test_the_checkbox_runs_the_set_as_the_tensorrt_node_does(
    descriptor: Any, frames: list[np.ndarray], builds: list[Any], tmp_path: Path
):
    got, context = checkbox(descriptor, frames)

    assert context.warnings == []
    assert builds == [(HEIGHT, WIDTH)]
    assert len(list(tmp_path.iterdir())) == 1
    engine = SETS[descriptor][(HEIGHT, WIDTH, 0, str(tmp_path))]
    view = View(frames, 3)
    node = Context()
    cast(Any, node).iteration = view
    for index, frame in enumerate(frames):
        view.index = index
        expected = tfdat_session.temporal_engine_upscale(
            cast(NodeContext, node), frame, engine, 0, TileReport()
        )
        np.testing.assert_array_equal(got[index], expected, f"frame {index}")

    # Another run, its sets no longer in memory: the set is read from the Engine Cache.
    SETS.clear()
    again, _ = checkbox(descriptor, frames)
    assert builds == [(HEIGHT, WIDTH)]
    for index, image in enumerate(again):
        np.testing.assert_array_equal(image, got[index], f"frame {index}")
