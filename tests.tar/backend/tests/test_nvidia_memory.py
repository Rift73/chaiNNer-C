"""An NVIDIA device's memory reading: NVML's older call counts the driver's own reserve as
used; the version-2 call says how much it is. Runs without a GPU: NVML is a stand-in."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

import gpu


def _device(
    monkeypatch: pytest.MonkeyPatch, detail: SimpleNamespace | int
) -> gpu.NvDevice:
    def memory_info(_handle: object, version: int | None = None) -> SimpleNamespace:
        if version is None:
            return SimpleNamespace(total=32 << 30, used=3 << 30, free=29 << 30)
        assert version == gpu.nv.nvmlMemory_v2
        if isinstance(detail, int):
            raise gpu.nv.NVMLError(detail)
        return detail

    monkeypatch.setattr(gpu.nv, "nvmlDeviceGetMemoryInfo", memory_info)
    return gpu.NvDevice(index=0, handle=gpu.nv.c_nvmlDevice_t(), name="Test GPU")


def test_the_drivers_reserve_is_read_beside_the_older_use(
    monkeypatch: pytest.MonkeyPatch,
):
    device = _device(monkeypatch, SimpleNamespace(reserved=420 << 20))
    assert device.get_current_vram_usage() == gpu.MemoryUsage(
        32 << 30, 3 << 30, 29 << 30, 420 << 20
    )


@pytest.mark.parametrize(
    "error",
    [
        gpu.nv.NVML_ERROR_FUNCTION_NOT_FOUND,
        gpu.nv.NVML_ERROR_NOT_SUPPORTED,
        gpu.nv.NVML_ERROR_ARGUMENT_VERSION_MISMATCH,
        gpu.nv.NVML_ERROR_GPU_IS_LOST,
    ],
)
def test_without_the_version_2_reading_no_reserve_is_known(
    monkeypatch: pytest.MonkeyPatch, error: int
):
    device = _device(monkeypatch, error)
    assert device.get_current_vram_usage() == gpu.MemoryUsage(
        32 << 30, 3 << 30, 29 << 30, 0
    )


def test_a_failing_version_2_reading_is_logged_once_and_the_older_one_stands(
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setattr(gpu, "_reserve_unread", [])
    warnings: list[tuple[object, ...]] = []
    monkeypatch.setattr(
        gpu.logger, "warning", lambda *args, **kwargs: warnings.append(args)
    )
    device = _device(monkeypatch, gpu.nv.NVML_ERROR_UNKNOWN)
    for _ in range(2):
        assert device.get_current_vram_usage() == gpu.MemoryUsage(
            32 << 30, 3 << 30, 29 << 30, 0
        )
    assert len(warnings) == 1
