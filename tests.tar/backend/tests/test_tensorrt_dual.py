from __future__ import annotations

import importlib
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import onnx
import onnx.external_data_helper
import pytest
import torch
from onnx import TensorProto, helper, numpy_helper
from spandrel import ModelLoader
from spandrel.architectures.DUAL.__arch import dual_arch
from spandrel.architectures.DUAL.__arch.dual_arch import dual_xs

from nodes.impl.onnx.load import load_onnx_model
from nodes.impl.onnx.model import MIXED
from nodes.impl.tensorrt import dual


@pytest.mark.parametrize(
    ("tags", "factory"),
    [(["Light", "128dim"], "dual_light"), (["XS"], "dual_xs"), (["XL"], "dual_xl")],
)
def test_presets_map_to_the_guides_factories(tags: list[str], factory: str):
    assert dual.factory_of(tags) == factory


@pytest.mark.parametrize("tags", [[], ["96dim", "4g"], ["DUAL3X"]])
def test_other_dual_models_are_refused(tags: list[str]):
    with pytest.raises(ValueError, match="six DUAL presets"):
        dual.factory_of(tags)


def _plain_onnx() -> bytes:
    node = helper.make_node("Identity", ["input"], ["output"])
    graph = helper.make_graph(
        [node],
        "plain",
        [helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, 4, 4])],
        [helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 3, 4, 4])],
    )
    return helper.make_model(graph).SerializeToString()


def test_only_a_dual_export_has_a_manifest():
    assert dual.export_manifest(_plain_onnx()) is None
    assert dual.export_manifest(onnx.load_from_string(_plain_onnx())) is None


def test_only_the_rgb_readout_moves_ahead_of_its_pixel_shuffle():
    # Moving a 3x3 convolution ahead of a x2 shuffle keeps its result but quadruples its
    # work; for the 64-to-256 tail convolution that cost Light ~4.5 ms at 512x512.
    spec = importlib.util.spec_from_file_location(
        "dual_tensorrt_graph", dual.VENDOR / "scripts/dual_tensorrt/graph.py"
    )
    assert spec is not None and spec.loader is not None
    graph_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(graph_module)
    tail = torch.nn.Sequential(
        torch.nn.Conv2d(64, 256, 3, padding=1),
        torch.nn.PixelShuffle(2),
        torch.nn.Conv2d(64, 256, 3, padding=1),
        torch.nn.PixelShuffle(2),
        torch.nn.Conv2d(64, 3, 3, padding=1),
    )
    graph = graph_module.Graph(dual_arch, SimpleNamespace(channels=128, trunk=(8, 8)))
    graph.tail_sequence("x", tail)
    weights = {constant.name: tuple(constant.dims) for constant in graph.constants}
    convolutions = [node for node in graph.nodes if node.op_type == "Conv"]
    assert [weights[node.input[1]] for node in convolutions] == [
        (256, 64, 3, 3),
        (256, 64, 3, 3),
        (12, 256, 3, 3),
    ]


def test_the_exporters_write_onnxs_files_in_one_pass(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    # ONNX's own writer opens and closes weights.bin once per tensor, and real-time
    # antivirus scanning rescans the growing file after each close: a DUAL Light export
    # (335 tensors) took about 100 s with Windows Defender on, 0.1 s with it off.
    monkeypatch.syspath_prepend(str(dual.VENDOR))
    export = importlib.import_module("scripts.dual_tensorrt.export")
    # 2048, 16, 1000 (external by ONNX's rule, which counts the bytes object's
    # overhead), 4096 and 8 bytes.
    shapes = [(16, 32), (4,), (250,), (32, 32), (2,)]
    weights = [
        numpy_helper.from_array(
            np.arange(np.prod(shape), dtype=np.float32).reshape(shape), f"w{i}"
        )
        for i, shape in enumerate(shapes)
    ]
    value = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1])
    graph = helper.make_graph(
        [helper.make_node("Identity", ["input"], ["output"])],
        "weights",
        [value],
        [helper.make_tensor_value_info("output", TensorProto.FLOAT, [1])],
        initializer=weights,
    )
    model = helper.make_model(graph)
    expected, written = tmp_path / "onnx", tmp_path / "one-pass"
    expected.mkdir()
    written.mkdir()
    reference = onnx.ModelProto()
    reference.CopyFrom(model)
    onnx.save_model(
        reference,
        str(expected / "model.onnx"),
        save_as_external_data=True,
        all_tensors_to_one_file=True,
        location="weights.bin",
        size_threshold=1024,
    )

    def per_tensor(*_args: object):
        raise AssertionError("weights.bin was written one tensor at a time")

    monkeypatch.setattr(onnx.external_data_helper, "save_external_data", per_tensor)
    export.save_onnx(model, written)
    for name in ("model.onnx", "weights.bin"):
        assert (written / name).read_bytes() == (expected / name).read_bytes()
    assert (expected / "weights.bin").stat().st_size == 2048 + 1000 + 4096


def _folded_xs(tmp_path: Path):
    torch.manual_seed(0)
    model = dual_xs(scale=1).eval()
    path = tmp_path / "xs.pth"
    torch.save(model.state_dict(), path)
    return ModelLoader("cpu").load_from_file(path)  # folded on load


@pytest.fixture(scope="module")
def fixed_xs_onnx(tmp_path_factory: pytest.TempPathFactory) -> bytes:
    descriptor = _folded_xs(tmp_path_factory.mktemp("xs"))
    return dual.export_onnx(
        descriptor.model.state_dict(), descriptor.tags, descriptor.scale, (32, 64)
    )


def test_a_folded_xs_exports_a_fixed_size_tensorrt_onnx(fixed_xs_onnx: bytes):
    onnx_bytes = fixed_xs_onnx
    manifest = dual.export_manifest(onnx_bytes)
    assert manifest is not None
    spec = manifest["specialization"]
    assert (spec["factory"], spec["scale"], spec["height"], spec["width"]) == (
        "dual_xs",
        1,
        32,
        64,
    )
    assert spec["plugin_key"] == "c128_h32_w64"
    assert manifest["checkpoint_folded"] is True
    model = onnx.load_from_string(onnx_bytes)
    assert "trt" in {node.domain for node in model.graph.node}
    assert dual.export_manifest(model) == manifest


def _tag(node: onnx.NodeProto) -> str:
    """The exporter's site of a node: /group<g>/layer<i> for a trunk layer's."""
    return node.name.rpartition("/")[0]


def _windows(nodes: list[onnx.NodeProto]) -> list[int]:
    return [a.i for n in nodes for a in n.attribute if a.name == "window"]


def test_context_sites_past_their_window_export_as_neighborhood_attention(
    fixed_xs_onnx: bytes,
):
    # At 32x64 the M32 sites' trunk is wider than their window; the M64 sites' fits.
    model = onnx.load_from_string(fixed_xs_onnx)
    manifest = dual.export_manifest(model)
    assert manifest is not None
    assert manifest["context"] == "na-v1"
    assert (manifest["local"], manifest["retrieval"]) == ("na-v1", "na-v1")
    assert "DualNA_c128_h32_w64_TRT" in manifest["plugin_names"]
    graph = model.graph
    na = [n for n in graph.node if n.op_type == "DualNA_c128_h32_w64_TRT"]
    assert _windows(na) == [32, 32, 32]
    sites = {_tag(n) for n in na}
    assert sites == {"/group0/layer2", "/group2/layer2", "/group3/layer2"}
    weights = {i.name for i in graph.initializer}
    for node in graph.node:
        if _tag(node) in sites:
            # No attention is left there: each MatMul is a projection by a weight.
            assert node.op_type != "Softmax"
            assert node.op_type != "MatMul" or node.input[1] in weights
    attention = {_tag(n) for n in graph.node if n.op_type == "Softmax"}
    assert {"/group1/layer2", "/group3/layer5"} <= attention


def test_the_neighborhood_oracle_matches_the_canonical_model(
    monkeypatch: pytest.MonkeyPatch,
):
    # The DualNA node evaluated densely per query (the exporter's FP32 oracle) against
    # the source's tiled _na_core, with nonzero RFB sine amplitudes (the bias's signed
    # term): XS x2 at 48x40, where the three M32 sites are neighborhoods. The oracle
    # has no local neighborhoods, so the model keeps its local windows.
    monkeypatch.syspath_prepend(str(dual.VENDOR))
    export = importlib.import_module("scripts.dual_tensorrt.export")
    oracle = importlib.import_module("scripts.dual_tensorrt.cpu_graph_oracle")
    spec = importlib.import_module("scripts.dual_tensorrt.spec")
    torch.manual_seed(0)
    arch, model = export.make_model("dual_xs", 2)
    with torch.no_grad():
        for group in model.groups:
            for layer in group.layers:
                if layer.attention.context_na:
                    layer.attention.factored_bias.amplitude_sin.normal_(std=0.3)
                layer.attention.local_na = False
        model.prepare_for_export()
        x = torch.rand(1, 3, 48, 40)
        graph = oracle.FP32GraphOracle(
            arch, spec.from_model(model, "dual_xs", 2, 48, 40), x
        )
        torch.testing.assert_close(graph.build(model), model(x), rtol=3e-5, atol=3e-6)
    assert graph.na_sites == 3


def test_routing_na_exports_as_its_own_site(tmp_path: Path, fixed_xs_onnx: bytes):
    # Every dynamic convolution routes per position (DualBoxMean's neighborhood means, no
    # row sums); the manifest names exactly the plugins the graph holds.
    descriptor = _folded_xs(tmp_path)
    onnx_bytes = dual.export_onnx(
        descriptor.model.state_dict(),
        descriptor.tags,
        descriptor.scale,
        (32, 64),
        routing_na=True,
    )
    manifest = dual.export_manifest(onnx_bytes)
    assert manifest is not None
    assert manifest["routing"] == "na-v1"
    assert manifest["routed_parts"] == 4
    graph = onnx.load_from_string(onnx_bytes).graph
    plugins = {n.op_type for n in graph.node if n.domain == "trt"}
    assert set(manifest["plugin_names"]) == plugins
    assert "DualRowSum_c128_h32_w64_TRT" not in plugins
    means = [n for n in graph.node if n.op_type == "DualBoxMean_c128_h32_w64_TRT"]
    assert len(means) == manifest["dynamic_sites"]
    assert not [n for n in graph.node if n.op_type == "AveragePool"]
    # Off (the default), no key: the released graph.
    off = dual.export_manifest(fixed_xs_onnx)
    assert off is not None
    assert "routing" not in off


def test_routing_na_exports_for_every_size(tmp_path: Path):
    # The dynamic ONNX: the width-only plugin node reads the size at run time.
    descriptor = _folded_xs(tmp_path)
    onnx_bytes = dual.export_onnx(
        descriptor.model.state_dict(),
        descriptor.tags,
        descriptor.scale,
        None,
        routing_na=True,
    )
    manifest = dual.export_manifest(onnx_bytes)
    assert manifest is not None
    assert manifest["specialization"]["dynamic"]
    assert manifest["routing"] == "na-v1"
    graph = onnx.load_from_string(onnx_bytes).graph
    plugins = {n.op_type for n in graph.node if n.domain == "trt"}
    assert set(manifest["plugin_names"]) == plugins
    means = [n for n in graph.node if n.op_type == "DualBoxMean_c128_TRT"]
    assert len(means) == manifest["dynamic_sites"]
    assert "DualRowSum_c128_TRT" not in plugins
    # No size is written into the graph's routed blend.
    dims = graph.input[0].type.tensor_type.shape.dim
    assert [d.dim_param for d in dims[2:]] == ["in_height", "in_width"]


@pytest.mark.parametrize("box_mean", [False, True])
def test_the_routed_convolution_matches_the_per_position_definition(
    monkeypatch: pytest.MonkeyPatch, box_mean: bool
):
    # Graph.routed_conv evaluated in FP32 (the exporter's oracle) against the definition:
    # the router's input at p is the mean over p's clamped K x K neighborhood,
    # start = clamp(p - K // 2, 0, L - K), K = min(96, L); output = base convolution +
    # sum_e c_e(p) * expert_e. A 40 x 120 trunk clamps on both axes (K = 40 and 96).
    # The means through the pools (NCHW) and through DualBoxMean (NHWC, row sums).
    monkeypatch.syspath_prepend(str(dual.VENDOR))
    export = importlib.import_module("scripts.dual_tensorrt.export")
    oracle = importlib.import_module("scripts.dual_tensorrt.cpu_graph_oracle")
    spec = importlib.import_module("scripts.dual_tensorrt.spec")
    torch.manual_seed(0)
    arch, model = export.make_model("dual_xs", 1)
    model.prepare_for_export()
    conv = next(
        m for m in model.modules() if isinstance(m, arch.PremixedDeployedDynamicConv3x3)
    )
    with torch.no_grad():
        conv.router.fc2.weight.normal_(std=1.0)
        conv.experts.normal_(std=0.02)
    height, width = 40, 120
    graph = oracle.FP32GraphOracle(
        arch, spec.from_model(model, "dual_xs", 1, height, width), None
    )
    graph.routing_na = True
    x = torch.randn(1, conv.base.in_channels, height, width)
    with torch.no_grad():
        if box_mean:
            # An NHWC trunk with row sums: the means come from DualBoxMean
            graph.row_sums = True
            got = graph.dynamic_conv(x.permute(0, 2, 3, 1), conv, True)
            got = got.permute(0, 3, 1, 2)
        else:
            got = graph.dynamic_conv(x, conv, False)
        ky, kx = min(96, height), min(96, width)
        pooled = torch.empty(1, height, width, x.shape[1])
        for y in range(height):
            y0 = min(max(y - ky // 2, 0), height - ky)
            for c in range(width):
                x0 = min(max(c - kx // 2, 0), width - kx)
                pooled[0, y, c] = x[0, :, y0 : y0 + ky, x0 : x0 + kx].mean((1, 2))
        router = conv.router
        hidden = torch.nn.functional.gelu(
            router.fc1(torch.nn.functional.layer_norm(pooled, (x.shape[1],), eps=1e-5))
        )
        experts = conv.experts.shape[0]
        coefficients = router.fc2(hidden).softmax(-1) - 1.0 / experts
        want = conv.base(x)
        for e in range(experts):
            weight = conv.experts[e].reshape(conv.base.weight.shape)
            want = want + coefficients[..., e][:, None] * torch.nn.functional.conv2d(
                x, weight, padding=1
            )
    assert graph.routing_sites == 1
    assert graph.box_mean_sites == box_mean
    torch.testing.assert_close(got, want, rtol=1e-4, atol=1e-5)


def test_chainner_loads_a_dual_onnx_as_mixed_precision(fixed_xs_onnx: bytes):
    # Loading runs in the native backend, which GitHub's checks do not build.
    pytest.importorskip("nodes.impl._chainner_graph")
    info = load_onnx_model(fixed_xs_onnx).info
    assert (info.fixed_input_height, info.fixed_input_width) == (32, 64)
    assert (info.scale_height, info.input_channels, info.output_channels) == (1, 3, 3)
    assert info.dtype == MIXED
    assert load_onnx_model(_plain_onnx()).info.dtype == "fp32"


def test_a_folded_xs_exports_one_tensorrt_onnx_for_every_size(tmp_path: Path):
    descriptor = _folded_xs(tmp_path)
    onnx_bytes = dual.export_onnx(
        descriptor.model.state_dict(), descriptor.tags, descriptor.scale, None
    )
    manifest = dual.export_manifest(onnx_bytes)
    assert manifest is not None
    spec = manifest["specialization"]
    assert (spec["factory"], spec["scale"], spec["dynamic"]) == ("dual_xs", 1, True)
    assert (spec["alignment"], spec["plugin_key"]) == (dual.ALIGNMENT, "c128")
    assert manifest["context"] == "na-v1"
    assert (manifest["local"], manifest["retrieval"]) == ("na-v1", "na-v1")
    graph = onnx.load_from_string(onnx_bytes).graph
    dims = graph.input[0].type.tensor_type.shape.dim
    assert [d.dim_value or d.dim_param for d in dims] == [1, 3, "in_height", "in_width"]
    plugins = {node.op_type for node in graph.node if node.domain == "trt"}
    assert plugins == {
        "DualNorm_c128_TRT",
        "DualCore_c128_TRT",
        "DualProject_c128_TRT",
        "DualNA_c128_TRT",
        "DualLocalNA_c128_TRT",
        "DualXR_c128_TRT",
        "DualRowSum_c128_TRT",
    }
    assert set(manifest["plugin_names"]) == plugins
    # Every context site, whatever the run-time size (one that fits the window is a
    # single neighborhood, the whole-window attention).
    na = [n for n in graph.node if n.op_type == "DualNA_c128_TRT"]
    assert _windows(na) == [32, 64, 32, 32, 64]
    sites = {_tag(n) for n in na}
    assert len(sites) == 5
    assert not [n for n in graph.node if n.op_type == "Softmax" and _tag(n) in sites]


def test_a_dual_engines_input_name_carries_its_alignment():
    assert dual.input_alignment(dual.aligned_input_name(4)) == 4
    assert dual.input_alignment("input") is None
    assert dual.input_alignment("input_aligned_x") is None


@pytest.mark.parametrize(
    ("low", "opt", "high", "message"),
    [
        ((64, 64), (512, 512), (1088, 1920), None),
        ((64, 64), (512, 500), (1088, 1920), "dynamic DUAL engine's optimal size must"),
        ((64, 64), (2048, 512), (1088, 1920), "minimum <= optimal <= maximum"),
        # Shape Mode Fixed on a dynamic ONNX: one size, a fixed engine
        ((256, 250), (256, 250), (256, 250), r"^A fixed DUAL engine's size must be"),
    ],
)
def test_a_dynamic_engines_profile_keeps_to_the_onnxs_alignment(
    low: tuple[int, int],
    opt: tuple[int, int],
    high: tuple[int, int],
    message: str | None,
):
    manifest = {
        "specialization": {
            "dynamic": True,
            "alignment": 64,
            "channels": 128,
            "unshuffle": False,
        }
    }
    if message is None:
        dual.check_profile(manifest, low, opt, high)
    else:
        with pytest.raises(ValueError, match=message):
            dual.check_profile(manifest, low, opt, high)


@pytest.mark.parametrize(
    ("unshuffle", "high", "refused"),
    [
        # 3 * H * W * 128 against 2**31: 2304 x 2368 fits, 2304 x 2432 does not
        (False, (2304, 2368), False),
        (False, (2304, 2432), True),
        # with pixel unshuffle the trunk is half the size on each axis
        (True, (4608, 4736), False),
        (True, (4608, 4864), True),
    ],
)
def test_a_dynamic_engines_maximum_keeps_to_32_bit_indexing(
    unshuffle: bool, high: tuple[int, int], refused: bool
):
    manifest = {
        "specialization": {
            "dynamic": True,
            "alignment": 64,
            "channels": 128,
            "unshuffle": unshuffle,
        }
    }
    low = (64, 64)
    if refused:
        with pytest.raises(ValueError, match="32-bit indexing"):
            dual.check_profile(manifest, low, low, high)
    else:
        dual.check_profile(manifest, low, low, high)


@pytest.mark.parametrize("dynamic", [False, True])
def test_the_build_settings_reach_the_engine_worker(
    monkeypatch: pytest.MonkeyPatch, dynamic: bool
):
    calls: list[list[str]] = []

    def child(args: list[str], *_: object) -> str:
        calls.append(args)
        Path(args[3]).write_bytes(b"engine")
        return ""

    monkeypatch.setattr(dual, "run_child", child)
    key = "c128" if dynamic else "c128_h256_w256"
    spec = {"dynamic": dynamic, "plugin_key": key, "alignment": 4}
    profile = ((64, 64), (256, 256), (512, 512)) if dynamic else None
    engine = dual.build_engine(
        b"onnx",
        {"specialization": spec},
        0,
        profile,
        workspace_gib=12.5,
        optimization_level=5,
        tf32=True,
        sparse_weights=True,
        tiling_optimization="full",
    )
    assert engine == b"engine"
    ((_, _, _, _, gpu, plugin, *rest),) = calls
    assert (gpu, plugin) == ("0", key)
    sizes = ["64x64", "256x256", "512x512", "4"] if dynamic else []
    assert rest == ["12.5", "5", "1", "1", "full", *sizes]


@pytest.mark.parametrize("keys", [(), ("context",), ("context", "local", "retrieval")])
def test_an_onnx_from_before_neighborhood_attention_builds_with_a_warning(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
    keys: tuple[str, ...],
):
    def child(args: list[str], *_: object) -> str:
        Path(args[3]).write_bytes(b"engine")
        return ""

    monkeypatch.setattr(dual, "run_child", child)
    manifest: dict[str, object] = {
        "specialization": {"plugin_key": "c128_h256_w256", "alignment": 4}
    }
    manifest.update(dict.fromkeys(keys, "na-v1"))
    assert dual.build_engine(b"onnx", manifest, 0) == b"engine"
    warned = [
        r.getMessage()
        for r in caplog.records
        if "without neighborhood attention" in r.getMessage()
    ]
    missing = [key for key in dual.NA_KEYS if key not in keys]
    assert len(warned) == bool(missing)
    if missing:
        assert f"at its {', '.join(missing)} sites" in warned[0]


def test_a_routed_export_keeps_its_largest_tensor_to_32_bit_indexing(
    monkeypatch: pytest.MonkeyPatch,
):
    # A 2x Light trunk of 2048 x 2400 (input 4096 x 4800): its qkv, 3 * H * W * C, is
    # under 2^31 elements, the routed convolution's 4 * H * W * C (base and three
    # expert differences) is not. By formula only: no export or build that large.
    monkeypatch.syspath_prepend(str(dual.VENDOR))
    spec = importlib.import_module("scripts.dual_tensorrt.spec")
    export = importlib.import_module("scripts.dual_tensorrt.export")
    _, model = export.make_model("dual_light", 2)
    parts = spec.routed_parts(model)
    assert parts == 4
    trunk = (2048, 2400)
    spec.check_indexing(*trunk, 128)
    with pytest.raises(ValueError, match="32-bit indexing"):
        spec.check_indexing(*trunk, 128, parts)
    manifest = {
        "specialization": {
            "dynamic": True,
            "alignment": 64,
            "channels": 128,
            "unshuffle": True,
        }
    }
    low, high = (64, 64), (4096, 4800)
    dual.check_profile(manifest, low, low, high)
    with pytest.raises(ValueError, match="32-bit indexing"):
        dual.check_profile(
            {**manifest, "routing": "na-v1", "routed_parts": parts}, low, low, high
        )
