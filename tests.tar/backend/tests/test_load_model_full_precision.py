"""Load Model's full-precision source (packages/chaiNNer_pytorch/pytorch/io/load_model.py)
for models whose evaluation mode derives weights from others (SPAN's Conv3XC, SMoVSR's
rep convolutions), loaded in FP16 on a GPU: the weights Load Model derived are the same
on the GPU as on the CPU, so reading the file again in FP32 finds the weights it loaded
(SMoVSR failed this before the derived weights' tensors were held: SPAN derives none)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
import torch

# Load Model's package imports the native backend, which GitHub's checks do not build.
pytest.importorskip("nodes.impl._chainner_graph")

from packages.chaiNNer_pytorch.pytorch.io import load_model
from packages.chaiNNer_pytorch.settings import PyTorchSettings


def span() -> torch.nn.Module:
    from spandrel.architectures.SPAN.__arch.span import SPAN

    return SPAN(num_in_ch=3, num_out_ch=3, feature_channels=16, upscale=2)


def smovsr() -> torch.nn.Module:
    pytest.importorskip("spandrel.architectures.SMoVSR")
    from spandrel.architectures.SMoVSR import SMoVSR

    return SMoVSR(dim=8)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
@pytest.mark.parametrize("make", [span, smovsr])
def test_a_folding_model_loaded_on_a_gpu_in_fp16_has_its_full_precision_source(
    make: Any, tmp_path: Path
):
    torch.manual_seed(0)
    network = make()
    with torch.no_grad():
        for parameter in network.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05)
    path = tmp_path / "model.pth"
    torch.save(network.state_dict(), path)

    model = load_model.load_model(
        path, PyTorchSettings(use_cpu=False, use_fp16=True, gpu_index=0, budget_limit=0)
    )

    # The file is read again in FP32, not a reason why it cannot be ("no longer holds
    # the weights Load Model loaded")
    full = load_model.full_precision(model)
    assert not isinstance(full, str), full
    assert full is not None and full.model.state_dict().keys() == (
        model.model.state_dict().keys()
    )
