"""An engine set's part captures its CUDA graphs on a stream of its own
(nodes/impl/tensorrt/temporal_session.Part), not on the session's stream: a page-locked
block that a copy on the session's stream used (its frames and outputs) and that is freed
during the capture, by any thread or by a garbage collection, records an event on that
stream, which would join the graph ("CUDA error: invalid argument" at the next query).

On the CPU with stand-ins for TensorRT, CUDA's runtime and PyTorch's graphs; the GPU test
at the end frees such a block during a real capture, in each of the three ways; a part also holds
the garbage collector off during its capture, as a collection there can free other CUDA
objects (graphs, events, page-locked blocks) too."""

from __future__ import annotations

import contextlib
import gc
import sys
import threading
from collections.abc import Callable, Iterator
from importlib.util import find_spec
from types import ModuleType, SimpleNamespace
from typing import Any, cast

import numpy as np
import pytest
import torch

pytest.importorskip("cuda.bindings.runtime")

from cuda.bindings import runtime as real_cudart

from nodes.impl.tensorrt import temporal_session

SUCCESS = real_cudart.cudaError_t.cudaSuccess


class FakeEngine:
    num_io_tensors = 1
    device_memory_size_v2 = 0

    def __init__(self, log: list[tuple[str, Any]]) -> None:
        self.log = log

    def create_execution_context(self, _strategy: object) -> FakeContext:
        return FakeContext(self.log)

    def get_tensor_name(self, _index: int) -> str:
        return "x"

    def get_tensor_shape(self, _name: str) -> tuple[int, ...]:
        return (2,)

    def get_tensor_dtype(self, _name: str) -> str:
        return "FLOAT"


class FakeContext:
    def __init__(self, log: list[tuple[str, Any]]) -> None:
        self.log = log

    def set_tensor_address(self, _name: str, _address: int) -> bool:
        return True

    def execute_async_v3(self, stream: int) -> bool:
        self.log.append(("execute", stream))
        return True


class FakeStream:
    def __init__(self, handle: int) -> None:
        self.cuda_stream = handle

    def synchronize(self) -> None:
        pass


@pytest.fixture
def fakes(monkeypatch: pytest.MonkeyPatch) -> list[tuple[str, Any]]:
    """Stand-ins for TensorRT, CUDA's runtime streams and PyTorch's graphs and current
    stream; every call lands in the returned log."""
    log: list[tuple[str, Any]] = []
    handles = iter(range(100, 200))
    current: list[int] = [1]

    trt = ModuleType("tensorrt")
    trt.__dict__["ExecutionContextAllocationStrategy"] = SimpleNamespace(
        USER_MANAGED="user"
    )
    trt.__dict__["DataType"] = SimpleNamespace(
        FLOAT="FLOAT", HALF="HALF", BF16="BF16", BOOL="BOOL"
    )
    monkeypatch.setitem(sys.modules, "tensorrt", trt)

    cudart = ModuleType("cuda.bindings.runtime")

    def create(flags: object) -> tuple[Any, int]:
        handle = next(handles)
        log.append(("create", (handle, flags)))
        return SUCCESS, handle

    def destroy(handle: int) -> tuple[Any]:
        log.append(("destroy", handle))
        return (SUCCESS,)

    cudart.__dict__.update(
        cudaStreamCreateWithFlags=create,
        cudaStreamDestroy=destroy,
        cudaStreamNonBlocking=real_cudart.cudaStreamNonBlocking,
    )
    bindings = sys.modules["cuda.bindings"]
    monkeypatch.setitem(sys.modules, "cuda.bindings.runtime", cudart)
    monkeypatch.setattr(bindings, "runtime", cudart)

    class Graph:
        def capture_begin(self, **_kwargs: object) -> None:
            log.append(("capture_begin", current[-1]))

        def capture_end(self) -> None:
            log.append(("capture_end", current[-1]))

        def replay(self) -> None:
            log.append(("replay", current[-1]))

    @contextlib.contextmanager
    def stream(chosen: FakeStream) -> Iterator[None]:
        current.append(chosen.cuda_stream)
        try:
            yield
        finally:
            current.pop()

    monkeypatch.setattr(torch.cuda, "CUDAGraph", Graph)
    monkeypatch.setattr(torch.cuda, "stream", stream)
    monkeypatch.setattr(
        torch.cuda, "ExternalStream", lambda handle, device=None: FakeStream(handle)
    )
    monkeypatch.setattr(torch.cuda, "current_device", lambda: 0)
    runtime = SimpleNamespace(deserialize_cuda_engine=lambda _data: FakeEngine(log))
    log.append(("runtime", runtime))
    return log


def part_of(log: list[tuple[str, Any]]) -> temporal_session.Part:
    runtime = next(value for kind, value in log if kind == "runtime")
    return temporal_session.Part(runtime, b"engine", "prefix", "RDUAL")


def test_a_part_captures_on_its_own_stream_and_replays_on_the_sessions(
    fakes: list[tuple[str, Any]],
):
    part = part_of(fakes)
    session = cast(torch.cuda.Stream, FakeStream(1))
    tensors = {"x": torch.zeros(2)}
    with torch.cuda.stream(session):
        for key in ("slot 0", "slot 1", "slot 0", "slot 1"):
            part.call(key, tensors, session)
    part.close()
    created = [value[0] for kind, value in fakes if kind == "create"]
    events = [(kind, value) for kind, value in fakes if kind not in ("runtime",)]
    # One stream for the part, made at its start, released at its close.
    assert len(created) == 1 and created[0] != session.cuda_stream
    own = created[0]
    assert events == [
        ("create", (own, real_cudart.cudaStreamNonBlocking)),
        # Each key: one run on the session's stream, then its capture on the part's.
        ("execute", 1),
        ("capture_begin", own),
        ("execute", own),
        ("capture_end", own),
        ("execute", 1),
        ("capture_begin", own),
        ("execute", own),
        ("capture_end", own),
        # Later calls replay on the session's stream, in the session's order.
        ("replay", 1),
        ("replay", 1),
        ("destroy", own),
    ]


def test_parts_of_many_windows_and_runs_make_one_stream_each(
    fakes: list[tuple[str, Any]],
):
    session = cast(torch.cuda.Stream, FakeStream(1))
    tensors = {"x": torch.zeros(2)}
    for _ in range(3):  # three runs, each a session of two parts
        parts = [part_of(fakes) for _ in range(2)]
        with torch.cuda.stream(session):
            for window in range(5):
                for part in parts:
                    part.call(("slot", window % 2), tensors, session)
        for part in parts:
            part.close()
    created = [value[0] for kind, value in fakes if kind == "create"]
    destroyed = [handle for kind, handle in fakes if kind == "destroy"]
    assert len(created) == 6 and sorted(destroyed) == sorted(created)


def _cuda_and_tensorrt() -> bool:
    return torch.cuda.is_available() and find_spec("tensorrt") is not None


class _Cycle:
    def __init__(self, value: object) -> None:
        self.value = value
        self.me = self


def _identity_engine() -> bytes:
    """A TensorRT engine of one tiny element-wise layer, built in this process."""
    import tensorrt as trt

    logger = trt.Logger(trt.Logger.ERROR)
    builder = trt.Builder(logger)
    network = builder.create_network(0)
    x = network.add_input("x", trt.float32, (1, 3, 8, 8))
    layer = network.add_activation(x, trt.ActivationType.RELU)
    layer.get_output(0).name = "y"
    network.mark_output(layer.get_output(0))
    config = builder.create_builder_config()
    data = builder.build_serialized_network(network, config)
    assert data is not None
    return bytes(data)


@pytest.mark.skipif(not _cuda_and_tensorrt(), reason="needs CUDA and TensorRT")
@pytest.mark.parametrize("way", ["another thread", "the capturing thread", "gc"])
def test_a_page_locked_block_freed_during_the_capture_leaves_it_whole(way: str):
    # A page-locked output that a copy on the session's stream used is freed while the
    # part captures its graph; then a page-locked allocation and the graph's replay.
    import tensorrt as trt

    from nodes.impl.pytorch.utils import host_image, to_host

    device = torch.device("cuda", 0)
    runtime = trt.Runtime(trt.Logger(trt.Logger.ERROR))
    part = temporal_session.Part(runtime, _identity_engine(), "prefix", "RDUAL")
    session = torch.cuda.Stream(device=device)
    tensors = {
        "x": torch.rand(1, 3, 8, 8, device=device) - 0.5,
        "y": torch.empty(1, 3, 8, 8, device=device),
    }
    with torch.cuda.stream(session):
        output = to_host(torch.rand(3, 64, 64, device=device))
    host_image(output)
    held: list[object] = [output]
    del output
    if way == "gc":
        _Cycle(held.pop())
    torch.cuda.synchronize()

    free: Callable[[], None]
    if way == "another thread":

        def free() -> None:
            thread = threading.Thread(target=held.clear)
            thread.start()
            thread.join()

    elif way == "the capturing thread":
        free = held.clear
    else:

        def free() -> None:
            # Allocations past the collector's threshold, as any Python code makes: an
            # automatic collection would free the block (and any other garbage) here.
            thresholds = gc.get_threshold()
            gc.set_threshold(1, 1, 1)
            try:
                for _ in range(1000):
                    _Cycle([])
            finally:
                gc.set_threshold(*thresholds)

    context = part.context

    class Freeing:
        """The part's context, freeing the block from inside the capture."""

        def __getattr__(self, name: str) -> object:
            return getattr(context, name)

        def execute_async_v3(self, stream: int) -> bool:
            if torch.cuda.is_current_stream_capturing():
                free()
            return context.execute_async_v3(stream)

    part.context = Freeing()
    try:
        with torch.cuda.stream(session):
            part.call("slot", tensors, session)
            later = torch.empty(1 << 16, pin_memory=True)
            tensors["y"].zero_()
            part.call("slot", tensors, session)
        session.synchronize()
        np.testing.assert_array_equal(
            tensors["y"].cpu().numpy(), tensors["x"].clamp(min=0).cpu().numpy()
        )
        del later
    finally:
        part.context = context
        part.close()
