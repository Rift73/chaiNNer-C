"""Upscale Image runs a model whose output changes in tiles (WHOLE_IMAGE_ONLY) on the
whole image where it can, and says once per chain when it does not."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

import numpy as np
import pytest
import torch
from onnx import TensorProto, helper
from spandrel import ImageModelDescriptor
from spandrel.architectures.WSR import WSRArch
from spandrel.architectures.WSR.__arch.wsr_arch import wsr_compact

# The node's modules load the native backend, which GitHub's checks do not build.
pytest.importorskip("nodes.impl._chainner_graph")

from api import NodeContext, Progress, SettingsParser
from nodes.impl.onnx.load import load_onnx_model, with_recorded_arch
from nodes.impl.onnx.model import OnnxGeneric
from nodes.impl.pytorch import auto_engine
from nodes.impl.upscale import whole_image
from nodes.impl.upscale.auto_split_tiles import (
    CUSTOM,
    ESTIMATE,
    MAX_TILE_SIZE,
    TILE_SIZE_256,
    TileSize,
)
from nodes.impl.upscale.basic_upscale import PaddingType
from packages.chaiNNer_onnx.onnx.processing import upscale_image as onnx_upscale_module
from packages.chaiNNer_onnx.onnx.processing.upscale_image import (
    upscale_image_node as onnx_upscale_image_node,
)
from packages.chaiNNer_pytorch.pytorch.processing import (
    upscale_image as pytorch_upscale_module,
)
from packages.chaiNNer_pytorch.pytorch.processing.upscale_image import (
    upscale_image_node as pytorch_upscale_image_node,
)


class Context:
    """The NodeContext members both Upscale Image nodes use, on the CPU, with the
    chain's cleanups and warnings kept."""

    node_id = "upscale"
    storage_dir = None
    aborted = False
    paused = False

    def __init__(self, settings: dict[str, object]) -> None:
        self.settings = SettingsParser(settings)
        progress = Progress.noop_progress()
        self.check_aborted = progress.check_aborted
        self.set_progress = progress.set_progress
        self.cleanups: set[Callable[[], None]] = set()
        self.warnings: list[str] = []

    def add_cleanup(self, fn: Callable[[], None], after: str = "chain") -> None:
        if after == "chain":
            self.cleanups.add(fn)

    def warn(self, message: str) -> None:
        self.warnings.append(message)

    def suspend(self) -> None:
        pass

    def end_chain(self) -> None:
        for fn in self.cleanups:
            fn()
        self.cleanups.clear()


def onnx_context() -> Context:
    return Context({"execution_provider": "CPUExecutionProvider"})


def mean_model(arch: str | None) -> OnnxGeneric:
    """Adds the image's mean to it: the output of every tile differs from the whole
    image's, as a model whose context reaches past the tiles. `arch`: the architecture
    recorded as Convert To ONNX records it, or none."""
    image = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, "h", "w"])
    output = helper.make_tensor_value_info(
        "output", TensorProto.FLOAT, [1, 3, "h", "w"]
    )
    nodes = [
        helper.make_node("ReduceMean", ["input"], ["mean"], axes=[2, 3], keepdims=1),
        helper.make_node("Add", ["input", "mean"], ["output"]),
    ]
    graph = helper.make_graph(nodes, "mean", [image], [output])
    data = helper.make_model(
        graph, opset_imports=[helper.make_opsetid("", 13)], ir_version=8
    ).SerializeToString()
    if arch is not None:
        data = with_recorded_arch(data, arch, "fp32")
    model = load_onnx_model(data)
    assert isinstance(model, OnnxGeneric)
    return model


def image(h: int, w: int) -> np.ndarray:
    """Values below 0.5, so that adding the mean stays below the node's clip at 1."""
    return np.random.default_rng(0).random((h, w, 3), dtype=np.float32) * 0.5


def whole(img: np.ndarray) -> np.ndarray:
    return img + img.mean(axis=(0, 1), dtype=np.float64).astype(np.float32)


def run_onnx(
    context: Context, model: OnnxGeneric, img: np.ndarray, tile: TileSize
) -> tuple[np.ndarray, str]:
    return onnx_upscale_image_node(
        cast(NodeContext, context), img, model, tile, 256, False
    )


def test_both_routes_read_one_set():
    assert auto_engine.WHOLE_IMAGE_ONLY is whole_image.WHOLE_IMAGE_ONLY
    assert "WSR" in whole_image.WHOLE_IMAGE_ONLY


@pytest.mark.parametrize("size", [(600, 520), (389, 517)])
def test_a_recorded_wsr_onnx_runs_whole_at_the_default_tile_size(
    size: tuple[int, int],
):
    context = onnx_context()
    img = image(*size)
    output, tiles = run_onnx(context, mean_model("WSR"), img, TILE_SIZE_256)
    assert output.shape == img.shape
    np.testing.assert_allclose(output, whole(img), atol=1e-5)
    assert tiles == "Whole image"
    assert context.warnings == []


@pytest.mark.parametrize("arch", [None, "ESRGAN"])
def test_another_onnx_is_tiled_as_before(arch: str | None):
    context = onnx_context()
    img = image(600, 520)
    output, tiles = run_onnx(context, mean_model(arch), img, TILE_SIZE_256)
    assert tiles != "Whole image"
    assert np.abs(output - whole(img)).max() > 1e-3
    assert context.warnings == []


class ShortOfMemory(Exception):
    pass


def short_of_memory_from(
    monkeypatch: pytest.MonkeyPatch, height: int, width: int
) -> list[bool]:
    """The ONNX node's session fails as one out of memory does for any input of at
    least `height` x `width`; returns, per run of the session on an image, whether it
    failed."""
    runs: list[bool] = []
    get_session = onnx_upscale_module.get_onnx_session

    class Session:
        def __init__(self, session: Any) -> None:
            self.session = session

        def __getattr__(self, name: str) -> Any:
            return getattr(self.session, name)

        def run(self, outputs: Any, feeds: dict[str, np.ndarray]) -> Any:
            (feed,) = feeds.values()
            fails = feed.shape[2] >= height and feed.shape[3] >= width
            runs.append(fails)
            if fails:
                raise ShortOfMemory(
                    "[ONNXRuntimeError] : 6 : RUNTIME_EXCEPTION : Failed to allocate"
                    " memory for requested buffer of size 123"
                )
            return self.session.run(outputs, feeds)

    def get_onnx_session(*args: Any, **kwargs: Any) -> Any:
        return Session(get_session(*args, **kwargs))

    monkeypatch.setattr(onnx_upscale_module, "get_onnx_session", get_onnx_session)
    return runs


def test_a_whole_image_out_of_memory_falls_back_to_the_tile_size_and_warns_once(
    monkeypatch: pytest.MonkeyPatch,
):
    context = onnx_context()
    model = mean_model("WSR")
    img = image(600, 520)
    tiled, tiled_text = run_onnx(context, mean_model(None), img, TILE_SIZE_256)
    runs = short_of_memory_from(monkeypatch, *img.shape[:2])
    for _ in range(2):
        runs.clear()
        output, tiles = run_onnx(context, model, img, TILE_SIZE_256)
        np.testing.assert_array_equal(output, tiled)
        assert tiles == tiled_text
        # The whole image, then its tiles
        assert runs[0] and not any(runs[1:]) and len(runs) > 1
    assert len(context.warnings) == 1
    assert context.warnings[0] == (
        "Upscale Image runs this WSR model in 256 px tiles, its Tile Size: the whole"
        " image ran out of memory, and WSR's output changes in tiles."
    )
    # The next chain says it again.
    context.end_chain()
    run_onnx(context, model, img, TILE_SIZE_256)
    assert len(context.warnings) == 2


def test_no_tiling_out_of_memory_still_fails(monkeypatch: pytest.MonkeyPatch):
    from nodes.impl.upscale.auto_split_tiles import NO_TILING

    context = onnx_context()
    short_of_memory_from(monkeypatch, 64, 64)
    with pytest.raises(RuntimeError, match="ran out of memory"):
        run_onnx(context, mean_model("WSR"), image(64, 64), NO_TILING)
    assert context.warnings == []


def test_an_error_that_is_not_for_memory_is_not_retried_in_tiles(
    monkeypatch: pytest.MonkeyPatch,
):
    context = onnx_context()
    runs = short_of_memory_from(monkeypatch, 600, 520)
    monkeypatch.setattr(onnx_upscale_module, "is_out_of_memory", lambda e: False)
    with pytest.raises(RuntimeError) as raised:
        run_onnx(context, mean_model("WSR"), image(600, 520), TILE_SIZE_256)
    assert isinstance(raised.value.__cause__, ShortOfMemory)
    assert runs == [True]
    assert context.warnings == []


def tiny_wsr() -> ImageModelDescriptor:
    torch.manual_seed(0)
    model = WSRArch().load(wsr_compact(scale=2).state_dict())
    for _, v in model.model.named_parameters():
        v.requires_grad = False
    return model.eval()


def run_pytorch(
    context: Context, model: ImageModelDescriptor, img: np.ndarray, tile: TileSize
) -> tuple[np.ndarray, str]:
    custom = 32
    return pytorch_upscale_image_node(
        cast(NodeContext, context),
        img,
        model,
        False,
        model.scale,
        CUSTOM if tile > 0 else tile,
        tile if tile > 0 else custom,
        PaddingType.NONE,
        False,
        False,
    )


def pytorch_context() -> Context:
    return Context({"use_cpu": True, "use_fp16": False, "gpu_index": "0"})


def test_pytorch_warns_once_per_chain_for_a_numbered_tile_size_that_tiles():
    context = pytorch_context()
    model = tiny_wsr()
    img = image(64, 72)
    for _ in range(2):
        _, tiles = run_pytorch(context, model, img, TileSize(32))
        assert tiles != "Whole image"
    assert context.warnings == [
        (
            "Upscale Image runs this WSR model in tiles, as its Tile Size of 32 px"
            " says, and WSR's output changes in tiles: Auto or Maximum runs the whole"
            " image where it fits."
        )
    ]
    context.end_chain()
    run_pytorch(context, model, img, TileSize(32))
    assert len(context.warnings) == 2


def test_pytorch_warns_when_auto_tiles_for_want_of_memory(
    monkeypatch: pytest.MonkeyPatch,
):
    context = pytorch_context()
    monkeypatch.setattr(
        pytorch_upscale_module, "estimate_tile_size", lambda *args, **kwargs: 32
    )
    _, tiles = run_pytorch(context, tiny_wsr(), image(64, 72), ESTIMATE)
    assert tiles != "Whole image"
    assert context.warnings == [
        (
            "Upscale Image runs this WSR model in tiles, as the whole image does not"
            " fit in memory, and WSR's output changes in tiles."
        )
    ]


@pytest.mark.parametrize("tile", [ESTIMATE, MAX_TILE_SIZE, TileSize(128)])
def test_pytorch_is_silent_when_the_image_runs_whole(tile: TileSize):
    context = pytorch_context()
    _, tiles = run_pytorch(context, tiny_wsr(), image(64, 72), tile)
    assert tiles == "Whole image"
    assert context.warnings == []
