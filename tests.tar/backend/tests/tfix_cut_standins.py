"""Run by test_tensorrt_tfix_cut_cpu.py in a process of its own: Temporal Fix's real
window part exported at HEIGHT x WIDTH, cut at its direct ops (tfix_cut.cut) with only
those ops lowered, and its pieces run one after the other in ONNX Runtime, each kernel's
output taken from the whole graph's own chain. Prints a JSON line: the kernels, the
order, and per piece whether every tensor it gives equals the whole graph's.

Where Triton (or TensorRT's plugin module) is not installed, stand-ins take their place:
only the matchers and the cut run, never a kernel.

    python tfix_cut_standins.py HEIGHT WIDTH"""

from __future__ import annotations

import importlib.util
import json
import sys
from collections import OrderedDict
from unittest import mock

import numpy as np
import onnx
import torch
from onnx import helper

STAND_INS = (
    "triton",
    "triton.language",
    "triton.compiler",
    "triton.backends",
    "triton.backends.compiler",
    "triton.runtime",
    "tensorrt",
    "tensorrt.plugin",
)


def install_stand_ins() -> None:
    """A stand-in module for each of STAND_INS that is not installed."""
    for name in STAND_INS:
        try:
            present = importlib.util.find_spec(name) is not None
        except ModuleNotFoundError:
            present = False
        if not present:
            sys.modules[name] = mock.MagicMock()
    triton = sys.modules.get("triton")
    if isinstance(triton, mock.MagicMock):
        triton.jit = lambda fn=None, **_: fn if fn is not None else (lambda f: f)


def run(model: onnx.ModelProto, feeds: dict, outputs: list[str], types: dict) -> dict:
    import onnxruntime as ort

    graph = onnx.ModelProto()
    graph.CopyFrom(model)
    del graph.graph.output[:]
    for name in outputs:
        graph.graph.output.append(
            helper.make_tensor_value_info(name, types[name], None)
        )
    session = ort.InferenceSession(
        graph.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    wanted = {i.name for i in session.get_inputs()}
    given = {k: v for k, v in feeds.items() if k in wanted}
    return dict(zip(outputs, session.run(outputs, given), strict=True))


def main(height: int, width: int) -> None:
    install_stand_ins()
    from nodes.impl.tensorrt import temporal_fix_split, tfix_aot, tfix_cut
    from nodes.impl.tensorrt.dual_aot import Lowered
    from vendor.temporalfix.temporalfix_arch import temporalfix_arch

    torch.manual_seed(0)
    network = temporalfix_arch(fixed_hw=(height + height % 2, width + width % 2))
    state = OrderedDict((k, v.clone()) for k, v in network.state_dict().items())
    _, window = temporal_fix_split.parts(state, height, width, "cpu")
    lowered = tfix_aot.lower(window)
    direct = [p for p in lowered.plugins if p.op.startswith(tfix_aot.DIRECT)]
    plain = Lowered(window, direct, {})
    found = tfix_cut.cut(plain)
    if found is None:
        print(json.dumps({"kernels": []}))
        return
    inferred = onnx.shape_inference.infer_shapes(window, data_prop=True).graph
    types = {
        v.name: v.type.tensor_type.elem_type
        for v in [*inferred.value_info, *inferred.input, *inferred.output]
    }
    rng = np.random.default_rng(0)
    feeds: dict[str, np.ndarray] = {}
    for value in window.graph.input:
        dims = [d.dim_value for d in value.type.tensor_type.shape.dim]
        half = value.type.tensor_type.elem_type == onnx.TensorProto.FLOAT16
        feeds[value.name] = rng.random(dims, dtype=np.float32).astype(
            np.float16 if half else np.float32
        )
    given = sorted(
        {o.name for p in found.pieces for o in p.lowered.model.graph.output}
        | {k.outputs[0] for k in found.kernels}
    )
    whole = run(window, feeds, given, types)
    values = dict(feeds)
    pieces = {p.name: p for p in found.pieces}
    equal = {}
    for step in found.order:
        if step not in pieces:
            # a kernel: its output as the whole graph's chain computes it
            values[step] = whole[step]
            continue
        model = pieces[step].lowered.model
        outputs = [o.name for o in model.graph.output]
        got = run(model, values, outputs, types)
        equal[step] = all(np.array_equal(got[n], whole[n]) for n in outputs)
        values.update(got)
    print(
        json.dumps(
            {
                "kernels": [k.op.split("_s")[0] for k in found.kernels],
                "order": found.order,
                "equal": equal,
            }
        )
    )


if __name__ == "__main__":
    main(int(sys.argv[1]), int(sys.argv[2]))
