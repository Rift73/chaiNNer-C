"""RDUAL's AOT plugins' graph lowering (nodes/impl/tensorrt/rdual_aot.py); no GPU: the
plugins are registered apart from the lowering."""

from __future__ import annotations

import numpy as np
import onnx
import pytest
from onnx import TensorProto, helper, numpy_helper

# Needs TensorRT and Triton (the engine build's environment).
rdual_aot = pytest.importorskip("nodes.impl.tensorrt.rdual_aot")

H, W = 8, 12
KEY = f"c128_h{H}_w{W}"
TRT = {"domain": "trt", "plugin_version": "1", "plugin_namespace": ""}


def _value(name: str, kind: int, shape: list[int]) -> onnx.ValueInfoProto:
    return helper.make_tensor_value_info(name, kind, shape)


def _fusion_model(with_norm: bool = False) -> onnx.ModelProto:
    """A key/value warp feeding the temporal attention, as rdual_export emits them,
    optionally after one of DUAL's Norm nodes."""
    n = H * W
    nodes = []
    kv_input = "kv"
    if with_norm:
        nodes.append(
            helper.make_node(
                f"DualNorm_{KEY}_TRT",
                ["x", "gamma", "beta"],
                ["normed", "normed_unused_1"],
                name="norm",
                residual=0,
                epsilon=1e-5,
                **TRT,
            )
        )
        nodes.append(helper.make_node("MatMul", ["normed", "wkv"], ["kv"]))
    nodes += [
        helper.make_node(
            "RDUALFlowKV",
            [kv_input, "coords"],
            ["warped"],
            name="warp",
            height=H,
            width=W,
            **TRT,
        ),
        helper.make_node(
            "RDUALTemporal",
            ["q", "k", "v", "table", "null_key", "null_bias", "slot_bias", "valid"],
            ["attended", "attended_unused_1"],
            name="temporal",
            height=H,
            width=W,
            slots=1,
            radius=3,
            **TRT,
        ),
    ]
    initializers = [
        numpy_helper.from_array(np.zeros((7, 7, 4), np.float32), "table"),
        numpy_helper.from_array(np.zeros((1, 4, 1), np.float32), "null_bias"),
        numpy_helper.from_array(np.zeros((1, 4), np.float32), "slot_bias"),
    ]
    inputs = [
        _value("coords", TensorProto.FLOAT, [1, 2, H, W]),
        _value("q", TensorProto.BFLOAT16, [1, 4, n, 32]),
        _value("k", TensorProto.BFLOAT16, [1, 1, 4, n, 32]),
        _value("v", TensorProto.BFLOAT16, [1, 1, 4, n, 32]),
        _value("null_key", TensorProto.BFLOAT16, [4, 32]),
        _value("valid", TensorProto.BOOL, [1, 1]),
    ]
    if with_norm:
        inputs += [
            _value("x", TensorProto.BFLOAT16, [1, H, W, 128]),
            _value("wkv", TensorProto.BFLOAT16, [128, 256]),
        ]
        initializers += [
            numpy_helper.from_array(np.ones(128, np.float32), "gamma"),
            numpy_helper.from_array(np.zeros(128, np.float32), "beta"),
        ]
    else:
        inputs.append(_value("kv", TensorProto.BFLOAT16, [1, H, W, 256]))
    graph = helper.make_graph(
        nodes,
        "fusion",
        inputs,
        [
            _value("warped", TensorProto.BFLOAT16, [2, 1, 4, n, 32]),
            _value("attended", TensorProto.FLOAT, [1, 4, n, 32]),
        ],
        initializers,
    )
    return helper.make_model(graph, opset_imports=[helper.make_opsetid("", 20)])


def _flow_model() -> onnx.ModelProto:
    """The flow part's plugin nodes as rdual_export writes them: the global matching,
    then one correlation lookup (window, then sample)."""
    c, n = 64, H * W
    nodes = [
        helper.make_node(
            "RDUALMatch",
            ["q", "k", "g"],
            ["matched"],
            name="match",
            batch=2,
            n=n,
            channels=c,
            **TRT,
        ),
        helper.make_node(
            "RDUALCorrWindow",
            ["f0", "f1", "flow"],
            ["window"],
            name="window",
            batch=2,
            height=H,
            width=W,
            channels=c,
            half=1,
            **TRT,
        ),
        helper.make_node(
            "RDUALCorrSample",
            ["window", "flow"],
            ["corrs"],
            name="sample",
            batch=2,
            height=H,
            width=W,
            channels=c,
            half=1,
            **TRT,
        ),
    ]
    graph = helper.make_graph(
        nodes,
        "flow",
        [
            _value("q", TensorProto.FLOAT, [2, n, c]),
            _value("k", TensorProto.FLOAT, [2, n, c]),
            _value("g", TensorProto.FLOAT, [2, n, 2]),
            _value("f0", TensorProto.FLOAT16, [2, n, c]),
            _value("f1", TensorProto.FLOAT16, [2, n, c]),
            _value("flow", TensorProto.FLOAT, [2, 2, H, W]),
        ],
        [
            _value("matched", TensorProto.FLOAT, [2, n, 2]),
            _value("corrs", TensorProto.FLOAT, [2, 81, H, W]),
        ],
    )
    return helper.make_model(graph, opset_imports=[helper.make_opsetid("", 20)])


def _shapes(model: onnx.ModelProto) -> dict[str, tuple[int, list[int]]]:
    inferred = onnx.shape_inference.infer_shapes(model, strict_mode=True)
    return {
        value.name: (
            value.type.tensor_type.elem_type,
            [d.dim_value for d in value.type.tensor_type.shape.dim],
        )
        for value in [*inferred.graph.value_info, *inferred.graph.output]
    }


def test_rdual_s_nodes_lower_to_stand_ins_of_their_outputs_shapes():
    lowered = rdual_aot.lower(_fusion_model(), None)

    kinds = [node.op_type for node in lowered.model.graph.node]
    assert not {"RDUALFlowKV", "RDUALTemporal"} & set(kinds)
    shapes = _shapes(lowered.model)
    n = H * W
    assert shapes["warped"] == (TensorProto.BFLOAT16, [2, 1, 4, n, 32])
    assert shapes["attended"] == (TensorProto.FLOAT, [1, 4, n, 32])
    assert shapes["attended_unused_1"] == (TensorProto.FLOAT, [1, 4, n])
    assert [(p.op, p.inputs, p.outputs) for p in lowered.plugins] == [
        (rdual_aot.flow_kv_name(H, W), ["kv", "coords"], ["warped"]),
        (
            rdual_aot.temporal_name(H, W, 1, 3),
            ["q", "k", "v", "table", "null_key", "null_bias", "slot_bias", "valid"],
            ["attended", "attended_unused_1"],
        ),
    ]


def test_every_plugin_input_has_a_named_reader():
    lowered = rdual_aot.lower(_fusion_model(), None)

    needed = {name for plugin in lowered.plugins for name in plugin.inputs}
    assert set(lowered.readers.values()) == needed
    readers = {
        node.name for node in lowered.model.graph.node if node.op_type == "Identity"
    }
    assert set(lowered.readers) <= readers


def test_the_flow_s_plugins_lower_without_a_volume():
    lowered = rdual_aot.lower(_flow_model(), None)

    shapes = _shapes(lowered.model)
    assert shapes["window"] == (TensorProto.FLOAT, [2 * H * W, 128])
    assert shapes["corrs"] == (TensorProto.FLOAT, [2, 81, H, W])
    assert shapes["matched"] == (TensorProto.FLOAT, [2, H * W, 2])
    window, sample = rdual_aot.corr_names(2, H, W, 1)
    assert (window, sample) == (
        f"corr_window_b2_h{H}_w{W}_f16",
        f"corr_sample_b2_h{H}_w{W}_f16",
    )
    assert [(p.op, p.inputs) for p in lowered.plugins] == [
        (rdual_aot.match_name(2, H * W, 64), ["q", "k", "g"]),
        (window, ["f0", "f1", "flow"]),
        (sample, ["window", "flow"]),
    ]
    kinds = {node.op_type for node in lowered.model.graph.node}
    assert not kinds & set(rdual_aot.NODES)


def test_with_a_key_dual_s_plugins_lower_too_in_graph_order():
    lowered = rdual_aot.lower(_fusion_model(with_norm=True), KEY)

    kinds = {node.op_type for node in lowered.model.graph.node}
    assert not any(kind.startswith(("Dual", "RDUAL")) for kind in kinds)
    assert [p.op for p in lowered.plugins] == [
        f"norm_{KEY}",
        rdual_aot.flow_kv_name(H, W),
        rdual_aot.temporal_name(H, W, 1, 3),
    ]


def _routed_mean_model(neighbourhood: int = 96) -> onnx.ModelProto:
    """A routed convolution's neighborhood means as RDUAL's High Quality trunk parts
    hold them (TrunkGraph with routing_na: the vendored routed_conv): DualBoxMean over
    the NHWC trunk, FP32 out, into the router's LayerNorm."""
    node = helper.make_node(
        f"DualBoxMean_{KEY}_TRT",
        ["x"],
        ["means"],
        name="means",
        neighbourhood=neighbourhood,
        **TRT,
    )
    norm = helper.make_node(
        "LayerNormalization", ["means", "ones", "zeros"], ["normalized"], axis=-1
    )
    graph = helper.make_graph(
        [node, norm],
        "routed",
        [_value("x", TensorProto.BFLOAT16, [1, H, W, 128])],
        [_value("normalized", TensorProto.FLOAT, [1, H, W, 128])],
        [
            numpy_helper.from_array(np.ones(128, np.float32), "ones"),
            numpy_helper.from_array(np.zeros(128, np.float32), "zeros"),
        ],
    )
    return helper.make_model(graph, opset_imports=[helper.make_opsetid("", 20)])


def test_a_routed_part_s_window_means_lower_to_dual_s_box_mean_plugin():
    lowered = rdual_aot.lower(_routed_mean_model(), KEY)

    nodes = lowered.model.graph.node
    assert not any(n.op_type.startswith("Dual") for n in nodes)
    stand_in = next(n for n in nodes if n.output[0] == "means")
    assert stand_in.op_type == "Cast"
    assert [(p.op, p.inputs, p.outputs) for p in lowered.plugins] == [
        (f"boxmean_{KEY}", ["x"], ["means"])
    ]
    with pytest.raises(ValueError, match="neighborhood of 96"):
        rdual_aot.lower(_routed_mean_model(64), KEY)


def _dual_layer_model() -> onnx.ModelProto:
    """A local attention layer's tail as the exporter writes it, which DUAL's own
    lowering fuses as chains E and F: gate projection + bias -> Sigmoid -> x the
    attention output -> projection + bias -> residual add -> Norm -> FFN expand + bias
    -> GELU -> contraction + bias -> residual add -> Norm -> the next qkv + bias, that
    Norm output also read by the next gate (a Cast)."""
    c, shape = 128, [1, H, W]

    def norm(x: str, out: str) -> onnx.NodeProto:
        return helper.make_node(
            f"DualNorm_{KEY}_TRT",
            [x, "gamma", "beta"],
            [out, out + "_sigma"],
            name=out,
            residual=0,
            epsilon=1e-5,
            **TRT,
        )

    def weight(name: str, dims: list[int]) -> onnx.TensorProto:
        return numpy_helper.from_array(np.full(dims, 0.01, np.float32), name)

    nodes = [
        helper.make_node("MatMul", ["a", "wg"], ["ga"]),
        helper.make_node("Add", ["ga", "bg"], ["gb"]),
        helper.make_node("Sigmoid", ["gb"], ["gs"]),
        helper.make_node("Mul", ["attended", "gs"], ["g"]),
        helper.make_node("MatMul", ["g", "w1"], ["p"]),
        helper.make_node("Add", ["p", "b1"], ["pb"]),
        helper.make_node("Add", ["r", "pb"], ["s"]),
        norm("s", "n"),
        helper.make_node("MatMul", ["n", "w2"], ["e"]),
        helper.make_node("Add", ["e", "b2"], ["h"]),
        helper.make_node("Div", ["h", "c_div"], ["hd"]),
        helper.make_node("Erf", ["hd"], ["he"]),
        helper.make_node("Add", ["he", "c_add"], ["ha"]),
        helper.make_node("Mul", ["h", "c_mul"], ["hm"]),
        helper.make_node("Mul", ["hm", "ha"], ["gelu"]),
        helper.make_node("MatMul", ["gelu", "w3"], ["q"]),
        helper.make_node("Add", ["q", "b3"], ["qb"]),
        helper.make_node("Add", ["s", "qb"], ["s2"]),
        norm("s2", "n2"),
        helper.make_node("MatMul", ["n2", "wq"], ["qp"]),
        helper.make_node("Add", ["qp", "bq"], ["qkv"]),
        helper.make_node("Cast", ["n2"], ["n2_f32"], to=TensorProto.FLOAT),
    ]
    initializers = [
        weight("wg", [c, c]),
        weight("bg", [c]),
        weight("w1", [c, c]),
        weight("b1", [c]),
        weight("w2", [c, 2 * c]),
        weight("b2", [2 * c]),
        weight("w3", [2 * c, c]),
        weight("b3", [c]),
        weight("wq", [c, 3 * c]),
        weight("bq", [3 * c]),
        numpy_helper.from_array(np.ones(c, np.float32), "gamma"),
        numpy_helper.from_array(np.zeros(c, np.float32), "beta"),
        numpy_helper.from_array(np.array(1.4142135, np.float32), "c_div"),
        numpy_helper.from_array(np.array(1.0, np.float32), "c_add"),
        numpy_helper.from_array(np.array(0.5, np.float32), "c_mul"),
    ]
    graph = helper.make_graph(
        nodes,
        "dual_layer",
        [
            _value(name, TensorProto.FLOAT, [*shape, c])
            for name in ("a", "attended", "r")
        ],
        [
            _value("qkv", TensorProto.FLOAT, [*shape, 3 * c]),
            _value("n2_f32", TensorProto.FLOAT, [*shape, c]),
        ],
        initializers,
    )
    return helper.make_model(graph)


def test_rdual_keeps_chains_a_and_b_where_dual_fuses_chains_e_and_f():
    from nodes.impl.tensorrt import dual_aot

    rdual = [p.op for p in rdual_aot.lower(_dual_layer_model(), KEY).plugins]
    dual = [p.op for p in dual_aot.lower(_dual_layer_model(), KEY).plugins]

    assert rdual == [f"chaina_{KEY}", f"chainb_{KEY}"]
    assert dual == [f"chaine_{KEY}", f"chainf_{KEY}"]
