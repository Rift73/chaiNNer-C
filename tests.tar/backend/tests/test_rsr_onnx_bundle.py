"""RSR's ONNX bundle (nodes/impl/onnx/rdual_bundle.py, shared with RDUAL) through
Convert To ONNX, Save and Load Model, the other ONNX users and Build Engine, on the
CPU: the export's child and the engine build are stand-ins, except for one small real
conversion."""

from __future__ import annotations

import json
from collections import OrderedDict
from pathlib import Path
from typing import Any, cast

import onnx
import pytest
import torch

# The nodes' padding and helpers run in the native backend, which GitHub's checks do
# not build.
pytest.importorskip("nodes.impl._chainner_graph")
# spandrel before 0.4.2+c23 has no RSR.
pytest.importorskip("spandrel.architectures.RSR")

from spandrel.architectures.RSR import RSR, RSRArch
from test_tensorrt_rdual_nodes import (
    SETTINGS,
    Context,
    build_node,
    tensorrt_nodes,
    write_export,
)

from api import NodeContext
from nodes.impl.compressed_file import Compression
from nodes.impl.onnx import rdual_bundle
from nodes.impl.onnx.load import load_onnx_model
from nodes.impl.tensorrt import build_cache, rsr
from nodes.impl.tensorrt import memory as trt_memory
from nodes.impl.tensorrt.model import TemporalInfo
from nodes.impl.tensorrt.rdual_engine_set import unpack
from packages.chaiNNer_onnx.onnx.io.load_model import read_model
from packages.chaiNNer_onnx.onnx.io.save_model import save_model_node
from packages.chaiNNer_onnx.onnx.utility.optimize_model import optimize_model_node
from packages.chaiNNer_pytorch.pytorch.utility import convert_to_onnx
from packages.chaiNNer_pytorch.pytorch.utility.convert_to_onnx import (
    DualShape,
    OnnxDataType,
    Opset,
)

PARTS = ("prefix", "revcore", "fwdcore")
MANIFEST = {
    "height": 54,
    "width": 96,
    "scale": 2,
    "architecture": "RSR",
    "parts": {name: {"nodes": 1, "inputs": [], "outputs": []} for name in PARTS},
}


@pytest.fixture
def bundle(tmp_path: Path) -> bytes:
    return rdual_bundle.pack(write_export(tmp_path / "export", MANIFEST), 20)


@pytest.fixture(scope="module")
def descriptor() -> Any:
    torch.manual_seed(0)
    model = RSR(width=8, hidden=8, depth=9, gates=3, context_width=8, heads=1, scale=2)
    return RSRArch().load(model.state_dict())


def convert(model: Any, shape: DualShape, height: int, width: int) -> Any:
    return convert_to_onnx.convert_to_onnx_node(
        cast(NodeContext, Context()),
        model,
        OnnxDataType.FP32,
        Opset.OPSET_20,
        False,
        shape,
        height,
        width,
        False,
    )


def test_a_bundle_loads_as_a_fixed_fp16_rsr_onnx(bundle: bytes):
    model = load_onnx_model(bundle)
    info = model.info

    assert (info.arch, info.dtype, info.opset) == ("RSR", "fp16", 20)
    assert (info.fixed_input_height, info.fixed_input_width) == (54, 96)
    assert (info.scale_height, info.scale_width) == (2, 2)


def test_a_manifest_without_an_architecture_is_rdual_s():
    assert rdual_bundle.architecture({"height": 1}) == "RDUAL"
    assert rdual_bundle.architecture(MANIFEST) == "RSR"


def test_save_and_load_model_carry_an_rsr_bundle(bundle: bytes, tmp_path: Path):
    save_model_node(load_onnx_model(bundle), tmp_path, "rsr", True, Compression.ZSTD)
    loaded, _, _ = read_model(tmp_path / "rsr_compressed.onnx")

    assert loaded.bytes == bundle and loaded.info.arch == "RSR"


def test_other_onnx_users_refuse_an_rsr_bundle(bundle: bytes):
    from nodes.impl.onnx.session import create_inference_session

    model = load_onnx_model(bundle)
    with pytest.raises(ValueError, match="ONNX Runtime cannot use an RSR ONNX"):
        create_inference_session(model, 0, "CPUExecutionProvider")
    with pytest.raises(ValueError, match="Optimize Model cannot use an RSR ONNX"):
        optimize_model_node(model)


def test_convert_to_onnx_takes_rsr_at_a_fixed_size_only(descriptor: Any):
    with pytest.raises(ValueError, match="RSR converts to ONNX for one frame size"):
        convert(descriptor, DualShape.DYNAMIC, 54, 96)


def test_convert_to_onnx_refuses_an_aligned_rsr(monkeypatch: pytest.MonkeyPatch):
    # The flow variant has no ONNX design yet: refused before any export starts.
    torch.manual_seed(0)
    model = RSR(
        width=8,
        hidden=8,
        depth=9,
        gates=3,
        context_width=8,
        heads=1,
        scale=2,
        temporal_read="aligned",
    )
    # A file with its flow weights: the library refuses to load one without them.
    model.get_buffer("flow_loaded").fill_(True)
    aligned = RSRArch().load(model.state_dict())

    def no_export(*_args: Any, **_kwargs: Any) -> None:
        raise AssertionError("an aligned RSR must not be exported")

    monkeypatch.setattr(rsr, "export", no_export)
    with pytest.raises(ValueError, match=r"flow variant \(aligned read\) has no ONNX"):
        convert(aligned, DualShape.FIXED, 54, 96)


def test_convert_to_onnx_bundles_rsr_s_export_once(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    exports: list[tuple[int, int, int | None]] = []

    def export(
        _model: Any, height: int, width: int, folder: Path, gpu: Any, _context: Any
    ) -> dict:
        exports.append((height, width, gpu))
        manifest = {**MANIFEST, "height": height, "width": width}
        write_export(folder, manifest)
        return manifest

    monkeypatch.setattr(rsr, "export", export)

    onnx_model, fp_mode, opset = convert(descriptor, DualShape.FIXED, 55, 97)
    again = convert(descriptor, DualShape.FIXED, 55, 97)

    assert exports == [(55, 97, None)]
    assert again[0] is onnx_model
    assert (fp_mode, opset) == ("fp16", "opset20")
    info = onnx_model.info
    assert (info.fixed_input_height, info.fixed_input_width, info.arch) == (
        55,
        97,
        "RSR",
    )


def test_a_small_rsr_converts_saves_and_loads_with_its_three_onnx_parts(
    descriptor: Any, tmp_path: Path
):
    onnx_model, _, _ = convert(descriptor, DualShape.FIXED, 36, 44)
    save_model_node(onnx_model, tmp_path, "rsr", True, Compression.ZSTD)
    loaded, _, _ = read_model(tmp_path / "rsr_compressed.onnx")

    manifest = rdual_bundle.write(loaded.bytes, tmp_path / "export")

    assert (manifest["height"], manifest["width"], manifest["scale"]) == (36, 44, 2)
    assert rdual_bundle.architecture(manifest) == "RSR"
    assert list(manifest["parts"]) == list(PARTS)
    for name in PARTS:
        part = onnx.load(str(tmp_path / "export" / name / "model.onnx"))
        assert len(part.graph.node) == manifest["parts"][name]["nodes"]


def test_build_engine_builds_an_rsr_bundle_into_one_set(
    bundle: bytes, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(build_cache, "_memory", OrderedDict())
    monkeypatch.setattr(build_cache, "_building", {})
    calls: list[tuple[dict[str, Any], tuple[str, ...]]] = []

    def build(
        folder: Path, engines: Path, _gpu: int, _context: Any, settings: tuple[str, ...]
    ) -> None:
        manifest = json.loads((folder / "export.json").read_text(encoding="utf-8"))
        calls.append((manifest, settings))
        engines.mkdir()
        for i, name in enumerate(manifest["parts"]):
            (engines / f"{name}.engine").write_bytes(bytes([i + 1]) * 1000)

    def refuse(*_: Any) -> None:
        raise AssertionError("RDUAL's build ran for an RSR bundle")

    from nodes.impl.tensorrt import rdual

    monkeypatch.setattr(rsr, "build", build)
    monkeypatch.setattr(rsr, "recipe_identity", lambda: "recipe")
    monkeypatch.setattr(rdual, "build", refuse)
    monkeypatch.setattr(trt_memory, "get_cuda_compute_capability", lambda _: (12, 0))
    build_engine = tensorrt_nodes("utility.build_engine", "build_engine_node")
    monkeypatch.setattr(build_engine, "get_cuda_compute_capability", lambda _: (12, 0))
    monkeypatch.setattr(build_engine, "get_cuda_device_name", lambda _: "RTX 5090")
    monkeypatch.setattr(build_engine, "get_settings", lambda _: SETTINGS)

    engine = build_node(load_onnx_model(bundle))

    ((manifest, settings),) = calls
    assert manifest == MANIFEST and settings == ("8.0", "3", "1", "0", "fast")
    info, parts = unpack(engine.bytes)
    assert info.temporal == TemporalInfo("RSR", 54, 96, "", PARTS)
    assert (info.precision, info.scale) == ("fp16", 2)
    assert list(parts) == list(PARTS)
