"""SMoVSR's ONNX bundle (nodes/impl/onnx/rdual_bundle.py, shared with RDUAL and RSR)
through Convert To ONNX, Save and Load Model and Build Engine, on the CPU: one small real
conversion, and a build whose worker is a stand-in."""

from __future__ import annotations

import json
from collections import OrderedDict
from pathlib import Path
from typing import Any, cast

import onnx
import pytest
import torch

# The nodes' padding and helpers run in the native backend, which GitHub's checks do
# not build.
pytest.importorskip("nodes.impl._chainner_graph")
pytest.importorskip("spandrel.architectures.SMoVSR")

from spandrel.architectures.SMoVSR import SMoVSR, SMoVSRArch
from test_tensorrt_rdual_nodes import (
    SETTINGS,
    Context,
    build_node,
    tensorrt_nodes,
    write_export,
)

from api import NodeContext
from nodes.impl.compressed_file import Compression
from nodes.impl.onnx import rdual_bundle
from nodes.impl.onnx.load import load_onnx_model
from nodes.impl.tensorrt import build_cache, smovsr, smovsr_export
from nodes.impl.tensorrt import memory as trt_memory
from nodes.impl.tensorrt.model import TemporalInfo
from nodes.impl.tensorrt.rdual_engine_set import unpack
from packages.chaiNNer_onnx.onnx.io.load_model import read_model
from packages.chaiNNer_onnx.onnx.io.save_model import save_model_node
from packages.chaiNNer_pytorch.pytorch.utility import convert_to_onnx
from packages.chaiNNer_pytorch.pytorch.utility.convert_to_onnx import (
    DualShape,
    OnnxDataType,
    Opset,
)

PARTS = smovsr_export.PARTS
MANIFEST = {
    "height": 54,
    "width": 96,
    "scale": 2,
    "architecture": "SMoVSR",
    "parts": {name: {"nodes": 1, "inputs": [], "outputs": []} for name in PARTS},
}


@pytest.fixture(scope="module")
def descriptor() -> Any:
    torch.manual_seed(0)
    return SMoVSRArch().load(SMoVSR(dim=8).eval().state_dict())


def convert(model: Any, shape: DualShape, height: int, width: int) -> Any:
    return convert_to_onnx.convert_to_onnx_node(
        cast(NodeContext, Context()),
        model,
        OnnxDataType.FP32,
        Opset.OPSET_20,
        False,
        shape,
        height,
        width,
        False,
    )


def test_convert_to_onnx_takes_smovsr_at_a_fixed_size_only(descriptor: Any):
    with pytest.raises(ValueError, match="SMoVSR converts to ONNX for one frame size"):
        convert(descriptor, DualShape.DYNAMIC, 54, 96)


def test_a_small_smovsr_converts_saves_and_loads_with_its_three_onnx_parts(
    descriptor: Any, tmp_path: Path
):
    onnx_model, fp_mode, opset = convert(descriptor, DualShape.FIXED, 20, 24)
    save_model_node(onnx_model, tmp_path, "smovsr", True, Compression.ZSTD)
    loaded, _, _ = read_model(tmp_path / "smovsr_compressed.onnx")

    manifest = rdual_bundle.write(loaded.bytes, tmp_path / "export")

    assert (fp_mode, opset) == ("fp16", "opset20")
    info = loaded.info
    assert (info.arch, info.dtype, info.fixed_input_height, info.fixed_input_width) == (
        "SMoVSR",
        "fp16",
        20,
        24,
    )
    assert (manifest["height"], manifest["width"], manifest["scale"]) == (20, 24, 2)
    assert list(manifest["parts"]) == list(PARTS)
    for name in PARTS:
        part = onnx.load(str(tmp_path / "export" / name / "model.onnx"))
        assert len(part.graph.node) == manifest["parts"][name]["nodes"]


def test_build_engine_builds_an_smovsr_bundle_into_one_set(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    bundle = rdual_bundle.pack(write_export(tmp_path / "export", MANIFEST), 20)
    monkeypatch.setattr(build_cache, "_memory", OrderedDict())
    monkeypatch.setattr(build_cache, "_building", {})
    calls: list[tuple[dict[str, Any], tuple[str, ...]]] = []

    def build(
        folder: Path, engines: Path, _gpu: int, _context: Any, settings: tuple[str, ...]
    ) -> None:
        manifest = json.loads((folder / "export.json").read_text(encoding="utf-8"))
        calls.append((manifest, settings))
        engines.mkdir()
        for i, name in enumerate(manifest["parts"]):
            (engines / f"{name}.engine").write_bytes(bytes([i + 1]) * 1000)

    def refuse(*_: Any) -> None:
        raise AssertionError("another architecture's build ran for an SMoVSR bundle")

    from nodes.impl.tensorrt import rdual, rsr

    monkeypatch.setattr(smovsr, "build", build)
    monkeypatch.setattr(rsr, "build", refuse)
    monkeypatch.setattr(rdual, "build", refuse)
    monkeypatch.setattr(trt_memory, "get_cuda_compute_capability", lambda _: (12, 0))
    build_engine = tensorrt_nodes("utility.build_engine", "build_engine_node")
    monkeypatch.setattr(build_engine, "get_cuda_compute_capability", lambda _: (12, 0))
    monkeypatch.setattr(build_engine, "get_cuda_device_name", lambda _: "RTX 5090")
    monkeypatch.setattr(build_engine, "get_settings", lambda _: SETTINGS)

    engine = build_node(load_onnx_model(bundle))

    ((manifest, settings),) = calls
    assert manifest == MANIFEST and settings == ("8.0", "3", "1", "0", "fast")
    info, parts = unpack(engine.bytes)
    assert info.temporal == TemporalInfo("SMoVSR", 54, 96, "", PARTS)
    assert (info.precision, info.scale) == ("fp16", 2)
    assert list(parts) == list(PARTS)
