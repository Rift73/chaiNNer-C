"""Temporal Fix's engine worker's parse (nodes/impl/tensorrt/temporal_fix_worker.py): a
part without Triton is the exported graph as it is, with no plugin layer. Needs
TensorRT and a CUDA GPU (TensorRT's builder needs one; the network is only parsed); with
Triton the part gets its plugin."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import onnx
import pytest
import torch
from onnx import TensorProto, helper, numpy_helper

trt = pytest.importorskip("tensorrt")
temporal_fix_worker = pytest.importorskip("nodes.impl.tensorrt.temporal_fix_worker")
temporal_fix = pytest.importorskip("nodes.impl.tensorrt.temporal_fix")


def round_trip(path: Path) -> None:
    """A half-size map up 2x, low-passed and down 2x: a round trip tfix_aot lowers."""
    k = np.array([1.0, 4.0, 6.0, 4.0, 1.0]) / 16.0
    weight = np.outer(k, k)[None, None].astype(np.float16)
    nodes = [
        helper.make_node(
            "Constant",
            [],
            ["up_size"],
            value=numpy_helper.from_array(np.array([1, 1, 8, 12], np.int64)),
        ),
        helper.make_node(
            "Constant",
            [],
            ["down_size"],
            value=numpy_helper.from_array(np.array([1, 1, 4, 6], np.int64)),
        ),
        helper.make_node("Resize", ["x", "", "", "up_size"], ["up"], mode="linear"),
        helper.make_node(
            "Conv", ["up", "w"], ["low"], group=1, kernel_shape=[5, 5], pads=[2] * 4
        ),
        helper.make_node("Resize", ["low", "", "", "down_size"], ["y"], mode="linear"),
    ]
    graph = helper.make_graph(
        nodes,
        "round_trip",
        [helper.make_tensor_value_info("x", TensorProto.FLOAT16, [1, 1, 4, 6])],
        [helper.make_tensor_value_info("y", TensorProto.FLOAT16, [1, 1, 4, 6])],
        [numpy_helper.from_array(weight, "w")],
    )
    onnx.save(
        helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)]), path
    )


def parsed(path: Path) -> set:
    """The layer types of the worker's parse of a Temporal Fix part at `path`."""
    logger = trt.Logger(trt.Logger.ERROR)
    network = trt.Builder(logger).create_network(
        1 << int(trt.NetworkDefinitionCreationFlag.STRONGLY_TYPED)
    )
    lowered = temporal_fix_worker.lower(path)
    temporal_fix_worker.parse(network, logger, path, lowered)
    return {network.get_layer(i).type for i in range(network.num_layers)}


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
def test_without_triton_a_temporal_fix_part_is_built_as_exported(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # As where Triton is not installed: the worker gets no plugins module
    monkeypatch.setattr(temporal_fix, "plugins", lambda: None)
    model = tmp_path / "model.onnx"
    round_trip(model)
    kinds = parsed(model)
    assert trt.LayerType.PLUGIN_V3 not in kinds
    assert trt.LayerType.CONVOLUTION in kinds


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
def test_with_triton_the_round_trip_becomes_a_plugin(tmp_path: Path) -> None:
    if temporal_fix.plugins() is None:
        pytest.skip("needs Triton")
    model = tmp_path / "model.onnx"
    round_trip(model)
    assert trt.LayerType.PLUGIN_V3 in parsed(model)
