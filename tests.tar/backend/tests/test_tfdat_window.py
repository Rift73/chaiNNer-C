"""Upscale Image's temporal path for TFDAT and TFDATv2 (nodes/impl/pytorch/tfdat_window.py)
on the CPU: small models with every parameter random, against the model called directly
on each frame's clip."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import pytest
import torch

# spandrel before 0.4.2+c24 has no TFDAT.
pytest.importorskip("spandrel.architectures.TFDAT")
# The temporal path's padding runs in the native backend, which GitHub's checks do not
# build.
pytest.importorskip("nodes.impl._chainner_graph")

from spandrel import ImageModelDescriptor, ModelLoader
from spandrel.architectures.TFDAT import TFDAT, TFDATv2

from api import NodeContext
from nodes.impl.pytorch.temporal_models import is_temporal, pytorch_windows
from nodes.impl.pytorch.tfdat_window import TFDATWindows
from nodes.impl.upscale.temporal_window import temporal_upscale
from nodes.impl.upscale.tile_report import TileReport
from packages.chaiNNer_pytorch.pytorch.io.load_model import load_model
from packages.chaiNNer_pytorch.pytorch.utility.convert_to_ncnn import (
    convert_to_ncnn_node,
)
from packages.chaiNNer_pytorch.settings import PyTorchSettings

SIZE = (20, 28)
FRAMES = 11
CPU = PyTorchSettings(use_cpu=True, use_fp16=False, gpu_index=0, budget_limit=0)


def tiny(version: type[torch.nn.Module], clip_size: int = 5) -> torch.nn.Module:
    torch.manual_seed(0)
    model = version(
        scale=2,
        clip_size=clip_size,
        embed_dim=16,
        num_groups=1,
        depth_per_group=1,
        num_heads=2,
        mid_dim=16,
        flow_base_ch=8,
    )
    # Every parameter random: the zero-initialised flow heads, refinements and fusion
    # would make the flow 0 and every warp the identity.
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05)
    return model.eval()


@pytest.fixture(scope="module", params=[TFDAT, TFDATv2], ids=["TFDAT", "TFDATv2"])
def descriptor(request: pytest.FixtureRequest) -> Any:
    return ModelLoader().load_from_state_dict(tiny(request.param).state_dict())


@pytest.fixture(scope="module")
def video() -> list[np.ndarray]:
    rng = np.random.default_rng(0)
    base = rng.random((SIZE[0], SIZE[1] + FRAMES, 3), dtype=np.float32)
    # Each frame the one before moved by a pixel: motion, not noise.
    return [np.ascontiguousarray(base[:, t : t + SIZE[1]]) for t in range(FRAMES)]


class View:
    """The iteration view the temporal path reads: the loop's index, its frames
    `ahead` items ahead, and the state slot."""

    def __init__(self, frames: list[np.ndarray], ahead: int) -> None:
        self.frames = frames
        self.ahead = ahead
        self.index = 0
        self.unread = False
        self.state: object | None = None

    def lookahead(self, _input: int) -> int:
        return self.ahead

    def peek(self, _input: int, offset: int) -> np.ndarray | None:
        at = self.index + offset
        return (
            self.frames[at] if offset <= self.ahead and at < len(self.frames) else None
        )


def direct(descriptor: Any, frames: list[np.ndarray], index: int) -> np.ndarray:
    """The model called on frame `index`'s clip, the frames past the video's ends the
    nearest one, BGR HWC in 0..1."""
    side = descriptor.model.clip_size // 2
    clip = [
        torch.from_numpy(
            frames[min(max(index + k, 0), len(frames) - 1)][..., ::-1].copy()
        ).permute(2, 0, 1)
        for k in range(-side, side + 1)
    ]
    with torch.inference_mode():
        out = descriptor.model(torch.stack(clip)[None])[0]
    return out.clamp(0, 1).permute(1, 2, 0).flip(2).numpy()


def loop(descriptor: Any, frames: list[np.ndarray], ahead: int) -> list[np.ndarray]:
    view = View(frames, ahead)
    context = cast(NodeContext, SimpleNamespace(iteration=view))
    executor = TFDATWindows(descriptor, torch.device("cpu"))
    outputs = []
    for index, frame in enumerate(frames):
        view.index = index
        outputs.append(temporal_upscale(context, frame, executor, TileReport()))
    return outputs


@pytest.mark.parametrize("ahead", [5, 2, 1])
def test_every_frame_is_the_model_on_its_clip(
    descriptor: Any, video: list[np.ndarray], ahead: int
):
    # 5 and 2 frames ahead read every clip's frames after its centre; 1 cannot, and
    # the frame after the last one read repeats as at a video's end.
    outputs = loop(descriptor, video, ahead)
    for index, output in enumerate(outputs):
        if ahead >= 2:
            expected = direct(descriptor, video, index)
        else:
            seen = video[: index + 2]
            expected = direct(descriptor, seen, index)
        np.testing.assert_allclose(output, expected, rtol=0, atol=1e-6)


@pytest.mark.parametrize("ahead", [7, 4])
def test_a_clip_of_nine_reads_four_frames_each_side(
    video: list[np.ndarray], ahead: int
):
    descriptor = ModelLoader().load_from_state_dict(tiny(TFDATv2, 9).state_dict())
    assert descriptor.model.clip_size == 9
    outputs = loop(descriptor, video, ahead)
    for index, output in enumerate(outputs):
        np.testing.assert_allclose(
            output, direct(descriptor, video, index), rtol=0, atol=1e-6
        )


def test_a_still_image_is_its_frame_repeated(descriptor: Any, video: list[np.ndarray]):
    context = cast(NodeContext, SimpleNamespace(iteration=None))
    executor = TFDATWindows(descriptor, torch.device("cpu"))
    output = temporal_upscale(context, video[3], executor, TileReport())
    np.testing.assert_allclose(
        output, direct(descriptor, [video[3]], 0), rtol=0, atol=1e-6
    )


def test_load_model_reads_a_video_model_of_its_scale(descriptor: Any, tmp_path: Path):
    path = tmp_path / "model.pth"
    torch.save(descriptor.model.state_dict(), path)
    model = load_model(path, CPU)
    assert isinstance(model, ImageModelDescriptor)
    assert model.architecture.id == descriptor.architecture.id
    assert model.scale == 2
    assert is_temporal(model)
    # PyTorch's executor, without lighter modes or tiles, in FP32 on the CPU
    windows, lighter, tiles = pytorch_windows(model, CPU, 0)
    executor = windows()
    assert isinstance(executor, TFDATWindows)
    assert (lighter, tiles) == ((), False)
    assert executor.model.dtype == torch.float32
    assert executor.look_ahead == 2


def test_convert_to_ncnn_refuses_it(descriptor: Any):
    context = cast(NodeContext, SimpleNamespace())
    with pytest.raises(ValueError, match="a video model"):
        convert_to_ncnn_node(context, descriptor, False)
