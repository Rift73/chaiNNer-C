"""Temporal Fix's window cut at its directly launched kernels (nodes/impl/tensorrt/
tfix_cut.py), without a GPU: where a graph is cut, what each piece gives and receives,
and that a graph without such a kernel is not cut."""

from __future__ import annotations

import numpy as np
import onnx
import pytest
from onnx import TensorProto, helper, numpy_helper
from test_tensorrt_tfix_aot import _binomial, _conf_model, _model

# Needs TensorRT and Triton (the engine build's environment), as tfix_aot's own tests.
tfix_aot = pytest.importorskip("nodes.impl.tensorrt.tfix_aot")
tfix_cut = pytest.importorskip("nodes.impl.tensorrt.tfix_cut")


def _conf_then_conv(flow_after: bool) -> onnx.ModelProto:
    """The confidence input, then a convolution on it (y); with `flow_after`, the flow
    the input reads is made in the graph (a ReLU of the input "raw") and y adds it."""
    model = _conf_model()
    graph = model.graph
    weight = np.full((2, 25, 1, 1), 0.01, np.float16)
    graph.initializer.append(numpy_helper.from_array(weight, "head"))
    graph.node.append(helper.make_node("Conv", ["x", "head"], ["conv"]))
    s, h, w = 2, 4, 6
    if flow_after:
        (flow,) = [i for i in graph.input if i.name == "flow"]
        flow.name = "raw"
        graph.node.insert(0, helper.make_node("Relu", ["raw"], ["flow"]))
        graph.node.append(helper.make_node("Add", ["conv", "flow"], ["y"]))
    else:
        graph.node.append(helper.make_node("Identity", ["conv"], ["y"]))
    del graph.output[:]
    graph.output.append(
        helper.make_tensor_value_info("y", TensorProto.FLOAT16, [s, 2, h, w])
    )
    return model


def _names(values: list[onnx.ValueInfoProto]) -> list[str]:
    return [v.name for v in values]


def test_a_graph_without_a_direct_kernel_is_not_cut():
    lowered = tfix_aot.lower(_model(1, None, _binomial(1)))
    assert lowered.plugins
    assert tfix_cut.cut(lowered) is None


def test_the_confidence_input_cuts_the_graph_before_its_convolution():
    found = tfix_cut.cut(tfix_aot.lower(_conf_then_conv(flow_after=False)))
    assert found is not None
    (kernel,) = found.kernels
    assert kernel.op == tfix_aot.conf_input_name(2, 4, 6, 16)
    # The kernel reads only the graph's inputs: nothing runs before it
    (piece,) = found.pieces
    assert found.order == [kernel.outputs[0], piece.name]
    assert piece.rows == ["x"]
    graph = piece.lowered.model.graph
    assert _names(graph.input) == ["x"]
    assert _names(graph.output) == ["y"]
    assert piece.lowered.plugins == []
    onnx.checker.check_model(piece.lowered.model)
    assert tfix_cut.row_shapes(found.kernels) == {"x": [2, 25, 4, 6]}


def test_what_a_later_piece_reads_is_handed_on_by_the_piece_that_makes_it():
    found = tfix_cut.cut(tfix_aot.lower(_conf_then_conv(flow_after=True)))
    assert found is not None
    first, second = found.pieces
    (kernel,) = found.kernels
    assert found.order == [first.name, kernel.outputs[0], second.name]
    # The flow is made before the cut, read by the kernel and after it
    assert _names(first.lowered.model.graph.output) == ["flow"]
    assert sorted(_names(second.lowered.model.graph.input)) == ["flow", "x"]
    assert second.rows == ["x"]
    for piece in found.pieces:
        onnx.checker.check_model(piece.lowered.model)


def test_a_piece_s_inputs_take_the_shapes_the_pieces_before_gave():
    found = tfix_cut.cut(tfix_aot.lower(_conf_then_conv(flow_after=True)))
    assert found is not None
    model = found.pieces[1].lowered.model
    tfix_cut.shape_inputs(model, {"x": [2, 25, 4, 6]})
    (x,) = [v for v in model.graph.input if v.name == "x"]
    assert [d.dim_value for d in x.type.tensor_type.shape.dim] == [2, 25, 4, 6]


def _renamed(model: onnx.ModelProto, suffix: str) -> onnx.ModelProto:
    """`model` with every tensor and node name given `suffix`."""
    out = onnx.ModelProto()
    out.CopyFrom(model)
    graph = out.graph
    for node in graph.node:
        node.input[:] = [f"{n}{suffix}" if n else n for n in node.input]
        node.output[:] = [f"{n}{suffix}" for n in node.output]
        node.name = f"{node.name}{suffix}"
    for value in [*graph.input, *graph.output, *graph.initializer]:
        value.name = f"{value.name}{suffix}"
    return out


def _two_confidence_inputs() -> onnx.ModelProto:
    """Two confidence inputs whose convolutions are added: the piece after the second
    kernel reads the first one's output, which only the piece right after it may."""
    a, b = _renamed(_conf_model(), "_a"), _renamed(_conf_model(), "_b")
    weight = np.full((2, 25, 1, 1), 0.01, np.float16)
    nodes = [*a.graph.node, *b.graph.node]
    nodes += [
        helper.make_node("Conv", ["x_a", "head"], ["conv_a"]),
        helper.make_node("Conv", ["x_b", "head"], ["conv_b"]),
        helper.make_node("Add", ["conv_a", "conv_b"], ["y"]),
    ]
    graph = helper.make_graph(
        nodes,
        "two",
        [*a.graph.input, *b.graph.input],
        [helper.make_tensor_value_info("y", TensorProto.FLOAT16, [2, 2, 4, 6])],
        [
            *a.graph.initializer,
            *b.graph.initializer,
            numpy_helper.from_array(weight, "head"),
        ],
    )
    return helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])


def test_a_kernel_whose_output_a_later_piece_reads_is_left_out_of_the_cut():
    lowered = tfix_aot.lower(_two_confidence_inputs())
    first, second = (p for p in lowered.plugins if p.op.startswith(tfix_aot.DIRECT))
    assert first.outputs == ["x_a"] and second.outputs == ["x_b"]
    found = tfix_cut.cut(lowered)
    assert found is not None
    # Only the second kernel cuts; the first one's chain runs in an engine
    assert [k.op for k in found.kernels] == [second.op]
    for piece in found.pieces:
        assert not any(p.op.startswith(tfix_aot.DIRECT) for p in piece.lowered.plugins)
        onnx.checker.check_model(piece.lowered.model)
    (after,) = [p for p in found.pieces if p.rows]
    assert after.rows == ["x_b"]


def test_a_window_built_whole_has_no_direct_kernel_plugin():
    lowered = tfix_aot.lower(_conf_then_conv(flow_after=False))
    assert any(p.op.startswith(tfix_aot.DIRECT) for p in lowered.plugins)
    assert tfix_cut.whole(lowered).plugins == []
