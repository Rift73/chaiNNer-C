"""TFDAT's and TFDATv2's engine sets on the app side (nodes/impl/tensorrt/tfdat.py,
tfdat_export.py, tfdat_session.py): the export's channel attention and its graph run by
ONNX Runtime on the CPU against the model in FP32, the set's info and container, the
TensorRT Upscale Image's context items; and on a GPU, a small set built and run on the
temporal path against the model on each frame's clip."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import onnx
import pytest
import torch

pytest.importorskip("spandrel.architectures.TFDAT")
# The temporal path's padding runs in the native backend, which GitHub's checks do not
# build.
pytest.importorskip("nodes.impl._chainner_graph")

from spandrel import ImageModelDescriptor, ModelLoader
from spandrel.architectures.FDAT.__arch.fdat import FastChannelAttention
from spandrel.architectures.TFDAT import TFDAT, TFDATv2

from api import NodeContext
from nodes.impl.tensorrt import rdual, tfdat, tfdat_export, tfdat_session
from nodes.impl.tensorrt.model import TemporalInfo, TensorRTEngine, TensorRTEngineInfo
from nodes.impl.tensorrt.rdual_engine_set import pack, unpack
from nodes.impl.upscale.temporal_window import LOOK_AHEAD, WARM_UP, temporal_upscale
from nodes.impl.upscale.tile_report import TileReport
from packages.chaiNNer_tensorrt.tensorrt.processing.upscale_image import context_of

HEIGHT, WIDTH = 32, 48
FRAMES = 7


def tiny(
    version: type[torch.nn.Module], clip_size: int = 5, scale: int = 2
) -> torch.nn.Module:
    torch.manual_seed(0)
    model = version(
        scale=scale,
        clip_size=clip_size,
        embed_dim=16,
        num_groups=1,
        depth_per_group=1,
        num_heads=2,
        mid_dim=16,
        flow_base_ch=8,
    )
    # Every parameter random: the zero-initialised flow heads, refinements and fusion
    # would make the flow 0 and every warp the identity.
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05)
    return model.eval()


@pytest.fixture(scope="module", params=[TFDAT, TFDATv2], ids=["TFDAT", "TFDATv2"])
def descriptor(request: pytest.FixtureRequest) -> Any:
    return ModelLoader().load_from_state_dict(tiny(request.param).state_dict())


def clip(frames: int, seed: int = 1) -> torch.Tensor:
    """(1, frames * 3, HEIGHT, WIDTH): a picture moving a pixel a frame, not noise."""
    generator = torch.Generator().manual_seed(seed)
    base = torch.rand(3, HEIGHT, WIDTH + frames, generator=generator)
    return torch.cat([base[:, :, t : t + WIDTH] for t in range(frames)])[None]


@pytest.mark.parametrize("stable_norm", [False, True])
def test_the_split_channel_attention_is_the_attention(stable_norm: bool):
    torch.manual_seed(0)
    attention = FastChannelAttention(16, 2, stable_norm=stable_norm).eval()
    with torch.no_grad():
        attention.temp.mul_(torch.rand_like(attention.temp) * 4)
    x = torch.randn(1, 64 * 3, 16)
    with torch.no_grad():
        expected = attention(x, 8, 24)
        got = tfdat_export.SplitChannelAttention(attention)(x, 8, 24)
    torch.testing.assert_close(got, expected, rtol=1e-5, atol=1e-5)


def test_the_export_swaps_every_channel_attention(descriptor: Any):
    model = tfdat_export.for_export(copy.deepcopy(descriptor.model))

    assert not any(isinstance(m, FastChannelAttention) for m in model.modules())
    assert any(
        isinstance(m, tfdat_export.SplitChannelAttention) for m in model.modules()
    )


def test_the_part_runs_in_onnx_runtime_as_the_model(descriptor: Any, tmp_path: Path):
    ort = pytest.importorskip("onnxruntime")
    weights = rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    tfdat_export.main(
        descriptor.architecture.id,
        str(weights),
        str(tmp_path / "export"),
        str(HEIGHT),
        str(WIDTH),
    )
    manifest = json.loads((tmp_path / "export" / "export.json").read_text())
    assert manifest["architecture"] == descriptor.architecture.id
    assert manifest["clip_size"] == 5
    assert list(manifest["parts"]) == [tfdat_export.PART]
    graph = onnx.load(str(tmp_path / "export" / "clip" / "model.onnx"))
    types = {i.name: i.type.tensor_type.elem_type for i in graph.graph.input}
    types |= {o.name: o.type.tensor_type.elem_type for o in graph.graph.output}
    assert types == {"x": onnx.TensorProto.FLOAT, "output": onnx.TensorProto.FLOAT}

    x = clip(5)
    session = ort.InferenceSession(
        str(tmp_path / "export" / "clip" / "model.onnx"),
        providers=["CPUExecutionProvider"],
    )
    (got,) = session.run(None, {"x": x.numpy()})
    with torch.inference_mode():
        expected = descriptor.model(x.view(1, 5, 3, HEIGHT, WIDTH))
    assert got.shape == (1, 3, 2 * HEIGHT, 2 * WIDTH)
    # The part in FP16 against the model in FP32
    error = np.abs(got - expected.numpy())
    assert float(error.mean()) <= 2e-3
    assert float(error.max()) <= 3e-2


def test_set_info_carries_the_architecture_and_the_clip(
    monkeypatch: pytest.MonkeyPatch,
):
    # memory.py imports CUDA's bindings, which GitHub's checks do not install.
    pytest.importorskip("cuda.bindings.runtime")
    from nodes.impl.tensorrt import memory

    monkeypatch.setitem(sys.modules, "tensorrt", SimpleNamespace(__version__="11.4.0"))
    monkeypatch.setattr(memory, "get_cuda_compute_capability", lambda _i: (12, 0))
    manifest = {
        "height": HEIGHT,
        "width": WIDTH,
        "scale": 2,
        "clip_size": 9,
        "architecture": "TFDATv2",
        "parts": {tfdat_export.PART: {}},
    }
    info = tfdat.set_info(manifest, 0)

    assert info.temporal is not None
    assert info.temporal.architecture == "TFDATv2"
    assert info.temporal.clip_size == 9
    assert info.temporal.parts == (tfdat_export.PART,)


def engine_set(clip_size: int, architecture: str = "TFDATv2") -> TensorRTEngine:
    shape = (1, 3, HEIGHT, WIDTH)
    info = TensorRTEngineInfo(
        precision="fp16",
        input_channels=3,
        output_channels=3,
        scale=2,
        gpu_architecture="sm_120",
        tensorrt_version="11.4.0",
        has_dynamic_shapes=False,
        min_shape=shape,
        opt_shape=shape,
        max_shape=shape,
        temporal=TemporalInfo(
            architecture, HEIGHT, WIDTH, "", (tfdat_export.PART,), clip_size=clip_size
        ),
    )
    return pack({tfdat_export.PART: b"engine"}, info)


def test_a_set_keeps_its_clip_through_the_container():
    info, parts = unpack(engine_set(9).bytes)

    assert info.temporal is not None
    assert info.temporal.clip_size == 9
    assert parts == {tfdat_export.PART: b"engine"}


def test_the_engine_node_reads_the_clip_around_each_frame():
    assert context_of(engine_set(9)) == (4, 4)
    assert context_of(engine_set(5)) == (2, 2)
    # RSR's and RDUAL's sets, and anything else, keep the node's items
    assert context_of(engine_set(0, "RSR")) == (WARM_UP, LOOK_AHEAD)
    assert context_of(object()) == (WARM_UP, LOOK_AHEAD)


class View:
    """The iteration view the temporal path reads: the loop's index and its frames
    `ahead` items ahead."""

    def __init__(self, frames: list[np.ndarray], ahead: int) -> None:
        self.frames = frames
        self.ahead = ahead
        self.index = 0
        self.unread = False
        self.state: object | None = None

    def lookahead(self, _input: int) -> int:
        return self.ahead

    def peek(self, _input: int, offset: int) -> np.ndarray | None:
        at = self.index + offset
        return (
            self.frames[at] if offset <= self.ahead and at < len(self.frames) else None
        )


def engine_against_model(descriptor: Any) -> list[float]:
    """Each frame's mean difference between the model's set on the temporal path and
    the model in FP32 on the frame's clip, the edges' repeated frames included."""
    pytest.importorskip("tensorrt")
    from nodes.impl.tensorrt.tfdat_session import open_session

    video = clip(FRAMES)[0].view(FRAMES, 3, HEIGHT, WIDTH)
    frames = [np.ascontiguousarray(f.permute(1, 2, 0).flip(-1).numpy()) for f in video]
    engine = tfdat.build_set(descriptor, HEIGHT, WIDTH, 0)
    session = open_session(engine, 0)
    view = View(frames, 3)
    context = cast(NodeContext, SimpleNamespace(iteration=view))
    try:
        got = []
        for index, frame in enumerate(frames):
            view.index = index
            got.append(temporal_upscale(context, frame, session, TileReport()))
    finally:
        session.close()
    model = descriptor.model.float().eval()
    side = model.clip_size // 2
    scale = descriptor.scale
    errors = []
    for index, image in enumerate(got):
        indices = [min(max(index + k, 0), FRAMES - 1) for k in range(-side, side + 1)]
        with torch.inference_mode():
            out = model(video[indices][None])[0]
        reference = out.clamp(0, 1).permute(1, 2, 0).flip(-1).numpy()
        assert image.shape == reference.shape == (scale * HEIGHT, scale * WIDTH, 3)
        errors.append(float(np.abs(image - reference).mean()))
    return errors


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
def test_a_set_builds_and_matches_the_model_on_every_clip(descriptor: Any):
    # The FP16 engine against FP32
    assert max(engine_against_model(descriptor)) <= 2e-3


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
@pytest.mark.parametrize("scale", [1, 4])
@pytest.mark.parametrize("version", [TFDAT, TFDATv2], ids=["TFDAT", "TFDATv2"])
def test_a_set_of_each_checked_scale_matches_the_model(
    version: type[torch.nn.Module], scale: int
):
    descriptor = ModelLoader().load_from_state_dict(
        tiny(version, scale=scale).state_dict()
    )
    errors = engine_against_model(descriptor)
    assert max(errors) <= 2e-3


def test_use_tensorrt_engine_takes_the_checked_scale_only(descriptor: Any):
    from nodes.impl.pytorch.rdual_engine import model_unavailable
    from nodes.impl.pytorch.temporal_models import runtime

    assert runtime(descriptor.architecture.id) == (tfdat, tfdat_session)
    assert model_unavailable(descriptor) is None
    other = ModelLoader().load_from_state_dict(
        tiny(type(descriptor.model), scale=3).state_dict()
    )
    assert isinstance(other, ImageModelDescriptor)
    assert model_unavailable(other) == (
        f"{descriptor.architecture.id}'s engines are checked for (1, 2, 4) scale only."
    )
