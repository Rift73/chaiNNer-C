"""The RSR engine set's session (nodes/impl/tensorrt/rsr_session.py) on the CPU, with
stand-in engines that compute simple functions of their bindings: the calls a window
makes, the prefix work two windows share, the validity at a window's edges, and the
memory arithmetic. No GPU, TensorRT or CUDA graphs."""

from __future__ import annotations

import contextlib
from typing import Any, cast

import numpy as np
import pytest
import torch
from torch.nn import functional

# cuda-python comes with the TensorRT package's dependencies, not with the runtime.
pytest.importorskip("cuda.bindings.runtime")

from nodes.impl.tensorrt.rsr_session import RSRSession

HEIGHT, WIDTH, SCALE = 4, 6, 2
F16, F32 = torch.float16, torch.float32
STATE = ((1, 8, HEIGHT, WIDTH), F16)
CONTEXT = ((1, 16, 1, 2), F16)
VALID = ((1,), torch.bool)
IMAGE = ((1, 3, HEIGHT, WIDTH), F32)
ENCODED = {"current6": STATE, "c3": CONTEXT, "c4": CONTEXT}
SPECS: dict[str, dict[str, tuple[tuple[int, ...], torch.dtype]]] = {
    "prefix": {"x": IMAGE, **ENCODED},
    "revcore": {
        **ENCODED,
        "state_future": STATE,
        "valid_future": VALID,
        "state": STATE,
    },
    "fwdcore": {
        "x": IMAGE,
        **ENCODED,
        "state_past": STATE,
        "valid_past": VALID,
        "state_future": STATE,
        "valid_future": VALID,
        "output": ((1, 3, HEIGHT * SCALE, WIDTH * SCALE), F32),
        "state": STATE,
    },
}


def encode(x: torch.Tensor) -> torch.Tensor:
    return x.mean().half() * torch.ones(STATE[0], dtype=F16)


def step(
    current: torch.Tensor, past: torch.Tensor | None, future: torch.Tensor | None
) -> torch.Tensor:
    state = current.float()
    if past is not None:
        state = state + 0.5 * past.float()
    if future is not None:
        state = state + 0.25 * future.float()
    return state.half()


def image(x: torch.Tensor, state: torch.Tensor) -> torch.Tensor:
    return functional.interpolate(x, scale_factor=SCALE) + state.float().mean()


def prefix(t: dict[str, torch.Tensor]) -> None:
    t["current6"].copy_(encode(t["x"]))
    t["c3"].fill_(1)
    t["c4"].fill_(2)


def revcore(t: dict[str, torch.Tensor]) -> None:
    future = t["state_future"] if t["valid_future"].item() else None
    t["state"].copy_(step(t["current6"], None, future))


def fwdcore(t: dict[str, torch.Tensor]) -> None:
    past = t["state_past"] if t["valid_past"].item() else None
    future = t["state_future"] if t["valid_future"].item() else None
    t["state"].copy_(step(t["current6"], past, future))
    t["output"].copy_(image(t["x"], t["state"]))


OPS = {"prefix": prefix, "revcore": revcore, "fwdcore": fwdcore}


class FakePart:
    """A part whose engine is OPS[name] on its bindings, logging each call's graph key
    (part, slot and validity)."""

    def __init__(self, name: str, log: list[Any]) -> None:
        self.name = name
        self.log = log
        self.workspace = {"prefix": 64, "revcore": 256, "fwdcore": 128}[name]
        self.graphs: dict[Any, Any] = {}

    def spec(self, name: str) -> tuple[tuple[int, ...], torch.dtype]:
        return SPECS[self.name][name]

    def tensor(self, name: str, device: torch.device) -> torch.Tensor:
        shape, dtype = self.spec(name)
        return torch.empty(shape, dtype=dtype, device=device)

    def use_memory(self, memory: torch.Tensor) -> None:
        assert memory.numel() >= self.workspace

    def call(self, key: Any, tensors: dict[str, torch.Tensor], _stream: Any):
        assert set(tensors) == set(SPECS[self.name])
        for name, tensor in tensors.items():
            assert (tuple(tensor.shape), tensor.dtype) == self.spec(name)
        self.log.append(key)
        OPS[self.name](tensors)

    def close(self) -> None:
        self.graphs.clear()


class FakeStream:
    def wait_stream(self, _other: object) -> None:
        pass

    def synchronize(self) -> None:
        pass


@pytest.fixture
def log(monkeypatch: pytest.MonkeyPatch) -> list[Any]:
    monkeypatch.setattr(torch.cuda, "set_device", lambda *_: None)
    monkeypatch.setattr(torch.cuda, "current_stream", lambda *_: None)
    monkeypatch.setattr(torch.cuda, "stream", lambda _: contextlib.nullcontext())
    return []


def session(log: list[Any]) -> RSRSession:
    return RSRSession(
        cast(Any, {name: FakePart(name, log) for name in OPS}),
        None,
        4000,
        FakeStream(),
        torch.device("cpu"),
        (HEIGHT, WIDTH, SCALE),
        "set",
    )


@pytest.fixture(scope="module")
def clip() -> list[torch.Tensor]:
    generator = torch.Generator().manual_seed(0)
    return [torch.rand(3, HEIGHT, WIDTH, generator=generator) for _ in range(9)]


def reference(
    frames: list[torch.Tensor], keep: int, past: torch.Tensor | None
) -> tuple[list[np.ndarray], torch.Tensor]:
    """The library's run_window with the stand-ins' functions."""
    count = len(frames)
    x = [f[None] for f in frames]
    encoded = [encode(f) for f in x]
    reverse: list[torch.Tensor | None] = [None] * (count + 1)
    for t in range(count - 1, 0, -1):
        reverse[t] = step(encoded[t], None, reverse[t + 1])
    outputs = []
    state = past
    for t in range(keep):
        state = step(encoded[t], state, reverse[t + 1])
        outputs.append(as_image(image(x[t], state)))
    assert state is not None
    return outputs, state


def as_image(output: torch.Tensor) -> np.ndarray:
    return output[0].clamp(0, 1).permute(1, 2, 0).flip(2).numpy()


# Two windows as the app runs a clip of 9 frames reading 4 ahead: the first keeps all
# but its last frame, the second (at the clip's end) keeps all of its frames.
WINDOWS = ((0, 5, 4), (4, 5, 5))


def test_chained_windows_equal_the_reference(log: list[Any], clip: list[torch.Tensor]):
    s = session(log)
    expected_state = None
    past = None
    for first, count, keep in WINDOWS:
        frames = clip[first : first + count]
        outputs, state = s.run(frames, keep, past, first)
        expected, expected_state = reference(frames, keep, expected_state)
        assert len(outputs) == keep
        for got, want in zip(outputs, expected, strict=True):
            assert np.array_equal(s.to_image(got), want)
        assert torch.equal(state, expected_state)
        past = (state, frames[keep - 1])


def test_a_window_s_calls_and_their_validity(log: list[Any], clip: list[torch.Tensor]):
    s = session(log)
    first, count, keep = WINDOWS[0]
    state = s.run(clip[first : first + count], keep, None, first)[1]
    ring = len(s.slots)
    assert ring == count + 1

    # every frame encoded once; the reverse sweep from the last frame (no future) to
    # the second; the forward sweep over the kept frames, cold at the first, and
    # every kept frame here has a future
    assert log == [
        *(("prefix", i) for i in range(5)),
        ("revcore", 4, False),
        *(("revcore", i, True) for i in (3, 2, 1)),
        ("fwdcore", 0, False, True),
        *(("fwdcore", i, True, True) for i in (1, 2, 3)),
    ]

    log.clear()
    first, count, keep = WINDOWS[1]
    s.run(clip[first : first + count], keep, (state, clip[3]), first)

    # frame 4, which the first window encoded, is not encoded again; the carried
    # state is the past of the first frame; the clip's last frame has no future
    assert log == [
        *(("prefix", i % ring) for i in range(5, 9)),
        ("revcore", 8 % ring, False),
        *(("revcore", i % ring, True) for i in (7, 6, 5)),
        *(("fwdcore", i % ring, True, True) for i in (4, 5, 6, 7)),
        ("fwdcore", 8 % ring, True, False),
    ]


def test_a_cold_or_unrelated_window_encodes_every_frame(
    log: list[Any], clip: list[torch.Tensor]
):
    s = session(log)
    s.run(clip[0:5], 4, None, 0)
    log.clear()

    s.run(clip[4:9], 5, None, 4)

    assert [key for key in log if key[0] == "prefix"] == [
        ("prefix", i % 6) for i in range(4, 9)
    ]


def test_one_frame_alone_has_no_neighbours(log: list[Any], clip: list[torch.Tensor]):
    s = session(log)

    (output,), state = s.run(clip[:1], 1, None, 0)

    assert log == [("prefix", 0), ("fwdcore", 0, False, False)]
    expected, expected_state = reference(clip[:1], 1, None)
    assert np.array_equal(s.to_image(output), expected[0])
    assert torch.equal(state, expected_state)


def test_outputs_and_states_are_the_callers(log: list[Any], clip: list[torch.Tensor]):
    s = session(log)
    outputs, state = s.run(clip[0:5], 4, None, 0)
    images = [s.to_image(o).copy() for o in outputs]
    kept = state.clone()

    s.run(clip[4:9], 5, (state, clip[3]), 4)

    assert all(np.array_equal(s.to_image(o), i) for o, i in zip(outputs, images))
    assert torch.equal(state, kept)


def test_windows_and_frames_are_checked(log: list[Any], clip: list[torch.Tensor]):
    s = session(log)
    with pytest.raises(ValueError, match="cannot keep"):
        s.run(clip[:3], 4, None, 0)
    with pytest.raises(ValueError, match="RSR engine set takes 6x4"):
        s.convert(np.zeros((5, 6, 3), dtype=np.float32))


def test_the_memory_follows_the_bindings(log: list[Any]):
    s = session(log)

    state = 8 * HEIGHT * WIDTH * 2
    frame = 3 * HEIGHT * WIDTH * 4
    output = 3 * HEIGHT * SCALE * WIDTH * SCALE * 4
    # one working memory, the largest part's; the output binding, the zero state and
    # two output images
    assert s.memory.fixed == 4000 + 256 + output + state + 2 * output
    # a slot: its input, the prefix outputs, two states; and the converted frame
    assert s.memory.per_frame == frame + state + 2 * (16 * 2 * 2) + 2 * state + frame
    assert s.memory.carried == 2 * state
