"""Whether Temporal Fix's engine set has its plugins (nodes/impl/tensorrt/temporal_fix.py):
only a missing Triton leaves them out, and the set's key says which. No GPU."""

from __future__ import annotations

import builtins
from typing import Any

import pytest

temporal_fix = pytest.importorskip("nodes.impl.tensorrt.temporal_fix")

_import = builtins.__import__


def failing(name: str, error: BaseException) -> Any:
    """An __import__ under which importing `name` (as `from . import <name>`) raises."""

    def imports(target: str, *args: Any, **kwargs: Any) -> Any:
        fromlist = args[2] if len(args) > 2 else kwargs.get("fromlist")
        if fromlist and name in fromlist:
            raise error
        return _import(target, *args, **kwargs)

    return imports


def test_a_missing_triton_means_no_plugins(monkeypatch: pytest.MonkeyPatch) -> None:
    missing = ModuleNotFoundError("No module named 'triton'", name="triton")
    monkeypatch.setattr(builtins, "__import__", failing("tfix_aot", missing))
    assert temporal_fix.plugins() is None


def test_any_other_failure_to_import_the_plugins_is_raised(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    broken = ImportError("cannot import name 'resolved' from 'dual_aot'")
    # Triton itself imports (installed or not here): the failure is the plugins' own
    import_module = temporal_fix.importlib.import_module

    def triton_imports(name: str, *args: Any) -> Any:
        if name.partition(".")[0] == "triton":
            return object()
        return import_module(name, *args)

    monkeypatch.setattr(temporal_fix.importlib, "import_module", triton_imports)
    monkeypatch.setattr(builtins, "__import__", failing("tfix_aot", broken))
    with pytest.raises(ImportError, match="resolved"):
        temporal_fix.plugins()


def test_the_key_tells_a_set_with_plugins_from_one_without(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(temporal_fix, "plugins", lambda: None)
    without = temporal_fix.recipe_identity()
    monkeypatch.setattr(temporal_fix, "plugins", object)
    monkeypatch.setattr(temporal_fix, "triton_version", lambda: "3.9.0")
    with_plugins = temporal_fix.recipe_identity()
    monkeypatch.setattr(temporal_fix, "triton_version", lambda: "3.9.1")
    upgraded = temporal_fix.recipe_identity()
    # The state is read again for each key, in the same process
    assert len({without, with_plugins, upgraded}) == 3


def test_a_broken_triton_warns_once_and_keys_the_set_as_plain(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import_module = temporal_fix.importlib.import_module

    def broken(name: str, *args: Any) -> Any:
        if name.partition(".")[0] == "triton":
            raise OSError("[WinError 126] the CUDA driver library is missing (a test)")
        return import_module(name, *args)

    monkeypatch.setattr(temporal_fix, "plugins", lambda: None)
    plain = temporal_fix.recipe_identity()
    monkeypatch.undo()
    warnings: list[str] = []
    monkeypatch.setattr(
        temporal_fix.logger, "warning", lambda message, *a: warnings.append(message % a)
    )
    monkeypatch.setattr(temporal_fix.importlib, "import_module", broken)
    assert temporal_fix.plugins() is None
    assert temporal_fix.recipe_identity() == plain
    assert len(warnings) == 1
    assert "WinError 126" in warnings[0]
