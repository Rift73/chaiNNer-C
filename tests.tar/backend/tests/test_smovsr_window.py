"""Upscale Image's temporal path for SMoVSR (nodes/impl/pytorch/smovsr_window.py) on the
CPU: a small model with every parameter random, against the clip in one cold window of
spandrel's run_window. A window from frame s to frame e keeps frames whose forward sweep
is the whole video's and whose backward sweep starts cold at e: each kept frame's output
is that of the clip of frames 0..e (from the last cold start), which these tests compare
it with. (The one window is the clip's sweeps frame by frame; run_clip's batched
encoding rounds differently, which a model with random weights amplifies, so it is
compared on the released file only.)"""

from __future__ import annotations

import os
import weakref
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import pytest
import torch

# spandrel before 0.4.2+c25 has no SMoVSR.
pytest.importorskip("spandrel.architectures.SMoVSR")
# The temporal path's padding runs in the native backend, which GitHub's checks do not
# build.
pytest.importorskip("nodes.impl._chainner_graph")

from spandrel import ImageModelDescriptor
from spandrel.architectures import SMoVSR

from api import NodeContext
from nodes.impl.pytorch import smovsr_window
from nodes.impl.pytorch.rdual_engine import model_unavailable
from nodes.impl.pytorch.smovsr_window import (
    MAX_KEEP,
    SMoVSRWindows,
    fits,
    window_peak,
)
from nodes.impl.pytorch.temporal_models import (
    TEMPORAL_ARCHITECTURES,
    context_of,
    is_temporal,
    pytorch_windows,
    window_of,
)
from nodes.impl.upscale.temporal_window import (
    LOOK_AHEAD,
    WARM_UP,
    Fit,
    WindowPlanner,
    temporal_upscale,
)
from nodes.impl.upscale.tile_report import TileReport
from nodes.impl.upscale.tiler import NoTiling
from packages.chaiNNer_pytorch.pytorch.io.load_model import load_model
from packages.chaiNNer_pytorch.pytorch.processing import upscale_image
from packages.chaiNNer_pytorch.pytorch.utility import interpolate_models
from packages.chaiNNer_pytorch.pytorch.utility.convert_to_ncnn import (
    convert_to_ncnn_node,
)
from packages.chaiNNer_pytorch.settings import PyTorchSettings

SIZE = (12, 16)
FRAMES = 40
CPU = PyTorchSettings(use_cpu=True, use_fp16=False, gpu_index=0, budget_limit=0)
# A released SMoVSR file, never in the repository: CHAINNER_C_TEST_SMOVSR_MODEL holds its
# full path; without it, or without the file, the tests that read it skip.
REAL_FILE = Path(os.environ.get("CHAINNER_C_TEST_SMOVSR_MODEL", ""))
NO_REAL_FILE = "CHAINNER_C_TEST_SMOVSR_MODEL names no SMoVSR model file"


def tiny() -> torch.nn.Module:
    torch.manual_seed(0)
    # A bound on the state, as the released file has (30): without one, random weights
    # let the state grow over the video until small roundings change the outputs.
    model = SMoVSR.SMoVSR(dim=8, h_clamp=2.0)
    # Every parameter random: zero-initialised gates and depth weights would hide a
    # sweep that runs in the wrong order.
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05)
    return model.eval()


@pytest.fixture(scope="module")
def descriptor() -> Any:
    loaded = SMoVSR.SMoVSRArch().load(tiny().state_dict())
    assert isinstance(loaded, ImageModelDescriptor)
    return loaded


@pytest.fixture(scope="module")
def video() -> list[np.ndarray]:
    rng = np.random.default_rng(0)
    base = rng.random((SIZE[0], SIZE[1] + FRAMES, 3), dtype=np.float32)
    # Each frame the one before moved by a pixel: motion, not noise.
    return [np.ascontiguousarray(base[:, t : t + SIZE[1]]) for t in range(FRAMES)]


class View:
    """The iteration view the temporal path reads: the loop's index, its frames
    `ahead` items ahead, and the state slot."""

    def __init__(self, frames: list[np.ndarray], ahead: int) -> None:
        self.frames = frames
        self.ahead = ahead
        self.index = 0
        self.unread = False
        self.state: object | None = None

    def lookahead(self, _input: int) -> int:
        return self.ahead

    def peek(self, _input: int, offset: int) -> np.ndarray | None:
        at = self.index + offset
        return (
            self.frames[at] if offset <= self.ahead and at < len(self.frames) else None
        )


def clip_outputs(
    descriptor: Any, frames: list[np.ndarray], batched: bool = False
) -> list[np.ndarray]:
    """The outputs of `frames` (BGR HWC in 0..1) as one cold window, or run_clip's with
    `batched`."""
    clip = torch.stack(
        [torch.from_numpy(f[..., ::-1].copy()).permute(2, 0, 1) for f in frames]
    )[None]
    with torch.inference_mode():
        if batched:
            out = SMoVSR.run_clip(descriptor.model, clip)[0]
        else:
            out = SMoVSR.run_window(descriptor.model, clip, len(frames))[0][0]
    return [o.permute(1, 2, 0).flip(2).numpy() for o in out]


class Recording(SMoVSRWindows):
    """The executor, recording each window as (first index, frames, kept)."""

    windows: list[tuple[int, int, int]]

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.windows = []

    def run(self, frames: Any, keep: int, past: Any, first: int) -> Any:
        self.windows.append((first, len(frames), keep))
        return super().run(frames, keep, past, first)


def loop(
    executor: SMoVSRWindows,
    frames: list[np.ndarray],
    ahead: int,
    indices: range | None = None,
) -> dict[int, np.ndarray]:
    view = View(frames, ahead)
    context = cast(NodeContext, SimpleNamespace(iteration=view))
    outputs = {}
    for index in indices or range(len(frames)):
        view.index = index
        outputs[index] = temporal_upscale(
            context, frames[index], executor, TileReport()
        )
    return outputs


def expected(
    descriptor: Any,
    frames: list[np.ndarray],
    windows: list[tuple[int, int, int]],
    start: int = 0,
) -> dict[int, np.ndarray]:
    """Each kept frame's run_clip output on the frames from `start` to its window's
    last one."""
    want = {}
    for first, count, keep in windows:
        outs = clip_outputs(descriptor, frames[start : first + count])
        for k in range(keep):
            want[first + k] = outs[first + k - start]
    return want


@pytest.mark.parametrize("ahead", [47, 20, 16, 5])
def test_each_output_is_the_clip_up_to_its_window_s_end(
    descriptor: Any, video: list[np.ndarray], ahead: int
):
    executor = Recording(descriptor, torch.device("cpu"))
    outputs = loop(executor, video, ahead)
    # Kept frames grow 1, 2, 4, ... after the cold start, up to what the frames read
    # ahead allow; the last window reaches the video's end and keeps every frame.
    windows = executor.windows
    assert sum(keep for _, _, keep in windows) == FRAMES
    assert windows[-1][0] + windows[-1][1] == FRAMES == windows[-1][0] + windows[-1][2]
    most = max(1, ahead + 1 - SMoVSR.LOOK_AHEAD)
    assert [keep for _, _, keep in windows[:4]] == [min(n, most) for n in (1, 2, 4, 8)]
    want = expected(descriptor, video, windows)
    for index, output in outputs.items():
        np.testing.assert_allclose(output, want[index], rtol=0, atol=1e-5)
    # The last window's frames are the whole clip's.
    whole = clip_outputs(descriptor, video)
    for index in range(windows[-1][0], FRAMES):
        np.testing.assert_allclose(outputs[index], whole[index], rtol=0, atol=1e-5)


def test_the_look_ahead_moves_the_output(descriptor: Any, video: list[np.ndarray]):
    # Guards the tests above: frame 0's output with 16 frames ahead is not its output
    # with none, so a window cut short would show.
    near = clip_outputs(descriptor, video[:1])[0]
    far = clip_outputs(descriptor, video[:17])[0]
    assert np.abs(near - far).max() > 1e-3


@pytest.mark.parametrize("count", [1, 5, 10, SMoVSR.LOOK_AHEAD])
def test_a_clip_within_one_look_ahead_is_the_whole_clip(
    descriptor: Any, video: list[np.ndarray], count: int
):
    # One frame, and up to LOOK_AHEAD: the first window reaches the clip's end and
    # keeps every frame.
    frames = video[:count]
    executor = Recording(descriptor, torch.device("cpu"))
    outputs = loop(executor, frames, 47)
    assert executor.windows == [(0, count, count)]
    whole = clip_outputs(descriptor, frames)
    for index in range(count):
        np.testing.assert_allclose(outputs[index], whole[index], rtol=0, atol=1e-5)


def test_a_window_shorter_than_the_carry_keeps_the_rest_for_the_next(
    descriptor: Any, video: list[np.ndarray]
):
    # Fewer frames fit than the last window read ahead: the frames past the short
    # window stay in the carry, and the forward sweep stays the whole video's.
    executor = SMoVSRWindows(descriptor, torch.device("cpu"))
    frames = [executor.convert(f) for f in video[:30]]
    outs_a, carry = executor.run(frames[0:20], 2, None, 0)
    assert len(carry[1]) == 18
    outs_b, carry = executor.run(frames[2:12], 3, (carry, frames[1]), 2)
    assert len(carry[1]) == 15
    outs_c, _ = executor.run(frames[5:30], 25, (carry, frames[4]), 5)
    got = [executor.to_image(o) for o in (*outs_a, *outs_b, *outs_c)]
    # Window b's backward sweep starts at its last frame, 11.
    want = expected(descriptor, video, [(0, 20, 2), (2, 10, 3), (5, 25, 25)])
    for index, output in enumerate(got):
        np.testing.assert_allclose(output, want[index], rtol=0, atol=1e-5)


@pytest.mark.parametrize("start", [9, 20])
def test_a_cold_start_inside_the_video_warms_up_from_there(
    descriptor: Any, video: list[np.ndarray], start: int
):
    # A Range's start or a seek: the planner starts cold at `start`, its windows
    # growing from one kept frame again, and every output is the clip from `start`.
    executor = Recording(descriptor, torch.device("cpu"))
    outputs = loop(executor, video, 47, range(start, FRAMES))
    assert [keep for _, _, keep in executor.windows[:2]] == [1, 2]
    want = expected(descriptor, video, executor.windows, start)
    for index, output in outputs.items():
        np.testing.assert_allclose(output, want[index], rtol=0, atol=1e-5)


def test_a_seek_restarts_the_growing_windows():
    # The planner alone: a stand-in run; after an item that does not follow the last
    # window's kept frames, the windows grow from one kept frame again.
    calls: list[tuple[int, int]] = []

    def run(frames: Any, keep: int, past: Any, first: int) -> Any:
        calls.append((first, keep))
        return [first + k for k in range(keep)], None

    planner = WindowPlanner((1,), "key", 16, grows=True)

    def item(index: int) -> None:
        planner.output(index, lambda: index, lambda k: index + k, 47, run)

    for index in range(70):
        item(index)
    for index in range(200, 210):
        item(index)
    assert calls == [
        (0, 1),
        (1, 2),
        (3, 4),
        (7, 8),
        (15, 16),
        (31, 32),
        (63, 32),
        (200, 1),
        (201, 2),
        (203, 4),
        (207, 8),
    ]


class State:
    """A stand-in state."""


class Counting:
    """A stand-in executor whose states are objects it counts while they live."""

    key = "counting"
    look_ahead = 16
    grows = True

    def __init__(self) -> None:
        self.states: list[weakref.ref[object]] = []
        # For each window: (first index, carried, states of earlier windows alive)
        self.windows: list[tuple[int, bool, int]] = []

    def convert(self, frame: np.ndarray) -> np.ndarray:
        return frame

    def run(self, frames: Any, keep: int, past: Any, first: int) -> Any:
        alive = sum(ref() is not None for ref in self.states)
        self.windows.append((first, past is not None, alive))
        state = State()
        self.states.append(weakref.ref(state))
        return [frames[k] for k in range(keep)], state

    @staticmethod
    def to_image(output: np.ndarray) -> np.ndarray:
        return output


def test_a_cold_window_does_not_hold_the_last_state(video: list[np.ndarray]):
    # A seek inside a run (an item that does not follow the last window's): while the
    # cold window runs, the last window's state is released, not held beside it.
    executor = Counting()
    view = View(video, 47)
    context = cast(NodeContext, SimpleNamespace(iteration=view))
    for index in [*range(10), *range(20, 25)]:
        view.index = index
        temporal_upscale(context, video[index], executor, TileReport())
    assert executor.windows == [
        (0, False, 0),
        (1, True, 1),
        (3, True, 1),
        (7, True, 1),
        (20, False, 0),
        (21, True, 1),
        (23, True, 1),
    ]


@pytest.mark.parametrize("look_ahead", [1, 16])
def test_a_planner_that_does_not_grow_plans_as_before(look_ahead: int):
    # The default: every window reads every frame it can, as for RSR, RDUAL, TFDAT.
    calls: list[tuple[int, int, int]] = []

    def run(frames: Any, keep: int, past: Any, first: int) -> Any:
        calls.append((first, len(frames), keep))
        return [first + k for k in range(keep)], None

    planner = WindowPlanner((1,), "key", look_ahead)
    for index in range(40):
        planner.output(
            index,
            lambda index=index: index,
            lambda k, index=index: index + k if index + k < 40 else None,
            7,
            run,
        )
    first = 0
    for at, count, keep in calls:
        assert at == first
        assert count == min(8, 40 - at)
        assert keep == (count if count < 8 else max(1, count - look_ahead))
        first += keep
    assert first == 40


@pytest.mark.skipif(not REAL_FILE.is_file(), reason=NO_REAL_FILE)
def test_half_precision_stays_near_full(video: list[np.ndarray]):
    # spandrel's bound for model.half(): RMSE 4.7e-4 and a worst pixel of 7.4e-3 on
    # the released file at 1080p on a GPU; here on the CPU, within twice those. (A
    # model with random weights has no such bound: its state overflows FP16.)
    model = load_model(REAL_FILE, CPU)
    assert isinstance(model, ImageModelDescriptor)
    full = loop(SMoVSRWindows(model, torch.device("cpu")), video, 47)
    half = loop(SMoVSRWindows(model, torch.device("cpu"), 0, True), video, 47)
    diff = np.stack([half[i] - full[i] for i in range(FRAMES)])
    assert np.sqrt((diff**2).mean()) < 9.4e-4
    assert np.abs(diff).max() < 1.5e-2


def test_the_ram_budget_caps_the_frames_read_ahead(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    # A budget of 10 frames of 12x16 BGR float32: 6 ahead, as the one kept output
    # (2x: 4 frames' bytes) waits on the host too; logged once.
    frame_bytes = SIZE[0] * SIZE[1] * 3 * 4
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: 10 * frame_bytes)
    logged: list[str] = []
    monkeypatch.setattr(
        smovsr_window.logger,
        "info",
        lambda message, *args: logged.append(message % args),
    )
    monkeypatch.setattr(smovsr_window, "_logged", set())
    executor = SMoVSRWindows(descriptor, torch.device("cpu"))
    assert executor.fitting_ahead(SIZE, 47) == 6
    assert executor.fitting_ahead(SIZE, 47) == 6
    assert executor.fitting_ahead(SIZE, 5) == 5
    assert len(logged) == 1
    assert "6 frames ahead of 16" in logged[0] and "RAM budget" in logged[0]
    # 47 frames and 32 kept outputs: everything fits, nothing changes.
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: 175 * frame_bytes)
    assert executor.fitting_ahead(SIZE, 47) == 47
    assert len(logged) == 1


def test_a_larger_frame_keeps_fewer_outputs_on_the_host(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    # One budget (8 GiB): 1920x1080 input keeps all 32 outputs (99.5 MB each at 4K
    # output) with 16 ahead; 3840x2160 input (398 MB each) keeps fewer, the look-ahead
    # whole.
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: 8 * 2**30)
    monkeypatch.setattr(smovsr_window.logger, "info", lambda *_args: None)
    executor = SMoVSRWindows(descriptor, torch.device("cpu"))
    assert executor.fitting_ahead((1080, 1920), 47) == 47
    ahead = executor.fitting_ahead((2160, 3840), 47)
    kept = ahead + 1 - 16
    assert 1 <= kept < 32
    frame = 2160 * 3840 * 3 * 4
    assert ahead * frame + kept * 4 * frame <= 8 * 2**30
    assert (ahead + 1) * frame + (kept + 1) * 4 * frame > 8 * 2**30


def gpu_executor(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch, free_mib: float
) -> tuple[SMoVSRWindows, list[str]]:
    """The executor on a stand-in GPU with `free_mib` MiB a window may add, and the
    lines it logs."""
    executor = SMoVSRWindows(descriptor, torch.device("cpu"))
    executor.device = torch.device("cuda")
    monkeypatch.setattr(
        smovsr_window, "window_memory", lambda _device, _budget: int(free_mib * 2**20)
    )
    logged: list[str] = []
    monkeypatch.setattr(
        smovsr_window.logger,
        "info",
        lambda message, *args: logged.append(message % args),
    )
    monkeypatch.setattr(smovsr_window, "_logged", set())
    return executor, logged


FULL_HD = (1080, 1920)


def predicted(frames_ahead: int, dtype_bytes: int = 4) -> int:
    frames = frames_ahead + 1
    return window_peak(*FULL_HD, frames, max(1, frames - 16), 2, dtype_bytes)


def test_a_window_that_fits_keeps_its_margin_of_free_memory(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    # 31 GiB free, FP32 at 1920x1080: the largest window whose estimate with its
    # margin fits, with all 16 frames ahead.
    executor, logged = gpu_executor(descriptor, monkeypatch, 31 * 1024)
    ahead = executor.fitting_ahead(FULL_HD, 47)
    free = 31 * 1024 * 2**20
    assert fits(predicted(ahead), free) and not fits(predicted(ahead + 1), free)
    assert ahead + 1 - 16 >= 1
    assert logged == []  # still 16 frames ahead: nothing less exact


def test_a_frame_that_fits_only_without_its_look_ahead_reads_fewer_frames_ahead(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    # Room for a window of one kept frame and 7 ahead, not 16: 7, logged once.
    free_mib = (predicted(7) * 1.2) / 2**20 + 256 + 1
    executor, logged = gpu_executor(descriptor, monkeypatch, free_mib)
    assert executor.fitting_ahead(FULL_HD, 47) == 7
    assert executor.fitting_ahead(FULL_HD, 47) == 7
    assert len(logged) == 1
    assert "7 frames ahead of 16" in logged[0] and "GPU's memory" in logged[0]


def test_a_frame_that_does_not_fit_alone_raises_before_it_runs(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    executor, _ = gpu_executor(
        descriptor, monkeypatch, predicted(0) * 1.2 / 2**20 + 256 - 1
    )
    with pytest.raises(torch.OutOfMemoryError, match="even with no frames read ahead"):
        executor.fitting_ahead(FULL_HD, 47)


def test_a_carried_state_is_not_counted_twice(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    # The estimate counts the carry the window starts from, which is allocated already
    # and so not in the free memory: with it, the window is the one the same free
    # memory plus the carry's bytes gives without one.
    carry = (
        torch.zeros(2**28, dtype=torch.uint8),
        (torch.zeros(2**30, dtype=torch.uint8),),
        (torch.zeros(2**30, dtype=torch.uint8),),
    )
    free_mib = 12 * 1024
    with_carry, _ = gpu_executor(descriptor, monkeypatch, free_mib)
    ahead = with_carry.fitting_ahead(FULL_HD, 47, carry)
    without, _ = gpu_executor(descriptor, monkeypatch, free_mib + 2304)
    assert ahead == without.fitting_ahead(FULL_HD, 47)
    cold, _ = gpu_executor(descriptor, monkeypatch, free_mib)
    assert cold.fitting_ahead(FULL_HD, 47) < ahead


class Fitting(Counting):
    """Counting, recording for each item whether its plan got a carried state."""

    def __init__(self) -> None:
        super().__init__()
        self.planned: list[bool] = []

    def fitting_ahead(self, _shape: Any, ahead: int, carry: Any = None) -> int:
        self.planned.append(carry is not None)
        return ahead


def test_only_a_state_carried_into_the_window_is_counted(video: list[np.ndarray]):
    # A window after the last one's kept frames: the live carried state (item 2 takes
    # its output from window 1, which kept 1 and 2, and plans nothing). A cold start (a
    # seek) and a change of frame size (whose planner starts over): none, as the last
    # state is released.
    executor = Fitting()
    view = View(video, 47)
    context = cast(NodeContext, SimpleNamespace(iteration=view))
    small = [f[:8, :8] for f in video]
    items = [(i, video) for i in range(4)] + [(20, video), (21, video), (22, small)]
    for index, frames in items:
        view.index = index
        view.frames = frames
        temporal_upscale(context, frames[index], executor, TileReport())
    assert executor.planned == [False, True, False, True, False, True, False]
    assert [first for first, _, _ in executor.windows] == [0, 1, 3, 20, 21, 22]


def test_a_shorter_smovsr_window_keeps_fewer_frames_before_it_reads_fewer_ahead():
    # Out of memory, the window halves the frames it keeps (32, 16 ... 1) with its 16
    # frames ahead, then halves those; RSR's (and every other executor's) steps stay
    # LOOK_AHEAD + 1 and none.
    fit = Fit(NoTiling(), True, lambda _e: True, lambda: None, tiles=False)
    grows = [a for a, _, _ in fit.steps(64, 64, 47, 16)]
    assert grows == [47, 31, 23, 19, 17, 16, 8, 4, 2, 1, 0]
    assert [(a + 1, max(1, a + 1 - 16)) for a in grows[:6]] == [
        (48, 32),
        (32, 16),
        (24, 8),
        (20, 4),
        (18, 2),
        (17, 1),
    ]
    assert [a for a, _, _ in fit.steps(64, 64, 10, 16)] == [10, 8, 4, 2, 1, 0]
    for ahead in (6, 7, 2, 0):
        today = [(ahead, None, 0)] + [
            (a, None, 0) for a in (LOOK_AHEAD + 1, 0) if a < ahead
        ]
        assert fit.steps(64, 64, ahead) == today


def test_the_estimate_counts_every_frame_of_the_window():
    # Pinned form: a window of T frames keeping K is FIXED + FRAME x T + KEPT x K per
    # megapixel, its carry included (a window that encodes fewer frames, after a carry,
    # is not predicted smaller), and at least spandrel's own figures (half precision:
    # 445 + 210 x K for the window and 126 per carried look-ahead frame; FP32: 1300 +
    # 290 x K and 252), so it never plans below them.
    mp = 540 * 960 / 1e6
    for keep in (1, 8, 16, 32):
        frames = keep + 16
        for dtype, (base, per_kept, per_carried) in {
            2: (445, 210, 126),
            4: (1300, 290, 252),
        }.items():
            estimate = window_peak(540, 960, frames, keep, 2, dtype)
            form = (
                smovsr_window.FIXED[dtype]
                + smovsr_window.FRAME[dtype] * frames
                + smovsr_window.KEPT[dtype] * keep
            )
            assert estimate == int(mp * form * 2**20)
            library = base + per_kept * keep + per_carried * 16
            assert estimate >= int(mp * library * 2**20), (keep, dtype)


class Watching(Counting):
    """Counting, recording for each fit whether it got a carried state and how many
    earlier states were still alive when it was measured."""

    def __init__(self) -> None:
        super().__init__()
        self.fits: list[tuple[bool, int]] = []

    def fitting_ahead(self, _shape: Any, ahead: int, carry: Any = None) -> int:
        alive = sum(ref() is not None for ref in self.states)
        self.fits.append((carry is not None, alive))
        return ahead


@pytest.mark.parametrize("with_fit", [False, True])
def test_a_cold_fit_is_measured_after_the_last_state_is_released(
    video: list[np.ndarray], with_fit: bool
):
    # A seek inside the run (item 20) and a new frame size (item 21, a new run): when
    # their cold window's fit is measured, no earlier state is alive any more, so the
    # free memory it reads already holds the released carry.
    executor = Watching()
    view = View(video, 47)
    context = cast(NodeContext, SimpleNamespace(iteration=view))
    fit = Fit(NoTiling(), True, lambda _e: False, lambda: None, tiles=False)
    small = [f[:8, :8] for f in video]
    items = [(i, video) for i in range(4)] + [(20, video), (21, small)]
    for index, frames in items:
        view.index = index
        view.frames = frames
        temporal_upscale(
            context,
            frames[index],
            executor,
            TileReport(),
            fit=fit if with_fit else None,
        )
    # Per fit (carried, earlier states alive): items 0, 1, 2, 3, 20, 21, with the fit's
    # first measure of a new run before items 0 and 21. Item 2 takes its output from
    # window 1 and plans nothing new: that window's state lives on for window 3.
    items_fits = [(False, 0), (True, 1), (False, 1), (True, 1), (False, 0), (False, 0)]
    if with_fit:
        items_fits = [(False, 0), *items_fits[:5], (False, 0), items_fits[5]]
    assert executor.fits == items_fits


@pytest.mark.parametrize(("ahead", "logs"), [(0, 1), (7, 1), (47, 0), (16, 0)])
def test_a_loop_that_reads_fewer_frames_ahead_says_so_once(
    descriptor: Any,
    monkeypatch: pytest.MonkeyPatch,
    video: list[np.ndarray],
    ahead: int,
    logs: int,
):
    # The loop's own window (a GPU node feeding the image, a window of 1, a model not
    # known before the loop) gives fewer than 16 frames ahead: one line for the run
    # and frame size. The clip's end, which every window reaches eventually, does not
    # log.
    logged: list[str] = []
    monkeypatch.setattr(
        smovsr_window.logger,
        "info",
        lambda message, *args: logged.append(message % args),
    )
    loop(SMoVSRWindows(descriptor, torch.device("cpu")), video[:20], ahead)
    assert len(logged) == logs
    if logs:
        assert f"reads {ahead} frames ahead of the 16" in logged[0]
        assert "the loop's window" in logged[0]


def test_the_window_estimate_follows_its_measurements():
    half = [window_peak(540, 960, f, 1, 2, 2) for f in (1, 17, 32)]
    assert half == sorted(half) and len(set(half)) == 3
    assert window_peak(540, 960, 32, 32, 2, 4) > window_peak(540, 960, 32, 32, 2, 2)
    # smovsr_window's measurements (MiB), as (height, width, frames, kept, dtype), each
    # after a window carrying 16 frames (frames - 16 encoded): within 8 % of each,
    # which MARGIN covers.
    for (h, w, frames, keep, dtype), mib in {
        (540, 960, 48, 32, 2): 3947,
        (540, 960, 32, 1, 2): 1565,
        (1080, 1920, 32, 16, 2): 8242,
        (540, 960, 40, 8, 4): 4375,
        (1080, 1920, 24, 8, 4): 8644,
    }.items():
        estimate = window_peak(h, w, frames - 16, keep, 2, dtype) / 2**20
        assert abs(estimate / mib - 1) < 0.08, (h, w, frames, keep, dtype)


def test_the_registration_lists(descriptor: Any):
    assert "SMoVSR" in TEMPORAL_ARCHITECTURES
    assert is_temporal(descriptor)
    assert context_of(descriptor) == (SMoVSR.WARM_UP, SMoVSR.LOOK_AHEAD) == (8, 16)
    assert window_of(descriptor) == MAX_KEEP + SMoVSR.LOOK_AHEAD == 48
    # Every other value: the loop's own window and RDUAL's and RSR's context.
    assert window_of(None) == window_of("not a model") == 0
    assert context_of(None) == (WARM_UP, LOOK_AHEAD)
    data = next(
        d
        for d in upscale_image.processing_group.nodes
        if d.schema_id == "chainner:pytorch:upscale_image"
    )
    assert data.temporal_window_of is window_of
    assert data.temporal_context_of is context_of
    windows, lighter, tiles = pytorch_windows(descriptor, CPU, 0)
    executor = windows()
    assert isinstance(executor, SMoVSRWindows)
    assert (lighter, tiles) == ((), False)
    assert executor.model.dtype == torch.float32
    assert executor.look_ahead == 16 and executor.grows


def test_the_engine_route_applies_and_ncnn_refuses(descriptor: Any):
    # SMoVSR's engine sets (tensorrt/smovsr.py) are checked at its trained scale, 2.
    assert model_unavailable(descriptor) is None
    context = cast(NodeContext, SimpleNamespace())
    with pytest.raises(ValueError, match="a video model"):
        convert_to_ncnn_node(context, descriptor, False)


@pytest.mark.parametrize(("record", "bound"), [({"h_clamp": 30.0}, 30.0), (None, None)])
def test_load_model_reads_the_training_bound(
    tmp_path: Path, record: dict[str, float] | None, bound: float | None
):
    # A neosr checkpoint records the bound beside its weights; a file without the
    # record keeps upstream's default, none.
    checkpoint: dict[str, Any] = {"params": tiny().state_dict()}
    if record is not None:
        checkpoint["neosr"] = {"network_g": {"type": "VSMoSR", **record}}
    path = tmp_path / "model.pth"
    torch.save(checkpoint, path)
    model = load_model(path, CPU)
    assert isinstance(model, ImageModelDescriptor)
    assert model.architecture.id == "SMoVSR"
    network: Any = model.model
    assert network.f_forward.h_clamp == network.f_backward.h_clamp == bound
    assert ("clamp30" in model.tags) == (bound is not None)


def bounded(tmp_path: Path, name: str, bound: float | None) -> Any:
    """The small model saved as a neosr checkpoint with `bound`, through Load Model."""
    checkpoint: dict[str, Any] = {"params": tiny().state_dict()}
    if bound is not None:
        checkpoint["neosr"] = {"network_g": {"h_clamp": bound}}
    path = tmp_path / f"{name}.pth"
    torch.save(checkpoint, path)
    return load_model(path, CPU)


@pytest.mark.parametrize("bound", [30.0, None])
def test_interpolate_models_keeps_the_bound_both_models_share(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, bound: float | None
):
    monkeypatch.setattr(
        interpolate_models,
        "get_settings",
        lambda _context: SimpleNamespace(device=torch.device("cpu"), budget_limit=0),
    )
    a, b = bounded(tmp_path, "a", bound), bounded(tmp_path, "b", bound)
    context = cast(NodeContext, SimpleNamespace())
    model, _, _ = interpolate_models.interpolate_models_node(context, a, b, 30)
    network: Any = model.model
    assert network.f_forward.h_clamp == network.f_backward.h_clamp == bound
    assert network.hyperparameters["h_clamp"] == bound
    assert ("clamp30" in model.tags) == (bound is not None)


def test_interpolate_models_refuses_two_bounds(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(
        interpolate_models,
        "get_settings",
        lambda _context: SimpleNamespace(device=torch.device("cpu"), budget_limit=0),
    )
    a, b = bounded(tmp_path, "a", 30.0), bounded(tmp_path, "b", None)
    context = cast(NodeContext, SimpleNamespace())
    with pytest.raises(ValueError, match=r"different bounds .*\(30\.0 and None\)"):
        interpolate_models.interpolate_models_node(context, a, b, 30)


@pytest.mark.skipif(not REAL_FILE.is_file(), reason=NO_REAL_FILE)
def test_the_released_file_runs_with_its_bound(video: list[np.ndarray]):
    # Its bound from the file, and the loop's last window run_clip's on the whole clip.
    model = load_model(REAL_FILE, CPU)
    assert isinstance(model, ImageModelDescriptor)
    network: Any = model.model
    assert network.f_forward.h_clamp == 30.0
    assert "clamp30" in model.tags
    executor = Recording(model, torch.device("cpu"))
    outputs = loop(executor, video, 47)
    whole = clip_outputs(model, video, batched=True)
    for index in range(executor.windows[-1][0], FRAMES):
        np.testing.assert_allclose(outputs[index], whole[index], rtol=0, atol=1e-5)
