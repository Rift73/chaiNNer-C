"""A seek preview's /run/individual request has a token: its run's node-broadcast and
node-finish events carry it, and the reply says whether a node-broadcast came."""

from __future__ import annotations

import asyncio
import importlib
import json
import sys
from types import ModuleType, SimpleNamespace

import pytest


@pytest.fixture
def server(monkeypatch: pytest.MonkeyPatch) -> ModuleType:
    # The module parses its command line when imported.
    monkeypatch.setattr(sys, "argv", ["server.py"])
    return importlib.import_module("server")


class Collected:
    def __init__(self) -> None:
        self.events: list[dict[str, object]] = []

    def put(self, event: dict[str, object]) -> None:
        self.events.append(event)


def test_the_run_s_broadcast_and_finish_carry_the_token(server: ModuleType):
    collected = Collected()
    events = server.TokenEvents(collected, "node 7")
    broadcast = {"nodeId": "node", "data": {}, "types": {}, "sequenceTypes": None}

    events.put(
        {"event": "node-finish", "data": {"nodeId": "node", "executionTime": 0.25}}
    )
    assert not events.broadcast
    events.put({"event": "node-broadcast", "data": broadcast})
    events.put({"event": "execution-warning", "data": {"message": "late"}})

    assert events.broadcast
    assert collected.events == [
        {
            "event": "node-finish",
            "data": {"nodeId": "node", "executionTime": 0.25, "token": "node 7"},
        },
        {"event": "node-broadcast", "data": {**broadcast, "token": "node 7"}},
        {"event": "execution-warning", "data": {"message": "late"}},
    ]
    # the run's own event data is left as it was
    assert "token" not in broadcast


def test_a_run_without_a_broadcast_says_so(server: ModuleType):
    collected = Collected()
    events = server.TokenEvents(collected, "node 8")

    events.put(
        {"event": "node-finish", "data": {"nodeId": "node", "executionTime": 0.5}}
    )

    assert not events.broadcast
    assert len(collected.events) == 1


SCHEMA = "chainner:test:seek_node"


def run_with_token(
    server: ModuleType,
    monkeypatch: pytest.MonkeyPatch,
    events: list[dict[str, object]],
    raises: BaseException | None = None,
    token: str | None = "node 9",
    fields: dict[str, object] | None = None,
    created: list[dict[str, object]] | None = None,
) -> tuple[dict[str, object], Collected]:
    """The reply of /run/individual for a node whose run puts `events` on its queue (or
    raises), and the events the stream got; `fields` are more of the request's, and
    `created` gets the arguments each executor is made with."""

    async def loaded(_schema_ids: object) -> None:
        pass

    class Executor:
        def __init__(self, *, queue: Collected, **kwargs: object) -> None:
            self.queue = queue
            if created is not None:
                created.append(kwargs)

        async def process_regular_node(self, _node: object) -> str:
            for event in events:
                self.queue.put(event)
            if raises is not None:
                raise raises
            return "output"

        def kill(self) -> None:
            pass

        async def flush_broadcasts(self) -> None:
            pass

    stream = Collected()
    node = SimpleNamespace(kind="regularNode", node_context=False, inputs=[])
    monkeypatch.setattr(server, "wait_for_nodes", loaded)
    monkeypatch.setattr(server.api.registry, "nodes", {SCHEMA: (node, None)})
    monkeypatch.setattr(server, "executor_kind", lambda: "python")
    monkeypatch.setattr(server, "Executor", Executor)
    monkeypatch.setattr(server.app.ctx, "cache", {})
    monkeypatch.setattr(server.app.ctx, "queue", stream)
    app = SimpleNamespace(ctx=server.app.ctx, loop=None)
    monkeypatch.setattr(server, "app", app)
    body: dict[str, object] = {
        "id": "node",
        "schemaId": SCHEMA,
        "inputs": [],
        "options": {},
    }
    if token is not None:
        body["token"] = token
    body.update(fields or {})
    reply = asyncio.run(server.run_individual(SimpleNamespace(app=app, json=body)))
    return json.loads(reply.body), stream


BROADCAST: dict[str, object] = {
    "event": "node-broadcast",
    "data": {"nodeId": "node", "data": {}, "types": {}, "sequenceTypes": None},
}
FINISH: dict[str, object] = {
    "event": "node-finish",
    "data": {"nodeId": "node", "executionTime": 0.5},
}


def test_a_seek_preview_s_reply_says_its_broadcast_came(
    server: ModuleType, monkeypatch: pytest.MonkeyPatch
):
    reply, stream = run_with_token(server, monkeypatch, [FINISH, BROADCAST])

    assert reply == {"success": True, "data": {"broadcast": True}}
    datas = [event["data"] for event in stream.events]
    assert [data["token"] for data in datas if isinstance(data, dict)] == ["node 9"] * 2


def test_a_seek_preview_whose_run_was_stopped_says_no_broadcast_came(
    server: ModuleType, monkeypatch: pytest.MonkeyPatch
):
    from progress_controller import Aborted

    reply, stream = run_with_token(server, monkeypatch, [], raises=Aborted())

    assert reply == {"success": True, "data": {"broadcast": False}}
    assert stream.events == []


def test_a_failed_seek_preview_replies_its_error(
    server: ModuleType, monkeypatch: pytest.MonkeyPatch
):
    reply, _ = run_with_token(
        server, monkeypatch, [], raises=ValueError("no such file")
    )

    assert reply == {"success": False, "error": "no such file"}


def test_a_run_without_a_token_is_as_before(
    server: ModuleType, monkeypatch: pytest.MonkeyPatch
):
    reply, stream = run_with_token(server, monkeypatch, [BROADCAST], token=None)

    assert reply == {"success": True, "data": None}
    assert stream.events == [BROADCAST]


def test_a_seek_preview_s_sizes_reach_its_run_alone(
    server: ModuleType, monkeypatch: pytest.MonkeyPatch
):
    # The request's previewSizes go to its own run's executor (its broadcast's previews:
    # LargeImageOutput.get_broadcast_data's sizes); a request without them gets none.
    created: list[dict[str, object]] = []
    fields: dict[str, object] = {"previewSizes": [512, 1920]}
    run_with_token(server, monkeypatch, [BROADCAST], fields=fields, created=created)
    run_with_token(server, monkeypatch, [BROADCAST], created=created)

    assert [kwargs["preview_sizes"] for kwargs in created] == [[512, 1920], []]


@pytest.mark.parametrize(
    ("field", "sizes"),
    [
        (None, []),
        ("512", []),
        (512, []),
        ({"512": 1}, []),
        ([], []),
        ([float("nan"), float("inf"), -5, 0, "300", None, True], []),
        ([511.2, 2**40, 256], [512, 65536, 256]),
    ],
)
def test_a_malformed_preview_sizes_field_never_fails_the_run(
    server: ModuleType, monkeypatch: pytest.MonkeyPatch, field: object, sizes: list[int]
):
    # Only finite numbers above 0 are kept (whole px, at most the limit); a field that
    # is no list, or keeps none, makes every preview, and the run goes on.
    created: list[dict[str, object]] = []
    reply, _ = run_with_token(
        server,
        monkeypatch,
        [BROADCAST],
        fields={"previewSizes": field},
        created=created,
    )

    assert reply == {"success": True, "data": {"broadcast": True}}
    assert [kwargs["preview_sizes"] for kwargs in created] == [sizes]


def run_chain(
    server: ModuleType,
    monkeypatch: pytest.MonkeyPatch,
    fields: dict[str, object],
    created: list[dict[str, object]],
) -> dict[str, object]:
    """The reply of /run for an empty chain whose executor is a stand-in; `created` gets
    the arguments it is made with."""

    class Executor:
        async def run(self) -> None:
            pass

    def made(_executor_class: object, **kwargs: object) -> Executor:
        created.append(kwargs)
        return Executor()

    monkeypatch.setattr(server, "run_executor", made)
    monkeypatch.setattr(server.app.ctx, "queue", Collected())
    app = SimpleNamespace(ctx=server.app.ctx, loop=None)
    monkeypatch.setattr(server, "app", app)
    body: dict[str, object] = {
        "data": [],
        "options": {},
        "sendBroadcastData": True,
        **fields,
    }
    reply = asyncio.run(server.run(SimpleNamespace(app=app, json=body)))
    return json.loads(reply.body)


@pytest.mark.parametrize(
    ("field", "sizes"),
    [
        ({"previewSizes": [512, 1920]}, [512, 1920]),
        ({}, []),
        ({"previewSizes": None}, []),
        ({"previewSizes": [float("nan"), -1, "300", 700.5]}, [701]),
    ],
)
def test_a_seek_render_s_sizes_reach_its_run_alone(
    server: ModuleType,
    monkeypatch: pytest.MonkeyPatch,
    field: dict[str, object],
    sizes: list[int],
):
    # /run's previewSizes, as /run/individual's: read by preview_sizes, for that run's
    # broadcasts only; without the field every preview is made.
    created: list[dict[str, object]] = []
    reply = run_chain(server, monkeypatch, field, created)
    run_chain(server, monkeypatch, {}, created)

    assert reply["type"] == "success"
    assert [kwargs["preview_sizes"] for kwargs in created] == [sizes, []]
