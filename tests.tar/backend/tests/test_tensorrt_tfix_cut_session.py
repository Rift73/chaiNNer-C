"""The run side of Temporal Fix's cut window (nodes/impl/tensorrt/tfix_cut.py), without a
GPU: what a failed kernel load, a failed session setup and a failed unload leave
behind (nothing, and the first error), the layouts the kernels take, and the checks
before a kernel's cubin is used. Stand-ins replace the pieces' engines and the CUDA
driver."""

from __future__ import annotations

import json
from collections.abc import Iterator
from contextlib import contextmanager
from types import SimpleNamespace
from typing import Any, ClassVar, cast

import pytest
import torch

driver = pytest.importorskip("cuda.bindings.driver")
temporal_fix_session = pytest.importorskip("nodes.impl.tensorrt.temporal_fix_session")
tfix_cut = pytest.importorskip("nodes.impl.tensorrt.tfix_cut")

LAUNCH = {
    "op": "conf_input_s2_h4_w6_g32",
    "inputs": ["a", "b"],
    "output": "rows",
    "grid": [1, 2, 1],
    "block": 128,
    "shared": 0,
    "function": "conf_input",
    "scratch": 0,
}


class Engine:
    def __init__(self, formats: dict[str, Any]) -> None:
        self.formats = formats

    def get_tensor_format(self, name: str) -> Any:
        return self.formats[name]


def part(name: str, bindings: dict[str, tuple[int, ...]], formats: dict[str, Any]):
    return SimpleNamespace(
        name=name,
        names=list(bindings),
        workspace=0,
        use_memory=lambda memory: None,
        engine=Engine(formats),
        spec=lambda n: (bindings[n], torch.float16),
    )


def window_data(kernels: int) -> dict[str, bytes]:
    launches = [
        {**LAUNCH, "op": f"conf_input_{k}", "output": f"rows{k}"}
        for k in range(kernels)
    ]
    plan = {"pieces": ["window_1"], "order": [], "kernels": launches}
    data = {tfix_cut.LAYOUT: json.dumps(plan).encode()}
    for launch in launches:
        data[tfix_cut.cubin_name(str(launch["op"]))] = b"cubin"
    return data


class Loaded:
    """A stand-in kernel: the n-th load fails; each one records its unload."""

    made: ClassVar[list[Loaded]] = []
    fail_at = -1

    def __init__(self, launch: dict, cubin: bytes) -> None:
        if len(Loaded.made) == Loaded.fail_at:
            raise RuntimeError("load refused")
        self.op, self.output, self.inputs = launch["op"], launch["output"], []
        self.closed = False
        Loaded.made.append(self)

    def close(self) -> None:
        self.closed = True


# The devices a stand-in device context entered ("in") and left ("out"), in order
devices: list[tuple[str, object]] = []


@contextmanager
def device_context(device: object) -> Iterator[None]:
    devices.append(("in", device))
    try:
        yield
    finally:
        devices.append(("out", device))


def set_device(device: object) -> None:
    raise AssertionError(f"the thread's device was set to {device} and not restored")


@pytest.fixture
def stand_ins(monkeypatch: pytest.MonkeyPatch):
    Loaded.made = []
    devices.clear()
    monkeypatch.setattr(tfix_cut, "Kernel", Loaded)
    monkeypatch.setattr(torch.cuda, "set_device", set_device)
    monkeypatch.setattr(torch.cuda, "device", device_context)
    monkeypatch.setattr(
        tfix_cut, "check_layouts", lambda pieces, kernels: None, raising=False
    )
    yield
    Loaded.fail_at = -1


@pytest.mark.usefixtures("stand_ins")
@pytest.mark.parametrize("fail_at", [0, 1])
def test_a_kernel_that_fails_to_load_raises_its_error_and_leaves_none_loaded(
    fail_at: int,
):
    Loaded.fail_at = fail_at
    parts = {"window_1": part("window_1", {"rows0": (2, 25, 4, 6)}, {})}
    with pytest.raises(RuntimeError, match="load refused"):
        tfix_cut.WindowPieces(cast(Any, parts), window_data(2), torch.device("cpu"))
    assert len(Loaded.made) == fail_at
    assert all(k.closed for k in Loaded.made)


@pytest.mark.usefixtures("stand_ins")
def test_a_failure_after_the_kernels_loaded_unloads_them():
    # No piece reads the second kernel's output
    parts = {"window_1": part("window_1", {"rows0": (2, 25, 4, 6)}, {})}
    with pytest.raises(RuntimeError, match="no piece reads its output"):
        tfix_cut.WindowPieces(cast(Any, parts), window_data(2), torch.device("cpu"))
    assert len(Loaded.made) == 2
    assert all(k.closed for k in Loaded.made)


@pytest.mark.usefixtures("stand_ins")
def test_a_session_that_fails_to_set_up_unloads_its_window_s_kernels(
    monkeypatch: pytest.MonkeyPatch,
):
    def fail(frame_part: object, device: torch.device) -> None:
        raise MemoryError("no room for the slots")

    monkeypatch.setattr(temporal_fix_session, "Slot", fail)
    parts = {
        "frame": part("frame", {}, {}),
        "window_1": part("window_1", {"rows0": (2, 25, 4, 6)}, {}),
    }
    with pytest.raises(MemoryError, match="no room"):
        temporal_fix_session.TemporalFixSession(
            cast(Any, parts),
            None,
            0,
            None,
            torch.device("cpu"),
            (4, 6, 1),
            "key",
            window_data(1),
        )
    (kernel,) = Loaded.made
    assert kernel.closed


@pytest.mark.usefixtures("stand_ins")
def test_close_tries_every_kernel_and_raises_the_first_error():
    parts = {
        "window_1": part(
            "window_1", {"rows0": (2, 25, 4, 6), "rows1": (2, 25, 4, 6)}, {}
        )
    }
    pieces = tfix_cut.WindowPieces(
        cast(Any, parts), window_data(2), torch.device("cpu")
    )
    first, second = Loaded.made

    def refuse() -> None:
        raise RuntimeError("unload refused")

    first.close = refuse
    with pytest.raises(RuntimeError, match="unload refused"):
        pieces.close()
    assert second.closed
    assert pieces.kernels == []


def test_a_session_s_close_frees_its_engines_when_a_kernel_will_not_unload(
    monkeypatch: pytest.MonkeyPatch,
):
    closed = []
    session = temporal_fix_session.TemporalFixSession.__new__(
        temporal_fix_session.TemporalFixSession
    )
    window = tfix_cut.WindowPieces.__new__(tfix_cut.WindowPieces)

    def refuse() -> None:
        raise RuntimeError("unload refused")

    window.close = refuse
    session.window_part = window
    session.parts = cast(Any, {"frame": None})
    stream = SimpleNamespace(synchronize=lambda: None)
    session.stream = stream
    session.download = stream
    monkeypatch.setattr(temporal_fix_session, "close_parts", closed.append)
    with pytest.raises(RuntimeError, match="unload refused"):
        session.close()
    assert closed == [{"frame": None}]


def test_the_kernels_take_linear_inputs_and_write_hwc8_rows():
    trt = pytest.importorskip("tensorrt")
    linear, hwc8 = trt.TensorFormat.LINEAR, trt.TensorFormat.HWC8
    kernel = cast(Any, SimpleNamespace(op="k", inputs=["a"], output="rows"))
    good = part("window_1", {"rows": (2, 25, 4, 6)}, {"rows": hwc8})
    maker = part("window_0", {"a": (2, 8, 4, 6)}, {"a": linear})
    tfix_cut.check_layouts(cast(Any, [maker, good]), [kernel])
    channel_last = part("window_0", {"a": (2, 8, 4, 6)}, {"a": hwc8})
    with pytest.raises(RuntimeError, match="window_0/a"):
        tfix_cut.check_layouts(cast(Any, [channel_last, good]), [kernel])
    linear_rows = part("window_1", {"rows": (2, 25, 4, 6)}, {"rows": linear})
    with pytest.raises(RuntimeError, match="window_1/rows"):
        tfix_cut.check_layouts(cast(Any, [maker, linear_rows]), [kernel])


def test_a_kernel_that_needs_scratch_memory_is_never_loaded(
    monkeypatch: pytest.MonkeyPatch,
):
    loads = []
    monkeypatch.setattr(driver, "cuModuleLoadData", loads.append)
    with pytest.raises(RuntimeError, match="scratch memory"):
        tfix_cut.Kernel({**LAUNCH, "scratch": 256}, b"cubin")
    with pytest.raises(RuntimeError, match="scratch memory"):
        # a layout from before the scratch was recorded
        tfix_cut.Kernel({k: v for k, v in LAUNCH.items() if k != "scratch"}, b"cubin")
    assert loads == []


@pytest.mark.parametrize("failure", ["lookup", "parameters", "old driver"])
def test_a_kernel_that_fails_after_its_load_unloads_its_module(
    monkeypatch: pytest.MonkeyPatch, failure: str
):
    ok, bad = driver.CUresult.CUDA_SUCCESS, driver.CUresult.CUDA_ERROR_INVALID_VALUE
    unloaded = []
    # buffers a, b and rows: 3 parameters; "parameters" gives the kernel 2
    count = {"lookup": 3, "parameters": 2, "old driver": 0}[failure]
    monkeypatch.setattr(driver, "cuModuleLoadData", lambda data: (ok, "module"))
    monkeypatch.setattr(
        driver,
        "cuModuleGetFunction",
        lambda module, name: (bad, None) if failure == "lookup" else (ok, "function"),
    )
    monkeypatch.setattr(
        driver,
        "cuFuncGetParamInfo",
        lambda function, index: (ok if index < count else bad, 0, 8),
    )
    monkeypatch.setattr(
        driver, "cuModuleUnload", lambda module: (unloaded.append(module), ok)[1:]
    )
    message = {"lookup": "lookup", "parameters": "fewer than", "old driver": "12.4"}
    with pytest.raises(RuntimeError, match=message[failure]):
        tfix_cut.Kernel(LAUNCH, b"cubin")
    assert unloaded == ["module"]


@pytest.mark.usefixtures("stand_ins")
def test_loading_and_unloading_the_kernels_keep_the_threads_device():
    # The kernels load and unload in the session device's context, which is left on
    # every path: the thread's own current device is never changed for good.
    parts = {
        "window_1": part(
            "window_1", {"rows0": (2, 25, 4, 6), "rows1": (2, 25, 4, 6)}, {}
        )
    }
    device = torch.device("cpu")
    pieces = tfix_cut.WindowPieces(cast(Any, parts), window_data(2), device)
    assert devices == [("in", device), ("out", device)]

    def refuse() -> None:
        raise RuntimeError("refused")

    Loaded.made[0].close = refuse
    with pytest.raises(RuntimeError, match="refused"):
        pieces.close()
    assert devices == [("in", device), ("out", device)] * 2
