"""The SMoVSR engine set's session (nodes/impl/tensorrt/smovsr_session.py) on the CPU,
with stand-in engines that run the library's own per-frame steps (the ones the export
traces) on a small FP32 model: windows of any length and kept count, chained, after a
seek and at a clip's end, against the library's run_window bit for bit; the calls a
window makes and the forward work two windows share; the memory arithmetic. No GPU,
TensorRT or CUDA graphs."""

from __future__ import annotations

import contextlib
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import pytest
import torch

# cuda-python comes with the TensorRT package's dependencies, not with the runtime.
pytest.importorskip("cuda.bindings.runtime")
pytest.importorskip("spandrel.architectures.SMoVSR")

from spandrel.architectures.SMoVSR import (
    SMoVSR,
    SMoVSRArch,
    backward_step,
    encode_forward,
    head,
    run_window,
)

from nodes.impl.tensorrt.smovsr_session import SMoVSRSession

HEIGHT, WIDTH, SCALE, DIM = 6, 8, 2, 8
F32 = torch.float32
STATE = ((1, DIM, HEIGHT, WIDTH), F32)
VALID = ((1,), torch.bool)
IMAGE = ((1, 3, HEIGHT, WIDTH), F32)
SPECS: dict[str, dict[str, tuple[tuple[int, ...], torch.dtype]]] = {
    "encfwd": {
        "x": IMAGE,
        "state_past": STATE,
        "valid_past": VALID,
        "feat": STATE,
        "fwd_out": STATE,
        "state": STATE,
    },
    "bwd": {
        "feat": STATE,
        "fwd_out": STATE,
        "state_future": STATE,
        "valid_future": VALID,
        "bwd_out": STATE,
        "state": STATE,
    },
    "head": {
        "x": IMAGE,
        "fwd_out": STATE,
        "bwd_out": STATE,
        "output": ((1, 3, HEIGHT * SCALE, WIDTH * SCALE), F32),
    },
}


@pytest.fixture(scope="module")
def model() -> Any:
    torch.manual_seed(0)
    network = SMoVSR(dim=DIM, h_clamp=30.0)
    with torch.no_grad():
        for parameter in network.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05)
    return SMoVSRArch().load(network.eval().state_dict()).model


class FakePart:
    """A part whose engine is the library's step on its bindings, logging each call's
    graph key."""

    def __init__(self, name: str, model: Any, log: list[Any]) -> None:
        self.name = name
        self.model = model
        self.log = log
        self.workspace = {"encfwd": 64, "bwd": 256, "head": 128}[name]
        self.graphs: dict[Any, Any] = {}

    def spec(self, name: str) -> tuple[tuple[int, ...], torch.dtype]:
        return SPECS[self.name][name]

    def tensor(self, name: str, device: torch.device) -> torch.Tensor:
        shape, dtype = self.spec(name)
        return torch.empty(shape, dtype=dtype, device=device)

    def use_memory(self, memory: torch.Tensor) -> None:
        assert memory.numel() >= self.workspace

    def call(self, key: Any, t: dict[str, torch.Tensor], _stream: Any) -> None:
        assert set(t) == set(SPECS[self.name])
        for name, tensor in t.items():
            assert (tuple(tensor.shape), tensor.dtype) == self.spec(name)
        self.log.append(key)
        with torch.inference_mode():
            if self.name == "encfwd":
                results = encode_forward(
                    self.model, t["x"], t["state_past"], t["valid_past"]
                )
                for name, value in zip(("feat", "fwd_out", "state"), results):
                    t[name].copy_(value)
            elif self.name == "bwd":
                results = backward_step(
                    self.model,
                    t["feat"],
                    t["fwd_out"],
                    t["state_future"],
                    t["valid_future"],
                )
                for name, value in zip(("bwd_out", "state"), results):
                    t[name].copy_(value)
            else:
                t["output"].copy_(head(self.model, t["x"], t["fwd_out"], t["bwd_out"]))

    def close(self) -> None:
        self.graphs.clear()


class FakeStream:
    def wait_stream(self, _other: object) -> None:
        pass

    def synchronize(self) -> None:
        pass


@pytest.fixture
def log(monkeypatch: pytest.MonkeyPatch) -> list[Any]:
    monkeypatch.setattr(torch.cuda, "set_device", lambda *_: None)
    monkeypatch.setattr(torch.cuda, "current_stream", lambda *_: None)
    monkeypatch.setattr(torch.cuda, "stream", lambda _: contextlib.nullcontext())
    return []


def session(model: Any, log: list[Any]) -> SMoVSRSession:
    return SMoVSRSession(
        cast(Any, {name: FakePart(name, model, log) for name in SPECS}),
        None,
        4000,
        FakeStream(),
        torch.device("cpu"),
        (HEIGHT, WIDTH, SCALE),
        "set",
    )


@pytest.fixture(scope="module")
def clip() -> list[torch.Tensor]:
    generator = torch.Generator().manual_seed(0)
    return [torch.rand(3, HEIGHT, WIDTH, generator=generator) for _ in range(24)]


def as_image(output: torch.Tensor) -> np.ndarray:
    return output.clamp(0, 1).permute(1, 2, 0).flip(2).numpy()


def hosts(frames: list[torch.Tensor]) -> list[torch.Tensor]:
    """RGB CHW frames as the session converts them: BGR HWC on the host."""
    return [f.permute(1, 2, 0).flip(2).contiguous() for f in frames]


def run(
    model: Any,
    log: list[Any],
    clip: list[torch.Tensor],
    windows: list[tuple[int, int, int]],
    s: SMoVSRSession | None = None,
) -> SMoVSRSession:
    """`windows` (first, count, keep) through a session and through run_window, each
    carrying the state from a window to the next one that starts where its kept frames
    end (a window elsewhere starts cold, as the planner starts one after a seek); every
    output equal."""
    s = session(model, log) if s is None else s
    past, carry, expected_next = None, None, None
    for first, count, keep in windows:
        frames = clip[first : first + count]
        if first != expected_next:
            past, carry = None, None
        outputs, state = s.run(hosts(frames), keep, past, first)
        with torch.inference_mode():
            want, carry = run_window(model, torch.stack(frames)[None], keep, carry)
        assert len(outputs) == keep
        for k, got in enumerate(outputs):
            assert np.array_equal(s.to_image(got), as_image(want[0, k])), (first, k)
        past = (state, frames[keep - 1])
        expected_next = first + keep
    return s


@pytest.mark.parametrize(
    "windows",
    [
        # chained windows of 6 frames keeping 3, the last to the clip's end
        [(0, 6, 3), (3, 6, 3), (6, 6, 6)],
        # the kept count growing after a cold start, as the planner grows it
        [(0, 5, 1), (1, 6, 2), (3, 8, 4), (7, 8, 8)],
        # a seek: a cold window in the middle of the clip, then on to its end
        [(0, 6, 3), (12, 6, 2), (14, 6, 6)],
        # a clip shorter than the window: one window keeping every frame
        [(0, 4, 4)],
        # one frame alone
        [(0, 1, 1)],
    ],
)
def test_windows_equal_run_window(
    model: Any,
    log: list[Any],
    clip: list[torch.Tensor],
    windows: list[tuple[int, int, int]],
):
    run(model, log, clip, windows)


def test_a_window_s_calls_and_their_validity(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    s = run(model, log, clip, [(0, 5, 3)])
    ring = len(s.slots)
    # no slot for a carried state: the sweep's own state goes on
    assert ring == 5

    # every frame encoded and swept forward once, cold at the first; the backward sweep
    # from the last frame (no future) down to the first, with a head right after each
    # kept frame's step
    assert log == [
        ("encfwd", 0, 0, False),
        *(("encfwd", i, i % 2, True) for i in range(1, 5)),
        ("bwd", 4, 0, False),
        ("bwd", 3, 1, True),
        ("bwd", 2, 0, True),
        ("head", 2),
        ("bwd", 1, 1, True),
        ("head", 1),
        ("bwd", 0, 0, True),
        ("head", 0),
    ]

    log.clear()
    run(model, log, clip, [(0, 5, 3), (3, 5, 5)], session(model, log))
    second = log[log.index(("head", 0)) + 1 :]

    # frames 3 and 4, which the first window swept forward, are not encoded again
    assert [key for key in second if key[0] == "encfwd"] == [
        ("encfwd", i % ring, i % 2, True) for i in range(5, 8)
    ]
    assert next(key for key in second if key[0] == "bwd") == ("bwd", 7 % ring, 1, False)


def test_a_cold_window_encodes_every_frame(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    s = session(model, log)
    s.run(hosts(clip[0:5]), 3, None, 0)
    log.clear()

    s.run(hosts(clip[3:8]), 5, None, 3)

    assert [key for key in log if key[0] == "encfwd"] == [
        ("encfwd", 3, 1, False),
        *(("encfwd", i % 5, i % 2, True) for i in range(4, 8)),
    ]


def test_a_carried_window_the_session_did_not_run_last_starts_cold(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    s = session(model, log)
    _, state = s.run(hosts(clip[0:5]), 3, None, 0)
    log.clear()

    # a carry for frame 4, after a window that kept frames 0-2: not this session's last
    outputs, _ = s.run(hosts(clip[4:8]), 4, (state, clip[3]), 4)

    assert log[0] == ("encfwd", 4 % len(s.slots), 0, False)
    with torch.inference_mode():
        want, _ = run_window(model, torch.stack(clip[4:8])[None], 4)
    for k, got in enumerate(outputs):
        assert np.array_equal(s.to_image(got), as_image(want[0, k]))


def test_a_rebuilt_session_has_a_key_of_its_own(model: Any, log: list[Any]):
    import gc

    first = session(model, log)
    key = first.key
    assert first.key == key
    # the first one freed before the second is made: its address may come back, its
    # key does not
    del first
    gc.collect()
    again = session(model, log)

    assert again.key != key


def test_outputs_and_states_are_the_callers(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    s = session(model, log)
    outputs, state = s.run(hosts(clip[0:5]), 3, None, 0)
    images = [s.to_image(o).copy() for o in outputs]
    kept = state.clone()

    s.run(hosts(clip[3:8]), 5, (state, clip[2]), 3)

    assert all(np.array_equal(s.to_image(o), i) for o, i in zip(outputs, images))
    assert torch.equal(state, kept)


def test_windows_and_frames_are_checked(model: Any, log: list[Any]):
    s = session(model, log)
    with pytest.raises(ValueError, match="cannot keep"):
        s.run([torch.zeros(3, HEIGHT, WIDTH)] * 3, 4, None, 0)
    with pytest.raises(ValueError, match="SMoVSR engine set takes 8x6"):
        s.convert(np.zeros((5, 8, 3), dtype=np.float32))


def test_the_look_ahead_is_the_library_s(model: Any, log: list[Any]):
    from spandrel.architectures.SMoVSR import LOOK_AHEAD

    assert session(model, log).look_ahead == LOOK_AHEAD


def test_the_memory_follows_the_bindings(model: Any, log: list[Any]):
    s = session(model, log)

    state = DIM * HEIGHT * WIDTH * 4
    frame = 3 * HEIGHT * WIDTH * 4
    output = 3 * HEIGHT * SCALE * WIDTH * SCALE * 4
    # one working memory, the largest part's; the output binding; the zero state, the
    # two backward and two forward states, the backward output and the staging frame;
    # two output images
    assert s.memory.fixed == 4000 + 256 + output + 6 * state + frame + 2 * output
    # a slot: its input, its encoding and forward output; the converted frame stays on
    # the host and no state is carried on the device
    assert s.memory.per_frame == frame + 2 * state
    assert (s.memory.carried, s.memory.extra_slots) == (0, 0)


@pytest.mark.parametrize("free_mib", [64, 8 * 1024, 30 * 1024])
def test_a_window_fits_the_free_memory(
    model: Any, log: list[Any], monkeypatch: pytest.MonkeyPatch, free_mib: int
):
    from nodes.impl.tensorrt.temporal_session import (
        ALLOCATOR_SHARE,
        OUTSIDE_ALLOCATOR_MARGIN,
    )

    free = free_mib * 2**20
    monkeypatch.setattr(torch.cuda, "mem_get_info", lambda _d: (free, 32 * 2**30))
    monkeypatch.setattr(torch.cuda, "memory_allocated", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "memory_reserved", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "get_per_process_memory_fraction", lambda _d: 1.0)
    s = session(model, log)
    # its ring as large as a window of 48 frames (K = 32 kept + 16 ahead) would need
    s.memory = type(s.memory)(
        fixed=2**20, per_frame=256 * 2**20, carried=2**20, extra_slots=0
    )

    ahead = s.fitting_ahead((HEIGHT, WIDTH), 47)

    budget = int(ALLOCATOR_SHARE * free) - OUTSIDE_ALLOCATOR_MARGIN
    if ahead < 0:
        assert s.memory.window_bytes(1) > budget
    else:
        assert s.memory.window_bytes(ahead + 1) <= budget
        assert ahead == 47 or s.memory.window_bytes(ahead + 2) > budget
    assert ahead == {64: -1, 8 * 1024: 27, 30 * 1024: 47}[free_mib]


def test_a_window_that_does_not_fit_keeps_fewer_frames_first(
    model: Any, log: list[Any]
):
    from nodes.impl.tensorrt.temporal_session import set_fit

    s = session(model, log)
    assert s.grows

    steps = set_fit("exhausted").steps(WIDTH, HEIGHT, 47, s.look_ahead)

    # the kept frames halve with all 16 ahead, then the look-ahead halves
    assert [ahead for ahead, _, _ in steps] == [47, 31, 23, 19, 17, 16, 8, 4, 2, 1, 0]


class View:
    """A loop's view of its items for Upscale Image's temporal path."""

    def __init__(self, frames: list[np.ndarray], ahead: int) -> None:
        self.frames, self.ahead, self.index = frames, ahead, 0
        self.state: Any = None
        self.unread = False

    def lookahead(self, _input: int) -> int:
        return self.ahead

    def peek(self, _input: int, offset: int) -> np.ndarray | None:
        at = self.index + offset
        return self.frames[at] if at < len(self.frames) else None


def test_the_planner_keeps_the_look_ahead_where_memory_caps_the_window(
    model: Any, log: list[Any], monkeypatch: pytest.MonkeyPatch
):
    from nodes.impl.pytorch import smovsr_window
    from nodes.impl.tensorrt.temporal_session import WindowMemory, set_fit
    from nodes.impl.upscale.basic_upscale import PaddingType
    from nodes.impl.upscale.temporal_window import temporal_upscale
    from nodes.impl.upscale.tile_report import TileReport

    mib = 2**20
    s = session(model, log)
    s.memory = WindowMemory(fixed=mib, per_frame=64 * mib, carried=mib, extra_slots=0)
    # The device's free memory less what the ring holds: a window of 20 frames fits.
    monkeypatch.setattr(
        torch.cuda,
        "mem_get_info",
        lambda _d: (1960 * mib - len(s.slots) * 64 * mib, 32 * 2**30),
    )
    monkeypatch.setattr(torch.cuda, "memory_allocated", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "memory_reserved", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "get_per_process_memory_fraction", lambda _d: 1.0)
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: 2**40)
    windows: list[tuple[int, int]] = []
    run = s.run

    def logged(frames: Any, keep: int, past: Any, first: int) -> Any:
        windows.append((len(frames), keep))
        return run(frames, keep, past, first)

    monkeypatch.setattr(s, "run", logged)
    generator = np.random.default_rng(0)
    frames = [generator.random((HEIGHT, WIDTH, 3), dtype=np.float32) for _ in range(40)]
    view = View(frames, 47)
    context = SimpleNamespace(iteration=view, node_id="node")
    for index in range(len(frames)):
        view.index = index
        out = temporal_upscale(
            cast(Any, context),
            frames[index],
            s,
            TileReport(),
            PaddingType.NONE,
            set_fit("exhausted"),
        )
        assert out.shape == (HEIGHT * SCALE, WIDTH * SCALE, 3)

    # growing after the cold start, then capped at about 21 frames (the ring, once
    # allocated, counts as room: 22): 16 of them always ahead, the last to the end
    assert windows[:3] == [(17, 1), (18, 2), (20, 4)]
    assert max(count for count, _ in windows) <= 22
    assert all(count - keep == 16 for count, keep in windows[:-1])
    assert windows[-1][0] == windows[-1][1]


def test_a_window_shorter_than_the_carry_encodes_no_frame_twice(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    # the second window ends before the first one's look-ahead does (a window the fit
    # shortened): frames 9-11, which the first swept forward, are not swept again by the
    # third. run_window takes no window shorter than its carry, so each window's
    # reference is one cold window from frame 0 to that window's last frame, keeping
    # up to its last kept one: the same exact forward sweep, the same backward start.
    s = session(model, log)
    past = None
    for first, count, keep in ((0, 12, 4), (4, 5, 2), (6, 10, 10)):
        frames = clip[first : first + count]
        outputs, state = s.run(hosts(frames), keep, past, first)
        past = (state, frames[keep - 1])
        with torch.inference_mode():
            want, _ = run_window(
                model, torch.stack(clip[: first + count])[None], first + keep
            )
        for k, got in enumerate(outputs):
            assert np.array_equal(s.to_image(got), as_image(want[0, first + k]))

    encoded = [key for key in log if key[0] == "encfwd"]
    ring = len(s.slots)
    assert encoded == [
        ("encfwd", 0, 0, False),
        *(("encfwd", i % ring, i % 2, True) for i in range(1, 16)),
    ]


def test_the_ring_grows_mid_run_and_the_carry_goes_on(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    s = session(model, log)
    run(model, log, clip, [(0, 5, 3)], s)
    assert len(s.slots) == 5
    for part in s.parts.values():
        part.graphs["kept"] = cast(Any, object())
    log.clear()

    # a longer window continuing the first: a larger ring, every graph dropped, the
    # slots of frames 3 and 4 placed anew with their work, which is not done again,
    # and the outputs those of run_window
    run(model, log, clip, [(0, 5, 3), (3, 12, 6)], s)

    assert len(s.slots) == 12
    assert all("kept" not in part.graphs for part in s.parts.values())
    second = log[log.index(("head", 0)) + 1 :]
    assert [key[1] for key in second if key[0] == "encfwd"] == [
        i % 12 for i in range(5, 15)
    ]


def test_an_out_of_memory_window_is_retried_shorter_keeping_its_look_ahead(
    model: Any, log: list[Any], monkeypatch: pytest.MonkeyPatch
):
    from nodes.impl.tensorrt.temporal_session import set_fit
    from nodes.impl.upscale.basic_upscale import PaddingType
    from nodes.impl.upscale.temporal_window import temporal_upscale
    from nodes.impl.upscale.tile_report import TileReport

    s = session(model, log)
    # no memory figures on the CPU: every window fits by them
    monkeypatch.setattr(
        type(s), "fitting_ahead", lambda _s, _shape, ahead, _c=None: ahead
    )
    windows: list[tuple[int, int]] = []
    run_ = s.run

    def failing(frames: Any, keep: int, past: Any, first: int) -> Any:
        windows.append((len(frames), keep))
        if len(frames) > 32:
            raise torch.OutOfMemoryError("CUDA out of memory (a test)")
        return run_(frames, keep, past, first)

    monkeypatch.setattr(s, "run", failing)
    generator = np.random.default_rng(0)
    frames = [generator.random((HEIGHT, WIDTH, 3), dtype=np.float32) for _ in range(80)]
    view = View(frames, 47)
    context = SimpleNamespace(iteration=view, node_id="node")
    for index in range(len(frames)):
        view.index = index
        temporal_upscale(
            cast(Any, context),
            frames[index],
            s,
            TileReport(),
            PaddingType.NONE,
            set_fit("exhausted"),
        )

    # the window of 48 failed once; the next step reads 31 ahead: 16 kept + 16 ahead
    failed = windows.index((48, 32))
    assert windows[failed + 1][0] <= 32
    assert all(c - k == 16 for c, k in windows[failed + 1 : -1])


def test_eight_gb_free_hold_a_window_of_one_kept_frame_and_its_look_ahead_at_1080p(
    monkeypatch: pytest.MonkeyPatch, log: list[Any]
):
    """The real bindings' sizes at 1920x1080 (on the meta device: nothing allocated), the
    engines' memory and working memory as measured (420 and 1012.5 MiB)."""
    from nodes.impl.pytorch import smovsr_window

    height, width, mib = 1080, 1920, 2**20
    state, image = ((1, 32, height, width), torch.float16), ((1, 3, height, width), F32)
    output = ((1, 3, 2 * height, 2 * width), F32)
    specs = {
        "encfwd": {
            "x": image,
            "state_past": state,
            "valid_past": VALID,
            "feat": state,
            "fwd_out": state,
            "state": state,
        },
        "bwd": {
            "feat": state,
            "fwd_out": state,
            "state_future": state,
            "valid_future": VALID,
            "bwd_out": state,
            "state": state,
        },
        "head": {"x": image, "fwd_out": state, "bwd_out": state, "output": output},
    }
    monkeypatch.setitem(globals(), "SPECS", specs)
    parts = {name: FakePart(name, None, log) for name in specs}
    parts["bwd"].workspace = int(1012.5 * mib)
    s = SMoVSRSession(
        cast(Any, parts),
        None,
        420 * mib,
        FakeStream(),
        torch.device("meta"),
        (height, width, 2),
        "set",
    )
    monkeypatch.setattr(torch.cuda, "memory_allocated", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "memory_reserved", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "get_per_process_memory_fraction", lambda _d: 1.0)
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: 2**40)

    def frames_fitting(free_gib: int) -> int:
        monkeypatch.setattr(
            torch.cuda, "mem_get_info", lambda _d: (free_gib * 2**30, 32 * 2**30)
        )
        return s.fitting_ahead((height, width), 47) + 1

    # 140 bytes per pixel and frame (276.9 MiB): 17 frames in 8 GiB (216 bytes: 10)
    assert s.memory.per_frame == 140 * height * width
    assert frames_fitting(8) >= 17
    assert frames_fitting(12) >= 31


def test_a_planner_that_outlived_its_session_starts_cold_with_the_new_one(
    model: Any, log: list[Any], monkeypatch: pytest.MonkeyPatch
):
    from nodes.impl.tensorrt.temporal_session import set_fit
    from nodes.impl.upscale.basic_upscale import PaddingType
    from nodes.impl.upscale.temporal_window import temporal_upscale
    from nodes.impl.upscale.tile_report import TileReport

    generator = np.random.default_rng(0)
    frames = [generator.random((HEIGHT, WIDTH, 3), dtype=np.float32) for _ in range(30)]
    view = View(frames, 23)
    context = SimpleNamespace(iteration=view, node_id="node")
    windows: list[tuple[int, bool]] = []

    def item(s: SMoVSRSession, index: int) -> None:
        view.index = index
        temporal_upscale(
            cast(Any, context),
            frames[index],
            s,
            TileReport(),
            PaddingType.NONE,
            set_fit("exhausted"),
        )

    sessions = [session(model, log), session(model, log)]
    for s in sessions:
        monkeypatch.setattr(s, "fitting_ahead", lambda _shape, ahead, _c=None: ahead)
        real = s.run

        def logged(f: Any, keep: int, past: Any, first: int, _real: Any = real) -> Any:
            windows.append((first, past is not None))
            return _real(f, keep, past, first)

        monkeypatch.setattr(s, "run", logged)
    for index in range(4):
        item(sessions[0], index)
    # the set's session dropped and rebuilt mid-run: the loop goes on with the new one
    for index in range(4, 30):
        item(sessions[1], index)

    assert windows[:3] == [(0, False), (1, True), (3, True)]
    # the new session's first window starts cold, then carries on
    assert windows[3] == (4, False)
    assert all(carried for _first, carried in windows[4:])


def test_the_ring_grows_by_the_missing_slots_only(
    model: Any,
    log: list[Any],
    clip: list[torch.Tensor],
    monkeypatch: pytest.MonkeyPatch,
):
    s = session(model, log)
    # a cold window: its slots hold no work the next cold window keeps
    s.run(hosts(clip[0:5]), 3, None, 0)
    made: list[int] = []
    new_slot = s.new_slot
    monkeypatch.setattr(s, "new_slot", lambda: made.append(1) or new_slot())

    run(model, log, clip, [(6, 12, 6)], s)

    assert len(s.slots) == 12
    assert len(made) == 12 - 5


class Driver:
    """Windows as the planner hands them to a session, each output against run_window;
    a window that runs out of memory leaves the planner's carry as it was."""

    def __init__(self, s: SMoVSRSession, model: Any, clip: list[torch.Tensor]) -> None:
        self.s, self.model, self.clip = s, model, clip
        self.past: Any = None
        self.carry: Any = None
        self.next: int | None = None

    def window(self, first: int, count: int, keep: int) -> bool:
        frames = self.clip[first : first + count]
        if first != self.next:
            self.past, self.carry = None, None
        try:
            outputs, state = self.s.run(hosts(frames), keep, self.past, first)
        except torch.OutOfMemoryError:
            return False
        with torch.inference_mode():
            want, self.carry = run_window(
                self.model, torch.stack(frames)[None], keep, self.carry
            )
        for k, got in enumerate(outputs):
            assert np.array_equal(self.s.to_image(got), as_image(want[0, k])), (
                first,
                k,
            )
        self.past = (state, frames[keep - 1])
        self.next = first + keep
        return True


def fail_once(monkeypatch: pytest.MonkeyPatch, part: Any, at: int) -> None:
    """`part`'s `at`-th call from now runs out of memory, once."""
    call = part.call
    calls = [0]

    def failing(key: Any, tensors: Any, stream: Any) -> None:
        calls[0] += 1
        if calls[0] == at:
            raise torch.OutOfMemoryError("CUDA out of memory (a test)")
        call(key, tensors, stream)

    monkeypatch.setattr(part, "call", failing)


def test_out_of_memory_mid_forward_sweep_then_a_shorter_window(
    model: Any,
    log: list[Any],
    clip: list[torch.Tensor],
    monkeypatch: pytest.MonkeyPatch,
):
    d = Driver(session(model, log), model, clip)
    assert d.window(0, 4, 1)
    assert d.window(1, 6, 2)
    fail_once(monkeypatch, d.s.parts["encfwd"], 3)
    assert not d.window(3, 12, 4)
    assert d.window(3, 8, 2)
    assert d.window(5, 10, 4)
    assert d.window(9, 10, 10)


def test_out_of_memory_in_a_backward_step_then_a_shorter_window(
    model: Any,
    log: list[Any],
    clip: list[torch.Tensor],
    monkeypatch: pytest.MonkeyPatch,
):
    d = Driver(session(model, log), model, clip)
    assert d.window(0, 6, 2)
    fail_once(monkeypatch, d.s.parts["bwd"], 2)
    assert not d.window(2, 12, 6)
    assert d.window(2, 5, 1)
    assert d.window(3, 4, 1)
    assert d.window(4, 14, 14)


def test_out_of_memory_while_the_ring_grows_changes_nothing(
    model: Any,
    log: list[Any],
    clip: list[torch.Tensor],
    monkeypatch: pytest.MonkeyPatch,
):
    d = Driver(session(model, log), model, clip)
    assert d.window(0, 4, 2)
    ring = list(d.s.slots)
    new_slot = d.s.new_slot
    made = [0]

    def failing() -> Any:
        made[0] += 1
        if made[0] == 3:
            raise torch.OutOfMemoryError("CUDA out of memory (a test)")
        return new_slot()

    monkeypatch.setattr(d.s, "new_slot", failing)
    assert not d.window(2, 12, 4)
    assert d.s.slots == ring
    assert d.window(2, 3, 1)
    assert d.window(3, 9, 9)


def test_a_cold_restart_at_the_next_frame(
    model: Any, log: list[Any], clip: list[torch.Tensor]
):
    d = Driver(session(model, log), model, clip)
    assert d.window(0, 6, 2)
    # a seek onto the frame the session would continue with: the planner starts cold
    d.next = None
    assert d.window(2, 6, 2)
    assert d.window(4, 6, 2)


def test_the_ram_plan_counts_the_page_locked_copies_in_power_of_two_blocks(
    model: Any, log: list[Any], monkeypatch: pytest.MonkeyPatch
):
    from nodes.impl.pytorch import smovsr_window

    s = session(model, log)
    monkeypatch.setattr(torch.cuda, "mem_get_info", lambda _d: (2**40, 2**41))
    monkeypatch.setattr(torch.cuda, "memory_allocated", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "memory_reserved", lambda _d: 0)
    monkeypatch.setattr(torch.cuda, "get_per_process_memory_fraction", lambda _d: 1.0)
    frame = 3 * HEIGHT * WIDTH * 4  # 576 bytes: blocks of 1024
    output = frame * SCALE * SCALE
    # 20 frames ahead: 20 of the loop's, 21 copies, 5 kept outputs; one byte short
    need = 20 * frame + 21 * 1024 + 5 * output
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: need)
    assert s.fitting_ahead((HEIGHT, WIDTH), 20) == 20
    monkeypatch.setattr(smovsr_window, "memory_budget", lambda: need - 1)
    assert s.fitting_ahead((HEIGHT, WIDTH), 20) < 20
