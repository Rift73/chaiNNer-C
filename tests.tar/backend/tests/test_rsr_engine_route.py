"""Upscale Image's Use TensorRT Engine for RSR (nodes/impl/pytorch/rdual_engine.py,
which serves both temporal models) on the CPU: RSR's set and session are stand-ins,
the PyTorch result is a small RSR's with random weights."""

from __future__ import annotations

import copy
import dataclasses
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast
from weakref import WeakKeyDictionary

import numpy as np
import pytest
import torch

# The route's padding runs in the native backend, which GitHub's checks do not build.
pytest.importorskip("nodes.impl._chainner_graph")
# cuda-python comes with the TensorRT package's dependencies, not with the runtime.
pytest.importorskip("cuda.bindings.runtime")
# spandrel before 0.4.2+c23 has no RSR.
pytest.importorskip("spandrel.architectures.RSR")

from spandrel.architectures.RSR import RSR, RSRArch
from test_rdual_engine_route import SET_INFO, Context, tensorrt_upscale
from test_tensorrt_rdual_nodes import load_engine, tensorrt_nodes

from api import NodeContext
from nodes.impl.compressed_file import Compression
from nodes.impl.pytorch import rdual_engine
from nodes.impl.pytorch.rdual_window import release_memory
from nodes.impl.pytorch.rsr_window import RSRWindows
from nodes.impl.pytorch.utils import is_out_of_memory
from nodes.impl.tensorrt import rdual, rdual_session, rsr, rsr_session
from nodes.impl.tensorrt.model import TemporalInfo, TensorRTEngine
from nodes.impl.tensorrt.rdual_engine_set import pack
from nodes.impl.upscale.basic_upscale import PaddingType
from nodes.impl.upscale.temporal_window import Fit
from nodes.impl.upscale.tile_report import TileReport
from nodes.impl.upscale.tiler import NoTiling
from packages.chaiNNer_pytorch.pytorch.io import load_model

SIZE = (16, 20)
RSR_INFO = dataclasses.replace(
    SET_INFO,
    precision="fp16",
    temporal=TemporalInfo("RSR", *SIZE, "", ("prefix", "revcore", "fwdcore")),
)


@pytest.fixture(scope="module")
def descriptor() -> Any:
    torch.manual_seed(0)
    model = RSR(width=8, hidden=8, depth=9, gates=3, context_width=8, heads=1, scale=2)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05 * (parameter == 0))
    return RSRArch().load(model.state_dict())


@pytest.fixture
def frame() -> np.ndarray:
    return np.random.default_rng(0).random((*SIZE, 3), dtype=np.float32)


def never(*_: Any) -> Any:
    raise AssertionError("RDUAL's engines ran for an RSR model")


@pytest.fixture
def route(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> dict[str, list[Any]]:
    """The machine allows a set; RSR's build and session are recorded stand-ins and
    RDUAL's must not run."""
    calls: dict[str, list[Any]] = {"build": [], "run": []}
    monkeypatch.setattr(rdual_engine, "hold_engine", lambda _node: None)
    monkeypatch.setattr(rdual_engine, "release_engine", lambda _node: None)
    monkeypatch.setattr(rdual_engine, "unavailable", lambda _model, _device: None)
    monkeypatch.setattr(rdual_engine, "_failed", WeakKeyDictionary())
    monkeypatch.setattr(rdual_engine, "_sets", WeakKeyDictionary())
    monkeypatch.setattr(rdual_engine, "cache_folder", lambda *_: tmp_path)

    def engine_set(_model: Any, height: int, width: int, *_: Any) -> TensorRTEngine:
        calls["build"].append((height, width))
        return TensorRTEngine(b"set", RSR_INFO)

    def upscale(_c: Any, img: np.ndarray, engine: Any, *_: Any) -> np.ndarray:
        calls["run"].append(engine)
        return np.full((img.shape[0] * 2, img.shape[1] * 2, 3), 0.5, np.float32)

    monkeypatch.setattr(rsr, "engine_set", engine_set)
    monkeypatch.setattr(rsr_session, "temporal_engine_upscale", upscale)
    monkeypatch.setattr(rdual, "engine_set", never)
    monkeypatch.setattr(rdual_session, "temporal_engine_upscale", never)
    return calls


def run(descriptor: Any, context: Context, img: np.ndarray) -> np.ndarray:
    fit = Fit(
        NoTiling(), shorten=True, out_of_memory=is_out_of_memory, release=release_memory
    )
    return rdual_engine.temporal_upscale_through_engine(
        cast(NodeContext, context),
        img,
        descriptor,
        torch.device("cpu"),
        lambda: RSRWindows(descriptor, torch.device("cpu"), 0, False),
        0,
        TileReport(),
        PaddingType.NONE,
        fit,
    )


def pytorch(descriptor: Any, img: np.ndarray) -> np.ndarray:
    windows = RSRWindows(descriptor, torch.device("cpu"), 0, False)
    outputs, _ = windows.run([windows.convert(img)], 1, None, 0)
    return windows.to_image(outputs[0])


def test_a_set_is_built_from_the_model_s_full_precision_weights(
    descriptor: Any,
    route: dict[str, list[Any]],
    frame: np.ndarray,
    monkeypatch: pytest.MonkeyPatch,
):
    # A model Load Model loaded in FP16 exports its set from its FP32 weights, as
    # Convert To ONNX does, and the set's key hashes those.
    full = copy.deepcopy(descriptor)
    asked: list[tuple[Any, str]] = []
    built: list[Any] = []

    def source(model: Any, node: str) -> Any:
        asked.append((model, node))
        return full

    def engine_set(model: Any, *_: Any) -> TensorRTEngine:
        built.append(model)
        return TensorRTEngine(b"set", RSR_INFO)

    monkeypatch.setattr(load_model, "full_precision_source", source)
    monkeypatch.setattr(rsr, "engine_set", engine_set)
    run(descriptor, Context(), frame)
    assert asked == [(descriptor, "Use TensorRT Engine")]
    assert built == [full]


def test_an_rsr_model_runs_through_rsr_s_set(
    descriptor: Any, route: dict[str, list[Any]], frame: np.ndarray
):
    context = Context()
    out = run(descriptor, context, frame)
    again = run(descriptor, context, frame)

    assert np.all(out == 0.5) and np.all(again == 0.5)
    # built once for the model and size, then kept
    assert route["build"] == [SIZE]
    assert [e.info.temporal.architecture for e in route["run"]] == ["RSR", "RSR"]
    assert context.warnings == []


def test_a_failed_build_warns_and_the_chain_stays_on_pytorch(
    descriptor: Any,
    route: dict[str, list[Any]],
    frame: np.ndarray,
    monkeypatch: pytest.MonkeyPatch,
):
    def fails(*_: Any) -> TensorRTEngine:
        raise RuntimeError("no build here")

    monkeypatch.setattr(rsr, "engine_set", fails)
    context = Context()
    out = run(descriptor, context, frame)

    np.testing.assert_array_equal(out, pytorch(descriptor, frame))
    assert context.warnings == [
        (
            "Upscale Image runs this RSR model on PyTorch, not through a TensorRT"
            " engine: RuntimeError: no build here"
        )
    ]


def test_a_failed_frame_goes_on_with_pytorch(
    descriptor: Any,
    route: dict[str, list[Any]],
    frame: np.ndarray,
    monkeypatch: pytest.MonkeyPatch,
):
    def fails(*_: Any) -> np.ndarray:
        raise RuntimeError("the set failed")

    monkeypatch.setattr(rsr_session, "temporal_engine_upscale", fails)
    context = Context()
    out = run(descriptor, context, frame)

    np.testing.assert_array_equal(out, pytorch(descriptor, frame))
    assert len(context.warnings) == 1
    assert context.warnings[0].endswith("RuntimeError: the set failed")


def test_rsr_models_of_the_checked_scales_have_sets(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(rdual_engine, "no_engine_here", lambda _device: None)
    monkeypatch.setattr(rdual_engine, "migraphx_here", lambda: False)
    gpu = torch.device("cuda")

    assert rsr.CHECKED_SCALES == (1, 2, 4)
    assert rdual_engine.unavailable(descriptor, gpu) is None
    three = SimpleNamespace(architecture=descriptor.architecture, scale=3)
    assert "RSR's engines are checked" in str(
        rdual_engine.unavailable(cast(Any, three), gpu)
    )
    monkeypatch.setattr(rdual_engine, "migraphx_here", lambda: True)
    # On AMD GPUs the model stays on PyTorch without a warning.
    assert rdual_engine.unavailable(descriptor, gpu) == ""


# TensorRT's nodes on an RSR set


def rsr_set() -> TensorRTEngine:
    assert RSR_INFO.temporal is not None
    parts = {n: bytes([i]) * 2000 for i, n in enumerate(RSR_INFO.temporal.parts)}
    return pack(parts, RSR_INFO)


def test_tensorrt_upscale_image_runs_an_rsr_set_by_its_architecture(
    route: dict[str, list[Any]], frame: np.ndarray, monkeypatch: pytest.MonkeyPatch
):
    nodes = tensorrt_upscale()
    monkeypatch.setattr(nodes, "get_settings", lambda _: SimpleNamespace(gpu_index=0))
    engine = rsr_set()
    out, _ = nodes.engine_upscale(
        cast(NodeContext, Context()), frame, engine, True, True
    )

    assert np.all(out == 0.5) and route["run"] == [engine]


def test_tensorrt_upscale_image_refuses_an_unknown_architecture(
    route: dict[str, list[Any]], frame: np.ndarray, monkeypatch: pytest.MonkeyPatch
):
    nodes = tensorrt_upscale()
    monkeypatch.setattr(nodes, "get_settings", lambda _: SimpleNamespace(gpu_index=0))
    assert RSR_INFO.temporal is not None
    info = dataclasses.replace(
        RSR_INFO, temporal=dataclasses.replace(RSR_INFO.temporal, architecture="XYZ")
    )

    with pytest.raises(ValueError, match="XYZ"):
        nodes.engine_upscale(
            cast(NodeContext, Context()),
            frame,
            TensorRTEngine(b"set", info),
            True,
            True,
        )
    assert route["run"] == []


def test_get_engine_info_shows_an_rsr_set():
    info_node = tensorrt_nodes(
        "utility.get_engine_info", "get_engine_info_node"
    ).get_engine_info_node

    scale, precision, _, _, shape, temporal = info_node(rsr_set())

    assert (scale, precision, shape) == (2, "FP16", "Fixed: 16x20")
    assert temporal == (
        "RSR engine set: 20x16 frames (width x height), engines prefix, revcore,"
        " fwdcore"
    )


def test_save_and_load_engine_carry_an_rsr_set(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    saved = rsr_set()
    save = tensorrt_nodes("io.save_engine", "save_engine_node").save_engine_node
    save(saved, tmp_path, "rsr", True, Compression.LZMA)
    (path,) = tmp_path.iterdir()

    loaded = load_engine(monkeypatch, path)

    assert loaded.bytes == saved.bytes and loaded.info == RSR_INFO


def test_image_paths_refuse_an_rsr_set():
    from nodes.impl.tensorrt.engine_info import deserialize_engine

    with pytest.raises(ValueError, match="RSR engine set"):
        deserialize_engine(rsr_set().bytes, 0)
