"""Temporal Fix's real window part cut at its direct kernels (nodes/impl/tensorrt/
tfix_cut.py), on the CPU and without Triton: the pieces run one after the other in ONNX
Runtime give exactly the whole graph's tensors (tfix_cut_standins.py, run in a process
of its own, where stand-ins replace Triton and TensorRT's plugin module if they are not
installed), at a size where both kernels cut and one where only the confidence's does."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

pytest.importorskip("onnxruntime")

HERE = Path(__file__).parent


@pytest.mark.parametrize(
    ("size", "kernels"),
    [((32, 48), ["block_input", "conf_input"]), ((34, 50), ["conf_input"])],
)
def test_the_real_window_s_pieces_give_the_whole_graph_s_tensors(
    size: tuple[int, int], kernels: list[str]
):
    environment = {
        **os.environ,
        "CUDA_VISIBLE_DEVICES": "-1",
        "PYTHONPATH": os.pathsep.join(
            [str(HERE.parent / "src"), os.environ.get("PYTHONPATH", "")]
        ),
    }
    done = subprocess.run(
        [sys.executable, str(HERE / "tfix_cut_standins.py"), *map(str, size)],
        capture_output=True,
        text=True,
        env=environment,
        timeout=600,
        check=False,
    )
    assert done.returncode == 0, done.stderr[-3000:]
    result = json.loads(done.stdout.strip().splitlines()[-1])
    assert result["kernels"] == kernels
    assert len(result["equal"]) == len(kernels) + 1
    assert all(result["equal"].values()), result
