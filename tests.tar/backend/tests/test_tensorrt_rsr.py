"""RSR's engine sets on the app side (nodes/impl/tensorrt/rsr.py, rsr_export.py): the
set's key, the weights the export reads, the export's graphs, the set's container; and
on a GPU, a small set built and run by its session against the library's windows."""

from __future__ import annotations

import dataclasses
import sys
from collections import OrderedDict
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import onnx
import pytest
import torch

pytest.importorskip("spandrel.architectures.RSR")

from spandrel.architectures.RSR import RSR, RSRArch, run_window
from spandrel.architectures.RSR.__arch.rsr_arch import rsr_compact

from nodes.impl.tensorrt import build_cache, rdual, rsr, rsr_engine_worker, rsr_export
from nodes.impl.tensorrt.model import TemporalInfo, TensorRTEngineInfo
from nodes.impl.tensorrt.rdual_engine_set import pack, unpack

PARTS = rsr_export.PARTS
INFO = TensorRTEngineInfo(
    precision="fp16",
    input_channels=3,
    output_channels=3,
    scale=2,
    gpu_architecture="sm_120",
    tensorrt_version="11.4.0",
    has_dynamic_shapes=False,
    min_shape=(1, 3, 64, 96),
    opt_shape=(1, 3, 64, 96),
    max_shape=(1, 3, 64, 96),
    temporal=TemporalInfo("RSR", 64, 96, "", PARTS),
)


def compact(scale: int, seed: int = 0) -> Any:
    """An RSR Compact whose zero weights (the temporal read's included) have values,
    so that the neighbours change the output, loaded as the app loads a file."""
    torch.manual_seed(seed)
    model = rsr_compact(scale=scale)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05 * (parameter == 0))
    return RSRArch().load(model.eval().state_dict())


@pytest.fixture(scope="module")
def descriptor() -> Any:
    return compact(2)


@pytest.fixture
def machine(monkeypatch: pytest.MonkeyPatch) -> None:
    """A GPU and TensorRT as the key reads them."""
    # memory.py imports CUDA's bindings, which GitHub's checks do not install.
    pytest.importorskip("cuda.bindings.runtime")
    from nodes.impl.tensorrt import memory

    monkeypatch.setitem(sys.modules, "tensorrt", SimpleNamespace(__version__="11.4.0"))
    monkeypatch.setattr(memory, "get_cuda_device_name", lambda _i: "GPU")
    monkeypatch.setattr(memory, "get_cuda_compute_capability", lambda _i: (12, 0))


@pytest.mark.usefixtures("machine")
def test_the_key_follows_the_size_the_weights_and_the_recipe(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    key = rsr.engine_key(descriptor, 64, 96, 0)

    assert rsr.engine_key(descriptor, 64, 96, 0) == key
    assert rsr.engine_key(descriptor, 96, 64, 0) != key
    assert rsr.engine_key(compact(2, seed=1), 64, 96, 0) != key
    monkeypatch.setattr(rsr, "recipe_identity", lambda: "another recipe")
    assert rsr.engine_key(descriptor, 64, 96, 0) != key


def test_the_export_reads_the_folded_model_back(descriptor: Any, tmp_path: Path):
    weights = rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")

    read = rsr_export.load(weights)

    mine, theirs = descriptor.model.state_dict(), read.state_dict()
    assert mine.keys() == theirs.keys()
    assert all(torch.equal(mine[k], theirs[k]) for k in mine)
    # the attention's deployment scale, which the state dict does not hold
    scale, loaded = read.attention.export_scale, descriptor.model.attention.export_scale
    assert isinstance(scale, torch.Tensor) and isinstance(loaded, torch.Tensor)
    assert torch.equal(scale, loaded)
    frames = torch.rand(1, 3, 3, 20, 24)
    with torch.inference_mode():
        assert torch.equal(
            run_window(read, frames, 2)[0], run_window(descriptor.model, frames, 2)[0]
        )


def test_the_export_child_gets_the_weights_and_the_size(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    seen: list[list[str]] = []

    def child(arguments: list[str], *_: Any, **kwargs: Any) -> str:
        seen.append(arguments)
        assert kwargs == {"cpu_only": True}
        assert rsr_export.load(Path(arguments[2])).scale == 2
        Path(arguments[3]).mkdir()
        (Path(arguments[3]) / "export.json").write_text("{}", encoding="utf-8")
        return ""

    monkeypatch.setattr(rsr, "run_child", child)
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)

    rsr.export(descriptor, 64, 96, tmp_path / "export", 0)

    ((module, _weights, folder, height, width, device),) = [s[1:] for s in seen]
    assert (module, folder, height, width, device) == (
        "nodes.impl.tensorrt.rsr_export",
        str(tmp_path / "export"),
        "64",
        "96",
        "cpu",
    )


def test_the_parts_compute_in_fp16_with_fp32_images_and_resizes(
    descriptor: Any, tmp_path: Path
):
    folded = rsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    graphs = rsr_export.parts(folded, 20, 24, "cpu")

    types = onnx.TensorProto
    for name, graph in graphs.items():
        bindings = {
            v.name: (
                v.type.tensor_type.elem_type,
                tuple(d.dim_value for d in v.type.tensor_type.shape.dim),
            )
            for v in (*graph.graph.input, *graph.graph.output)
        }
        for binding, (elem, shape) in bindings.items():
            # static inputs; TensorRT infers the outputs' shapes from them
            if binding in {v.name for v in graph.graph.input}:
                assert all(shape), (name, binding, shape)
            if binding in rsr_export.IMAGE_BINDINGS:
                assert elem == types.FLOAT
            elif binding in rsr_export.VALIDITY_BINDINGS:
                assert (elem, shape) == (types.BOOL, (1,))
            else:
                assert elem == types.FLOAT16, (name, binding)
        produced = {o: n for n in graph.graph.node for o in n.output}
        for node in graph.graph.node:
            if node.op_type == "Resize":
                source = produced[node.input[0]]
                assert source.op_type == "Cast"
                assert source.attribute[0].i == types.FLOAT
    assert set(graphs) == set(PARTS)
    assert [v.name for v in graphs["revcore"].graph.input] == [
        "current6",
        "c3",
        "c4",
        "state_future",
        "valid_future",
    ]
    assert [v.name for v in graphs["fwdcore"].graph.output] == ["output", "state"]


def test_a_shape_without_a_gate_before_the_attention_exports(tmp_path: Path):
    # depth 9 with 2 gates: none before the attention stage, so the prefix has no Resize
    torch.manual_seed(0)
    model = RSR(width=8, hidden=8, depth=9, gates=2, context_width=8, heads=1, scale=2)
    descriptor = RSRArch().load(model.eval().state_dict())
    folded = rsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    assert rsr_export.gates(folded) == (0, 2)

    graphs = rsr_export.parts(folded, 20, 24, "cpu")

    resizes = {
        name: sum(n.op_type == "Resize" for n in graph.graph.node)
        for name, graph in graphs.items()
    }
    assert resizes == {"prefix": 0, "revcore": 2, "fwdcore": 2}


def test_a_part_with_another_number_of_resizes_is_refused(
    descriptor: Any, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    folded = rsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    # Compact: the gate at 3 before the attention, those at 6 and 9 after it
    assert rsr_export.gates(folded) == (1, 2)
    monkeypatch.setattr(rsr_export, "fp32_resize", lambda _model: 0)

    with pytest.raises(RuntimeError, match="found 0 Resizes"):
        rsr_export.parts(folded, 20, 24, "cpu")


class Tensor:
    def __init__(self, name: str, channels: int) -> None:
        self.name = name
        self.shape = (1, channels, 6, 8)
        self.allowed_formats = 0


class Network:
    """A parsed part's bindings, as rsr_engine_worker.channel_last reads them."""

    def __init__(self, inputs: list[Tensor], outputs: list[Tensor]) -> None:
        self.inputs, self.outputs = inputs, outputs
        self.num_inputs, self.num_outputs = len(inputs), len(outputs)

    def get_input(self, index: int) -> Tensor:
        return self.inputs[index]

    def get_output(self, index: int) -> Tensor:
        return self.outputs[index]


@pytest.mark.parametrize(
    ("width", "context", "expected"),
    [
        # Compact: every handoff
        (32, 64, ["current6", "c3", "c4", "state_past", "state_future", "state"]),
        # channels that HWC8 would pad stay linear
        (20, 64, ["c3", "c4"]),
        (20, 12, []),
    ],
)
def test_handoffs_are_channel_last_only_at_multiples_of_8(
    width: int, context: int, expected: list[str]
):
    trt = pytest.importorskip("tensorrt")
    inputs = [
        Tensor("x", 3),
        Tensor("current6", width),
        Tensor("c3", context),
        Tensor("c4", context),
        Tensor("state_past", width),
        Tensor("valid_past", 1),
        Tensor("state_future", width),
        Tensor("valid_future", 1),
    ]
    outputs = [Tensor("output", 3), Tensor("state", width)]

    # the fake has only what channel_last reads of an INetworkDefinition
    names = rsr_engine_worker.channel_last(cast(Any, Network(inputs, outputs)))

    assert names == expected
    hwc8 = 1 << int(trt.TensorFormat.HWC8)
    for tensor in inputs + outputs:
        assert tensor.allowed_formats == (hwc8 if tensor.name in expected else 0)


def test_the_recipe_covers_the_save_the_export_uses():
    assert "rdual_export.py" in {path.name for path in rsr.RECIPE_SOURCES}


def test_a_set_is_one_container_named_rsr(tmp_path: Path):
    data = {name: bytes([i]) * (500 + i) for i, name in enumerate(PARTS)}

    info, parts = unpack(pack(data, INFO).bytes)

    assert parts == data
    assert dataclasses.asdict(info) == dataclasses.asdict(INFO)
    assert info.temporal is not None and info.temporal.architecture == "RSR"


def test_set_info_names_the_architecture_and_its_parts(
    monkeypatch: pytest.MonkeyPatch,
):
    pytest.importorskip("cuda.bindings.runtime")
    from nodes.impl.tensorrt import memory

    monkeypatch.setitem(sys.modules, "tensorrt", SimpleNamespace(__version__="11.4.0"))
    monkeypatch.setattr(memory, "get_cuda_compute_capability", lambda _i: (12, 0))
    manifest = {"height": 64, "width": 96, "scale": 2, "parts": dict.fromkeys(PARTS)}

    assert rsr.set_info(manifest, 0) == INFO


def test_a_set_is_kept_in_a_cache_folder_made_for_it(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    monkeypatch.setattr(build_cache, "_memory", OrderedDict())
    monkeypatch.setattr(rsr, "engine_key", lambda *_: "rsr-key")
    data = {name: bytes([i]) * 100 for i, name in enumerate(PARTS)}
    monkeypatch.setattr(rsr, "build_set", lambda *_: pack(data, INFO))
    folder = tmp_path / "cache"

    engine = rsr.engine_set(descriptor, 64, 96, 0, str(folder))

    assert unpack(engine.bytes)[1] == data
    assert [p.name for p in folder.iterdir()] == [f"rsr-key{build_cache.SUFFIX}"]


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
def test_a_set_builds_and_matches_pytorch_across_windows():
    pytest.importorskip("tensorrt")
    from nodes.impl.tensorrt.rsr_session import open_session

    descriptor = compact(2)
    height, width = 64, 64
    engine = rsr.build_set(descriptor, height, width, 0)
    generator = torch.Generator().manual_seed(1)
    clip = torch.rand(1, 9, 3, height, width, generator=generator)
    # two windows of 5 frames as the app runs them: the first keeps 4, the second
    # (at the clip's end) all 5, with the state and the shared frame carried
    windows = ((0, 5, 4), (4, 5, 5))
    session = open_session(engine, 0)
    try:
        frames = [
            session.convert(np.ascontiguousarray(f.permute(1, 2, 0).flip(-1).numpy()))
            for f in clip[0]
        ]
        got, past = [], None
        for first, count, keep in windows:
            outputs, state = session.run(
                frames[first : first + count], keep, past, first
            )
            got += [session.to_image(o) for o in outputs]
            past = (state, frames[first + keep - 1])
    finally:
        session.close()
    model = descriptor.model.float().cuda().eval()
    expected, carry = [], None
    with torch.inference_mode():
        for first, count, keep in windows:
            out, carry = run_window(
                model, clip[:, first : first + count].cuda(), keep, carry
            )
            expected += list(
                out[0].clamp(0, 1).permute(0, 2, 3, 1).flip(-1).cpu().numpy()
            )
    assert len(got) == len(expected) == 9
    for image, reference in zip(got, expected, strict=True):
        assert image.shape == reference.shape == (2 * height, 2 * width, 3)
        # FP16 engines against FP32: this model's PyTorch FP16 differs by about as much.
        assert float(np.sqrt(((image - reference) ** 2).mean())) <= 2e-3
