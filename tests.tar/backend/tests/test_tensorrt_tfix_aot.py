"""Temporal Fix's AOT plugin (nodes/impl/tensorrt/tfix_aot.py): the round trips' lowering,
without a GPU, and the round-trip kernel against PyTorch's chain on the card."""

from __future__ import annotations

import numpy as np
import onnx
import pytest
import torch
from onnx import TensorProto, helper, numpy_helper
from torch.nn import functional

# Needs TensorRT and Triton (the engine build's environment).
tfix_aot = pytest.importorskip("nodes.impl.tensorrt.tfix_aot")
kernel = pytest.importorskip("nodes.impl.tensorrt.tfix_round_trip_kernel")

N, H, W = 2, 6, 10
BINOMIAL = np.array([1.0, 4.0, 6.0, 4.0, 1.0]) / 16.0


def _resize(source: str, output: str, size: list[int], nodes: list) -> None:
    sizes = output + "/sizes"
    nodes.append(
        helper.make_node(
            "Constant",
            [],
            [sizes],
            value=numpy_helper.from_array(np.array(size, np.int64), sizes),
        )
    )
    nodes.append(
        helper.make_node(
            "Resize",
            [source, "", "", sizes],
            [output],
            mode="linear",
            coordinate_transformation_mode="half_pixel",
        )
    )


def _model(
    channels: int, scales: list[float] | None, weight: np.ndarray
) -> onnx.ModelProto:
    """x (half size) -> Resize 2x -> [per-channel Slice * scale, Concat] -> depthwise
    5x5 Conv -> Resize back -> y, as the exporter writes the network's round trips."""
    nodes: list = []
    initializers = [numpy_helper.from_array(weight.astype(np.float16), "weight")]
    _resize("x", "up", [N, channels, 2 * H, 2 * W], nodes)
    filtered_input = "up"
    if scales is not None:
        parts = []
        for c, k in enumerate(scales):
            bounds = [f"s{c}", f"e{c}", "axis"]
            initializers += [
                numpy_helper.from_array(np.array([c], np.int64), bounds[0]),
                numpy_helper.from_array(np.array([c + 1], np.int64), bounds[1]),
            ]
            initializers.append(
                numpy_helper.from_array(np.array([k], np.float16), f"k{c}")
            )
            nodes.append(helper.make_node("Slice", ["up", *bounds], [f"slice{c}"]))
            nodes.append(helper.make_node("Mul", [f"slice{c}", f"k{c}"], [f"part{c}"]))
            parts.append(f"part{c}")
        initializers.append(numpy_helper.from_array(np.array([1], np.int64), "axis"))
        nodes.append(helper.make_node("Concat", parts, ["scaled"], axis=1))
        filtered_input = "scaled"
    nodes.append(
        helper.make_node(
            "Conv",
            [filtered_input, "weight"],
            ["filtered"],
            group=channels,
            kernel_shape=[5, 5],
            pads=[2, 2, 2, 2],
        )
    )
    _resize("filtered", "y", [N, channels, H, W], nodes)
    graph = helper.make_graph(
        nodes,
        "round_trip",
        [helper.make_tensor_value_info("x", TensorProto.FLOAT16, [N, channels, H, W])],
        [helper.make_tensor_value_info("y", TensorProto.FLOAT16, [N, channels, H, W])],
        initializers,
    )
    return helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])


def _binomial(channels: int) -> np.ndarray:
    return np.repeat(np.outer(BINOMIAL, BINOMIAL)[None, None], channels, 0)


def test_a_round_trip_lowers_to_one_plugin_reading_the_half_size_map():
    lowered = tfix_aot.lower(_model(1, None, _binomial(1)))
    assert [p.op for p in lowered.plugins] == [
        tfix_aot.round_trip_name(N, 1, H, W, 5, 16)
    ]
    plugin = lowered.plugins[0]
    assert plugin.inputs[0] == "x"
    assert plugin.outputs == ["y"]
    stand_in = next(n for n in lowered.model.graph.node if list(n.output) == ["y"])
    assert stand_in.op_type == "Identity"
    assert set(lowered.readers.values()) == set(plugin.inputs)


def test_a_flow_s_channel_scales_become_the_plugin_s_scale_input():
    lowered = tfix_aot.lower(_model(2, [2.0, 2.0], _binomial(2)))
    (plugin,) = lowered.plugins
    scale = next(
        t for t in lowered.model.graph.initializer if t.name == plugin.inputs[5]
    )
    assert numpy_helper.to_array(scale).tolist() == [2.0, 2.0]


@pytest.mark.parametrize("change", [0.1, 5e-4])
def test_a_filter_that_is_not_separable_stays_in_the_graph(change: float):
    # 5e-4: one tap off by an eighth of its value, which the kernel's separable taps
    # cannot compute
    weight = _binomial(1)
    weight[0, 0, 0, 0] += change
    lowered = tfix_aot.lower(_model(1, None, weight))
    assert lowered.plugins == []
    assert [n.op_type for n in lowered.model.graph.node].count("Conv") == 1


def test_the_taps_are_the_composed_chain_with_its_borders():
    index, weight = kernel.taps(H, BINOMIAL)
    x = np.random.default_rng(0).standard_normal(H)
    direct = functional.interpolate(
        torch.from_numpy(x)[None, None],
        size=2 * H,
        mode="linear",
        align_corners=False,
    )
    k = torch.from_numpy(BINOMIAL)[None, None]
    direct = functional.conv1d(direct, k, padding=2)
    direct = functional.interpolate(direct, size=H, mode="linear", align_corners=False)[
        0, 0
    ]
    composed = (x[index] * weight).sum(1)
    np.testing.assert_allclose(composed, direct.numpy(), atol=1e-6)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
@pytest.mark.parametrize("channels_last", [False, True])
def test_the_kernel_matches_pytorch_s_chain(channels_last: bool):
    c, h, w = 2, 36, 52
    x = torch.rand(N, c, h, w, device="cuda") * 8 - 4
    up = functional.interpolate(
        x, size=(2 * h, 2 * w), mode="bilinear", align_corners=False
    )
    weight = torch.from_numpy(_binomial(c)).float().cuda()
    filtered = functional.conv2d(up * 2.0, weight, padding=2, groups=c)
    expected = functional.interpolate(
        filtered, size=(h, w), mode="bilinear", align_corners=False
    )
    ih, ch = kernel.taps(h, BINOMIAL)
    iw, cw = kernel.taps(w, BINOMIAL)
    tables = [torch.from_numpy(t).cuda() for t in (ih, ch, iw, cw)]
    source = x.half()
    if channels_last:
        source = source.permute(0, 2, 3, 1).contiguous()
    y = torch.empty_like(source)
    kernel.round_trip[kernel.grid(N * c, h, w)](
        source,
        *tables,
        torch.full((c,), 2.0, device="cuda"),
        y,
        h,
        w,
        c,
        ih.shape[1],
        channels_last,
        **kernel.LAUNCH,
    )
    if channels_last:
        y = y.permute(0, 3, 1, 2)
    torch.testing.assert_close(y.float(), expected, atol=2e-2, rtol=2e-3)


conf_kernel = pytest.importorskip("nodes.impl.tensorrt.tfix_conf_input_kernel")


def _conf_model() -> onnx.ModelProto:
    """The confidence head's input as the exporter writes it: centre, the full-size
    warped frames low-passed and halved, |difference|, centre features, the support
    features sampled along the grid, |difference|, flow, its norm, time offset."""
    s, h, w = 2, 4, 6
    nodes: list = []
    initializers = [numpy_helper.from_array(_binomial(3).astype(np.float16), "lp")]
    nodes.append(
        helper.make_node(
            "Conv",
            ["full", "lp"],
            ["filtered"],
            group=3,
            kernel_shape=[5, 5],
            pads=[2, 2, 2, 2],
        )
    )
    _resize("filtered", "warped", [s, 3, h, w], nodes)
    nodes += [
        helper.make_node("Sub", ["warped", "centre"], ["d1"]),
        helper.make_node("Abs", ["d1"], ["a1"]),
        helper.make_node(
            "GridSample",
            ["features", "grid"],
            ["sampled"],
            mode="bilinear",
            padding_mode="zeros",
            align_corners=0,
        ),
        helper.make_node("Sub", ["sampled", "fcentre"], ["d2"]),
        helper.make_node("Abs", ["d2"], ["a2"]),
        helper.make_node("ReduceL2", ["flow"], ["norm"], axes=[1], keepdims=1),
        helper.make_node(
            "Concat",
            [
                "centre",
                "warped",
                "a1",
                "fcentre",
                "sampled",
                "a2",
                "flow",
                "norm",
                "delta",
            ],
            ["x"],
            axis=1,
        ),
    ]
    value = helper.make_tensor_value_info
    f16 = TensorProto.FLOAT16
    inputs = [
        value("full", f16, [s, 3, 2 * h, 2 * w]),
        value("centre", f16, [s, 3, h, w]),
        value("fcentre", f16, [s, 4, h, w]),
        value("features", f16, [s, 4, h, w]),
        value("grid", f16, [s, h, w, 2]),
        value("flow", f16, [s, 2, h, w]),
        value("delta", f16, [s, 1, h, w]),
    ]
    graph = helper.make_graph(
        nodes, "conf_input", inputs, [value("x", f16, [s, 25, h, w])], initializers
    )
    return helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])


def test_the_confidence_input_lowers_to_one_plugin_on_the_full_size_frames():
    lowered = tfix_aot.lower(_conf_model())
    (plugin,) = lowered.plugins
    assert plugin.op == tfix_aot.conf_input_name(2, 4, 6, 16)
    assert plugin.inputs == [
        "centre",
        "full",
        "fcentre",
        "features",
        "grid",
        "flow",
        "delta",
    ]
    assert plugin.outputs == ["x"]


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
@pytest.mark.parametrize("padded_rows", [False, True])
def test_the_confidence_kernel_matches_the_network_s_ops(padded_rows: bool):
    s, h, w = 3, 20, 28
    g = torch.Generator(device="cuda").manual_seed(0)

    def rand(*shape: int) -> torch.Tensor:
        return torch.rand(*shape, device="cuda", generator=g)

    centre = rand(s, 3, h, w).half()
    full = rand(s, 3, 2 * h, 2 * w).half()
    fcentre = (rand(s, 4, h, w) * 2 - 1).half()
    features = (rand(s, 4, h, w) * 2 - 1).half()
    flow = ((rand(s, 2, h, w) - 0.5) * 8).half()
    grid = ((rand(s, h, w, 2) * 2.4) - 1.2).half()
    delta = rand(s, 1, h, w).half()
    weight = torch.from_numpy(_binomial(3)).float().cuda()
    filtered = functional.conv2d(full.float(), weight, padding=2, groups=3)
    warped = functional.interpolate(
        filtered, size=(h, w), mode="bilinear", align_corners=False
    )
    warped = warped.half().float()
    sampled = functional.grid_sample(
        features.float(), grid.float(), padding_mode="zeros", align_corners=False
    )
    sampled = sampled.half().float()
    f32 = [t.float() for t in (centre, fcentre, flow, delta)]
    expected = torch.cat(
        (
            f32[0],
            warped,
            (warped - f32[0]).abs(),
            f32[1],
            sampled,
            (sampled - f32[1]).abs(),
            f32[2],
            f32[2].norm(dim=1, keepdim=True),
            f32[3],
        ),
        1,
    )
    shape = (s, h, w, 32) if padded_rows else (s, 25, h, w)
    # Not zeros: the padding must be written
    out = torch.full(shape, 7.0, device="cuda", dtype=torch.float16)
    conf_kernel.conf_input[conf_kernel.grid(s, h, w)](
        centre,
        full,
        fcentre,
        features,
        grid,
        flow,
        delta,
        out,
        h,
        w,
        padded_rows,
        **conf_kernel.LAUNCH,
    )
    if padded_rows:
        assert bool((out[..., 25:] == 0).all())
        out = out[..., :25].permute(0, 3, 1, 2)
    torch.testing.assert_close(out.float(), expected, atol=8e-3, rtol=2e-3)


tail_kernel = pytest.importorskip("nodes.impl.tensorrt.tfix_tail_kernel")


def test_a_downsample_of_an_odd_size_is_no_round_trip():
    model = _model(1, None, _binomial(1))
    # The full size one row taller than twice the half size
    for value in [*model.graph.node]:
        if value.op_type == "Constant" and value.output[0] == "up/sizes":
            value.attribute[0].t.CopyFrom(
                numpy_helper.from_array(np.array([N, 1, 2 * H + 1, 2 * W], np.int64))
            )
    assert tfix_aot.lower(model).plugins == []


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
def test_the_tail_kernels_match_the_export_s_warp_and_average():
    from nodes.impl.tensorrt.temporal_fix_export import fp32_average, fp32_warp

    s, h, w = 3, 24, 40
    g = torch.Generator(device="cuda").manual_seed(0)

    def rand(*shape: int) -> torch.Tensor:
        return torch.rand(*shape, device="cuda", generator=g)

    frames = rand(s, 3, h, w).half()
    flow = (rand(s, 2, h // 2, w // 2) - 0.5) * 6
    logits = ((rand(s, 1, h // 2, w // 2) - 0.5) * 8).half()
    centre = rand(1, 3, h, w).half()
    device = torch.device("cuda")
    # The network's base grid, which the model holds in FP16
    xs = ((torch.arange(w, device=device) + 0.5) * (2.0 / w) - 1.0).half()
    ys = ((torch.arange(h, device=device) + 0.5) * (2.0 / h) - 1.0).half()
    base = torch.stack((xs.expand(h, w), ys[:, None].expand(h, w)))[None]
    full = functional.interpolate(flow, size=(h, w), mode="bilinear") * 2
    with torch.inference_mode():
        warped = fp32_warp(frames, full, base)
        ones = torch.ones(s, 1, h, w, device=device, dtype=torch.float16)
        valid = fp32_warp(ones, full, base)
        # The graph's operations: the confidence in FP16, as the export computes it
        up = functional.interpolate(logits, size=(h, w), mode="bilinear")
        conf = torch.sigmoid(up) * valid
        expected = fp32_average(
            center=centre,
            aligned_supports=warped[None],
            support_conf=conf[None],
            conf_thresh=0.6,
            min_support=1,
            gate_slope=12.0,
            count_slope=4.0,
        )
    got = torch.empty_like(frames)
    supports = [frames[i : i + 1] for i in range(s)]
    supports += [supports[0]] * (6 - s)
    tail_kernel.warp[tail_kernel.grid(s, h, w)](
        *supports, flow, got, h, w, 2.0, 2.0, **tail_kernel.LAUNCH
    )
    torch.testing.assert_close(got.float(), warped.float(), atol=1e-3, rtol=0)
    out = torch.empty(1, 3, h, w, device=device)
    tail_kernel.blend[tail_kernel.grid(1, h, w)](
        centre,
        warped,
        logits,
        flow,
        out,
        h,
        w,
        s,
        flow_x=2.0,
        flow_y=2.0,
        threshold=0.6,
        gate_slope=12.0,
        min_support=1.0,
        offset=0.5,
        count_slope=4.0,
        one=1.0,
        eps=1e-6,
        **tail_kernel.LAUNCH,
    )
    # The graph's own rounding: the FP32-confidence form is up to 4e-4 off it
    torch.testing.assert_close(out, expected.float(), atol=1e-4, rtol=0)


block_kernel = pytest.importorskip("nodes.impl.tensorrt.tfix_block_input_kernel")


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
@pytest.mark.parametrize("padded_rows", [False, True])
# The previous block's output: FP16 (every stage in FP16), FP32 (the first two in FP32)
@pytest.mark.parametrize("previous_type", [torch.float16, torch.float32])
def test_the_block_input_kernel_matches_the_network_s_operations(
    padded_rows: bool, previous_type: torch.dtype
):
    from nodes.impl.tensorrt.temporal_fix_export import fp32_warp

    s, h, w = 3, 24, 40
    device = torch.device("cuda")
    g = torch.Generator(device="cuda").manual_seed(0)

    def rand(*shape: int) -> torch.Tensor:
        return torch.rand(*shape, device="cuda", generator=g)

    centre, fcentre = rand(1, 3, h, w).half(), (rand(1, 4, h, w) * 2 - 1).half()
    supports = rand(s, 7, h, w).half()
    quarter = (rand(s, 2, h // 2, w // 2) - 0.5) * 6
    previous = ((rand(s, 11, h // 2, w // 2) - 0.5) * 6).to(previous_type)
    delta = torch.tensor([-1.0, 0.0, 1.0], device=device).half()
    # The network's base grid, which the model holds in FP16
    xs = ((torch.arange(w, device=device) + 0.5) * (2.0 / w) - 1.0).half()
    ys = ((torch.arange(h, device=device) + 0.5) * (2.0 / h) - 1.0).half()
    base = torch.stack((xs.expand(h, w), ys[:, None].expand(h, w)))[None]

    def up(t: torch.Tensor) -> torch.Tensor:
        return functional.interpolate(t, size=(h, w), mode="bilinear")

    with torch.inference_mode():
        flow = up(quarter) * 2
        warped = fp32_warp(supports, flow, base)
        expected = torch.cat(
            (
                centre.expand(s, -1, -1, -1),
                warped[:, :3],
                fcentre.expand(s, -1, -1, -1),
                warped[:, 3:],
                delta.view(s, 1, 1, 1).expand(s, 1, h, w),
                up(previous[:, 2:3].half()),
                up(previous[:, 3:].half()),
                flow.half(),
            ),
            1,
        )
    shape = (s, h, w, 32) if padded_rows else (s, 26, h, w)
    # Not zeros: the padding must be written
    out = torch.full(shape, 7.0, device=device, dtype=torch.float16)
    block_kernel.block_input[block_kernel.grid(s, h, w)](
        centre,
        fcentre,
        supports,
        quarter,
        previous,
        delta,
        out,
        h,
        w,
        2.0,
        2.0,
        padded_rows,
        **block_kernel.LAUNCH,
    )
    if padded_rows:
        assert bool((out[..., 26:] == 0).all())
        out = out[..., :26].permute(0, 3, 1, 2)
    torch.testing.assert_close(out.float(), expected.float(), atol=1e-3, rtol=1e-3)
