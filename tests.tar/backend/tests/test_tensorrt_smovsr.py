"""SMoVSR's engine sets on the app side (nodes/impl/tensorrt/smovsr.py, smovsr_export.py):
the set's key, the weights the export reads, the export's graphs (chained over a clip by
onnxruntime against the library's whole-clip forward), the set's container; and on a GPU,
a small set built and run by its session against the library's windows."""

from __future__ import annotations

import dataclasses
import sys
from collections import OrderedDict
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import onnx
import onnxruntime as ort
import pytest
import torch

pytest.importorskip("spandrel.architectures.SMoVSR")

from spandrel.architectures.SMoVSR import (
    LOOK_AHEAD,
    WARM_UP,
    SMoVSR,
    SMoVSRArch,
    run_clip,
    run_window,
)

from nodes.impl.tensorrt import build_cache, rdual, rsr_export, smovsr, smovsr_export
from nodes.impl.tensorrt.model import TemporalInfo, TensorRTEngine, TensorRTEngineInfo
from nodes.impl.tensorrt.rdual_engine_set import pack, unpack

PARTS = smovsr_export.PARTS
INFO = TensorRTEngineInfo(
    precision="fp16",
    input_channels=3,
    output_channels=3,
    scale=2,
    gpu_architecture="sm_120",
    tensorrt_version="11.4.0",
    has_dynamic_shapes=False,
    min_shape=(1, 3, 64, 96),
    opt_shape=(1, 3, 64, 96),
    max_shape=(1, 3, 64, 96),
    temporal=TemporalInfo("SMoVSR", 64, 96, "", PARTS),
)


def small(seed: int = 0, h_clamp: float | None = 30.0) -> Any:
    """A small SMoVSR (dim 8) with every parameter moved off its initial value, loaded as
    the app loads a file, with the state bound the app reads from its training
    settings."""
    torch.manual_seed(seed)
    model = SMoVSR(dim=8)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.05)
    descriptor = SMoVSRArch().load(model.eval().state_dict())
    network = descriptor.model
    network.f_forward.h_clamp = h_clamp
    network.f_backward.h_clamp = h_clamp
    network.hyperparameters["h_clamp"] = h_clamp
    return descriptor


@pytest.fixture(scope="module")
def descriptor() -> Any:
    return small()


@pytest.fixture
def machine(monkeypatch: pytest.MonkeyPatch) -> None:
    """A GPU and TensorRT as the key reads them."""
    # memory.py imports CUDA's bindings, which GitHub's checks do not install.
    pytest.importorskip("cuda.bindings.runtime")
    from nodes.impl.tensorrt import memory

    monkeypatch.setitem(sys.modules, "tensorrt", SimpleNamespace(__version__="11.4.0"))
    monkeypatch.setattr(memory, "get_cuda_device_name", lambda _i: "GPU")
    monkeypatch.setattr(memory, "get_cuda_compute_capability", lambda _i: (12, 0))


@pytest.mark.usefixtures("machine")
def test_the_key_follows_the_size_the_weights_the_bound_and_the_recipe(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch
):
    key = smovsr.engine_key(descriptor, 64, 96, 0)

    assert smovsr.engine_key(descriptor, 64, 96, 0) == key
    assert smovsr.engine_key(descriptor, 96, 64, 0) != key
    assert smovsr.engine_key(small(seed=1), 64, 96, 0) != key
    assert smovsr.engine_key(small(h_clamp=None), 64, 96, 0) != key
    monkeypatch.setattr(smovsr, "recipe_identity", lambda: "another recipe")
    assert smovsr.engine_key(descriptor, 64, 96, 0) != key


def test_the_recipe_is_smovsrs_own_and_covers_what_it_runs():
    names = {path.name for path in smovsr.RECIPE_SOURCES}

    assert {"smovsr.py", "smovsr_export.py", "rsr_engine_worker.py"} <= names
    assert {"rsr_export.py", "rdual_export.py"} <= names
    from nodes.impl.tensorrt import rsr, tfdat

    for other in (rsr.RECIPE_SOURCES, tfdat.RECIPE_SOURCES):
        assert not any(path.name.startswith("smovsr") for path in other)


def test_the_export_reads_the_folded_model_back(descriptor: Any, tmp_path: Path):
    weights = rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")

    read = smovsr_export.load(weights)

    mine, theirs = descriptor.model.state_dict(), read.state_dict()
    assert mine.keys() == theirs.keys()
    assert all(torch.equal(mine[k], theirs[k]) for k in mine)
    assert read.f_forward.h_clamp == read.f_backward.h_clamp == 30.0
    frames = torch.rand(1, 3, 3, 20, 24)
    with torch.inference_mode():
        assert torch.equal(
            run_window(read, frames, 2)[0], run_window(descriptor.model, frames, 2)[0]
        )


def test_the_export_child_gets_the_weights_and_the_size(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    seen: list[list[str]] = []

    def child(arguments: list[str], *_: Any, **kwargs: Any) -> str:
        seen.append(arguments)
        assert kwargs == {"cpu_only": True}
        assert smovsr_export.load(Path(arguments[2])).scale == 2
        Path(arguments[3]).mkdir()
        (Path(arguments[3]) / "export.json").write_text("{}", encoding="utf-8")
        return ""

    monkeypatch.setattr(smovsr, "run_child", child)
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)

    smovsr.export(descriptor, 64, 96, tmp_path / "export", 0)

    ((module, _weights, folder, height, width, device),) = [s[1:] for s in seen]
    assert (module, folder, height, width, device) == (
        "nodes.impl.tensorrt.smovsr_export",
        str(tmp_path / "export"),
        "64",
        "96",
        "cpu",
    )


def bindings(graph: onnx.ModelProto) -> dict[str, tuple[int, tuple[int, ...]]]:
    return {
        v.name: (
            v.type.tensor_type.elem_type,
            tuple(d.dim_value for d in v.type.tensor_type.shape.dim),
        )
        for v in (*graph.graph.input, *graph.graph.output)
    }


def test_the_parts_compute_in_fp16_with_fp32_images_and_resize(
    descriptor: Any, tmp_path: Path
):
    folded = smovsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    graphs = smovsr_export.parts(folded, 20, 24, "cpu")

    types = onnx.TensorProto
    assert set(graphs) == set(PARTS)
    for name, graph in graphs.items():
        inputs = {v.name for v in graph.graph.input}
        for binding, (elem, shape) in bindings(graph).items():
            # static inputs; TensorRT infers the outputs' shapes from them
            if binding in inputs:
                assert all(shape), (name, binding, shape)
            if binding in rsr_export.IMAGE_BINDINGS:
                assert elem == types.FLOAT
            elif binding in rsr_export.VALIDITY_BINDINGS:
                assert (elem, shape) == (types.BOOL, (1,))
            else:
                # every handoff, 8 channels here (32 in the real model): HWC8 in a set
                assert elem == types.FLOAT16, (name, binding)
                assert shape[1] == 8, (name, binding)
        produced = {o: n for n in graph.graph.node for o in n.output}
        resizes = [n for n in graph.graph.node if n.op_type == "Resize"]
        assert len(resizes) == smovsr_export.RESIZES[name]
        for node in resizes:
            source = produced[node.input[0]]
            assert source.op_type == "Cast"
            assert source.attribute[0].i == types.FLOAT
    assert [v.name for v in graphs["encfwd"].graph.input] == [
        "x",
        "state_past",
        "valid_past",
    ]
    assert [v.name for v in graphs["encfwd"].graph.output] == [
        "feat",
        "fwd_out",
        "state",
    ]
    assert [v.name for v in graphs["bwd"].graph.input] == [
        "feat",
        "fwd_out",
        "state_future",
        "valid_future",
    ]
    assert [v.name for v in graphs["bwd"].graph.output] == ["bwd_out", "state"]
    assert [v.name for v in graphs["head"].graph.output] == ["output"]


def test_a_part_with_another_number_of_resizes_is_refused(
    descriptor: Any, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    folded = smovsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    monkeypatch.setattr(smovsr_export, "fp32_resize", lambda _model: 0)

    with pytest.raises(RuntimeError, match="found 0 Resizes"):
        smovsr_export.parts(folded, 20, 24, "cpu")


def chained(
    graphs: dict[str, onnx.ModelProto], clip: torch.Tensor, dtype: Any
) -> np.ndarray:
    """The clip's T,3,sH,sW outputs from the three graphs on onnxruntime's CPU, chained
    as a session chains the engines over one window holding the whole clip: encfwd
    over every frame, then bwd from the last frame down with each frame's head."""
    run = {
        name: ort.InferenceSession(
            graph.SerializeToString(), providers=["CPUExecutionProvider"]
        )
        for name, graph in graphs.items()
    }
    frames = clip[0].numpy()
    count = len(frames)
    (state_past,) = [v for v in graphs["encfwd"].graph.input if v.name == "state_past"]
    shape = [d.dim_value for d in state_past.type.tensor_type.shape.dim]
    zero = np.zeros(shape, dtype)
    on, off = np.ones(1, bool), np.zeros(1, bool)
    encoded, state = [], zero
    for t in range(count):
        x = frames[t][None]
        feat, fwd_out, state = run["encfwd"].run(
            None, {"x": x, "state_past": state, "valid_past": on if t else off}
        )
        encoded.append((x, feat, fwd_out))
    outputs: list[np.ndarray] = [np.empty(0)] * count
    back = zero
    for t in range(count - 1, -1, -1):
        x, feat, fwd_out = encoded[t]
        bwd_out, back = run["bwd"].run(
            None,
            {
                "feat": feat,
                "fwd_out": fwd_out,
                "state_future": back,
                "valid_future": on if t < count - 1 else off,
            },
        )
        (output,) = run["head"].run(
            None, {"x": x, "fwd_out": fwd_out, "bwd_out": bwd_out}
        )
        assert isinstance(output, np.ndarray)
        outputs[t] = output
    return np.concatenate(outputs)


def test_the_graphs_chained_over_a_clip_are_the_whole_clip_forward(
    descriptor: Any, tmp_path: Path
):
    # The parts' modules traced from the folded FP32 model compute in FP32: the graphs
    # the set's FP16 parts are cast from, chained against the model's own forward.
    folded = smovsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    height, width = 20, 24
    x = torch.rand(1, 3, height, width)
    state = torch.rand(1, 8, height, width)
    valid = torch.ones(1, dtype=torch.bool)
    with torch.no_grad():
        graphs = {
            "encfwd": smovsr_export.trace(
                smovsr_export.EncodeForward(folded),
                {"x": x, "state_past": state, "valid_past": valid},
                ("feat", "fwd_out", "state"),
            ),
            "bwd": smovsr_export.trace(
                smovsr_export.Backward(folded),
                {
                    "feat": state,
                    "fwd_out": state,
                    "state_future": state,
                    "valid_future": valid,
                },
                ("bwd_out", "state"),
            ),
            "head": smovsr_export.trace(
                smovsr_export.Head(folded),
                {"x": x, "fwd_out": state, "bwd_out": state},
                ("output",),
            ),
        }
    clip = torch.rand(
        1, 7, 3, height, width, generator=torch.Generator().manual_seed(2)
    )

    got = chained(graphs, clip, np.float32)

    with torch.inference_mode():
        expected = run_clip(folded, clip)[0].numpy()
    assert got.shape == expected.shape == (7, 3, 2 * height, 2 * width)
    # oneDNN rounds the whole clip's batched calls differently from per-frame ones
    assert float(np.abs(got - expected).max()) <= 1e-5


def test_the_fp16_parts_chained_over_a_clip_stay_near_fp32(
    descriptor: Any, tmp_path: Path
):
    folded = smovsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w.safetensors")
    )
    height, width = 20, 24
    graphs = smovsr_export.parts(folded, height, width, "cpu")
    clip = torch.rand(
        1, 7, 3, height, width, generator=torch.Generator().manual_seed(2)
    )

    got = chained(graphs, clip, np.float16)

    reference = smovsr_export.load(
        rdual.write_weights(descriptor.model, tmp_path / "w2.safetensors")
    )
    with torch.inference_mode():
        expected = run_clip(reference, clip)[0].numpy()
    # half precision's rounding only
    assert float(np.sqrt(((got - expected) ** 2).mean())) <= 2e-3


def test_a_set_is_one_container_named_smovsr():
    data = {name: bytes([i]) * (500 + i) for i, name in enumerate(PARTS)}

    info, parts = unpack(pack(data, INFO).bytes)

    assert parts == data
    assert dataclasses.asdict(info) == dataclasses.asdict(INFO)
    assert info.temporal is not None and info.temporal.architecture == "SMoVSR"


def test_set_info_names_the_architecture_and_its_parts(
    monkeypatch: pytest.MonkeyPatch,
):
    pytest.importorskip("cuda.bindings.runtime")
    from nodes.impl.tensorrt import memory

    monkeypatch.setitem(sys.modules, "tensorrt", SimpleNamespace(__version__="11.4.0"))
    monkeypatch.setattr(memory, "get_cuda_compute_capability", lambda _i: (12, 0))
    manifest = {"height": 64, "width": 96, "scale": 2, "parts": dict.fromkeys(PARTS)}

    assert smovsr.set_info(manifest, 0) == INFO


def test_a_set_is_kept_in_a_cache_folder_made_for_it(
    descriptor: Any, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    monkeypatch.setattr(build_cache, "_memory", OrderedDict())
    monkeypatch.setattr(smovsr, "engine_key", lambda *_: "smovsr-key")
    data = {name: bytes([i]) * 100 for i, name in enumerate(PARTS)}
    monkeypatch.setattr(smovsr, "build_set", lambda *_: pack(data, INFO))
    folder = tmp_path / "cache"

    engine = smovsr.engine_set(descriptor, 64, 96, 0, str(folder))

    assert unpack(engine.bytes)[1] == data
    assert [p.name for p in folder.iterdir()] == [f"smovsr-key{build_cache.SUFFIX}"]


def test_tensorrt_upscale_image_reads_ahead_as_the_model():
    # The TensorRT package's Upscale Image imports TensorRT.
    pytest.importorskip("tensorrt")
    from nodes.impl.pytorch.smovsr_window import MAX_KEEP
    from packages.chaiNNer_tensorrt.tensorrt.processing.upscale_image import (
        context_of,
        window_of,
    )

    engine = TensorRTEngine(b"set", INFO)
    assert context_of(engine) == (WARM_UP, LOOK_AHEAD)
    # the item window as PyTorch's Upscale Image asks for an SMoVSR model
    assert window_of(engine) == MAX_KEEP + LOOK_AHEAD == 48
    rsr = dataclasses.replace(
        INFO, temporal=TemporalInfo("RSR", 64, 96, "", ("prefix", "revcore", "fwdcore"))
    )
    assert window_of(TensorRTEngine(b"set", rsr)) == window_of(object()) == 0


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs a CUDA GPU")
def test_a_set_builds_and_matches_pytorch_across_windows():
    pytest.importorskip("tensorrt")
    from nodes.impl.tensorrt.smovsr_session import open_session

    descriptor = small()
    height, width = 32, 48
    engine = smovsr.build_set(descriptor, height, width, 0)
    clip = torch.rand(
        1, 12, 3, height, width, generator=torch.Generator().manual_seed(1)
    )
    # windows as the planner runs them: cold, keeping 1, then 3, then to the clip's end
    windows = ((0, 5, 1), (1, 6, 3), (4, 8, 8))
    session = open_session(engine, 0)
    try:
        frames = [
            session.convert(np.ascontiguousarray(f.permute(1, 2, 0).flip(-1).numpy()))
            for f in clip[0]
        ]
        got, past = [], None
        for first, count, keep in windows:
            outputs, state = session.run(
                frames[first : first + count], keep, past, first
            )
            got += [session.to_image(o) for o in outputs]
            past = (state, frames[first + keep - 1])
    finally:
        session.close()
    model = descriptor.model.float().cuda().eval()
    expected, carry = [], None
    with torch.inference_mode():
        for first, count, keep in windows:
            out, carry = run_window(
                model, clip[:, first : first + count].cuda(), keep, carry
            )
            expected += list(out[0].permute(0, 2, 3, 1).flip(-1).cpu().numpy())
    assert len(got) == len(expected) == 12
    for image, reference in zip(got, expected, strict=True):
        assert image.shape == reference.shape == (2 * height, 2 * width, 3)
        # FP16 engines against FP32 (the real model: 1.24 times PyTorch FP16's distance)
        assert float(np.sqrt(((image - reference) ** 2).mean())) <= 2e-3
